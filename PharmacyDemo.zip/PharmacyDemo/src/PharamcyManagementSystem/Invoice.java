package PharamcyManagementSystem;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import static java.awt.print.Printable.NO_SUCH_PAGE;
import static java.awt.print.Printable.PAGE_EXISTS;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.ImageIcon;

public class Invoice extends javax.swing.JFrame {

    Double totalAmount = 0.0;
    Double cash = 0.0;
    Double balance = 0.0;
    Double bHeight = 0.0;

    ArrayList<String> itemName = new ArrayList<>();
    ArrayList<String> quantity = new ArrayList<>();
    ArrayList<String> itemPrice = new ArrayList<>();
    ArrayList<String> subtotal = new ArrayList<>();
    
    String storeName, state, city, pincode, MobileNumber;

    Connection con;
    ResultSet rs;
    Statement stm;


    public Invoice() {
        initComponents();
        itemName.add("med2");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");

        itemName.add("med3");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");

        itemName.add("med4");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");

        itemName.add("Medicine1s");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");

        itemName.add("med3");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");

        itemName.add("med4");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");

        itemName.add("med2");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");

        itemName.add("med3");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");
        
        itemName.add("med4");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");

        itemName.add("med2");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");

        itemName.add("med3");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");

        itemName.add("med4");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");

        itemName.add("med2");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");

        itemName.add("med3");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");

        itemName.add("med4");
        quantity.add("20");
        itemPrice.add("10");
        subtotal.add("200");
        getPharmacyDetails();

    }

    private void getPharmacyDetails() {
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacydatabase", "root", "Moin$8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT * FROM REGISTER";
            rs = stmt.executeQuery(query);
            rs.next();
            storeName = rs.getString(4);
            state = rs.getString(5);
            city = rs.getString(6);
            pincode = rs.getString(7);
            MobileNumber = rs.getString(8);
            System.out.println(storeName + state + city + pincode + MobileNumber);
            con.close();

        } catch (Exception e) {
        }
    }

    public PageFormat getPageFormat(PrinterJob pj) {

        PageFormat pf = pj.defaultPage();
        Paper paper = pf.getPaper();

        Double bodyHeight = 15.0;
        Double headerHeight = 5.0;
        Double footerHeight = 5.0;
        Double width = cm_to_pp(15);
        Double height = cm_to_pp(headerHeight + bodyHeight + footerHeight);
        paper.setSize(width, height);
        paper.setImageableArea(0, 10, width, height - cm_to_pp(1));

        pf.setOrientation(PageFormat.PORTRAIT);
        pf.setPaper(paper);

        return pf;
    }

    protected static double cm_to_pp(double cm) {
        return toPPI(cm * 0.393600787);
    }

    protected static double toPPI(double inch) {
        return inch * 72d;
    }

    public class BillPrintable implements Printable {

        public int print(Graphics graphics, PageFormat pageFormat, int pageIndex)
                throws PrinterException {

            int r = itemName.size();
            ImageIcon icon = new ImageIcon("C:\\Users\\moin_pc\\Desktop\\3rd year\\Pharmacy\\Logo.PNG");
            int result = NO_SUCH_PAGE;
            if (pageIndex == 0) {

                Graphics2D g2d = (Graphics2D) graphics;
                double width = pageFormat.getImageableWidth();
                g2d.translate((int) pageFormat.getImageableX(), (int) pageFormat.getImageableY());

                //  FontMetrics metrics=g2d.getFontMetrics(new Font("Arial",Font.BOLD,7));
                try {
                    int y = 30;
                    int yShift = 12;
                    int headerRectHeight = 15;
                    Calendar c = Calendar.getInstance();

                    SimpleDateFormat time = new SimpleDateFormat("yyyy-mm-dd, hh:mm:ss aa");
                    Date dat = c.getTime();
                    String timeInString = time.format(dat);
                    // int headerRectHeighta=40;

                    g2d.setFont(new Font("Monospaced", Font.PLAIN, 15));
                    g2d.drawImage(icon.getImage(), 100, 12, 100, 50, rootPane);
                    g2d.drawString("" + storeName + "        ", 210, 17);
                    g2d.setFont(new Font("Monospaced", Font.PLAIN, 11));
                    g2d.drawString("" + state + "," + city + " ", 210, 29);
                    g2d.drawString("" + state + "-" + pincode + " ", 210, 40);
                    g2d.drawString("www.facebook.com/" + storeName + " ", 210, 50);
                    g2d.drawString("+" + MobileNumber + "      ", 210, 62);
//                  g2d.setColor(Color.red);
                    
                    g2d.setColor(Color.black);
                    y += yShift + 30;
                    g2d.drawLine(206, 3, 206, y);
                    g2d.drawLine(90, y, 420, y);
                    y += yShift + 2;
                    g2d.drawString("Medicine Sell Invoice", 200, y);
                    y += yShift + 2;
                    g2d.drawLine(90, y, 420, y);
                    y += yShift + 2;
                    g2d.drawString("PRINT : " + timeInString + "", 110, y);
                    y += yShift + 2;
                    g2d.drawLine(90, y, 420, y);
                    y += yShift;
                    g2d.drawString("NAME : Kadiwal Moinudin        ", 110, y);
                    y += yShift;
                    g2d.drawString("AGE : " + 20 + "", 110, y);
                    y += yShift;
                    String g = "MALE";
                    g2d.drawString("GENDER : " + g + "", 110, y);
                    y += yShift;
                    g2d.drawString("CONTACT : +91 9328207651      ", 110, y);
                    y += yShift;
                    g2d.drawLine(90, y, 420, y);
                    y += headerRectHeight;
                    g2d.drawString("PRODUCT DETAIL", 220, y);
                    y += yShift + 2;
                    g2d.drawLine(90, y, 420, y);
                    Color newColor=new Color(0,156,247);
                    g2d.setColor(Color.BLACK);
                    y += yShift + 2;
                    g2d.drawString("MEDICINENAME        QUANTITY   Price  TOTAL PRICE", 92, y);
                    y += yShift;
                    g2d.drawLine(90, y, 420, y);
                    y += headerRectHeight;
                    for (int s = 0; s < r; s++) {
                        g2d.setColor(Color.black);
                        g2d.drawString("  " + itemName.get(s), 92, y);//"                      " + quantity.get(s) + "           " + itemPrice.get(s) + "         " + subtotal.get(s)
                        g2d.drawString(quantity.get(s),246,y);
                        g2d.drawString(itemPrice.get(s),310,y);
                        g2d.drawString( subtotal.get(s),375,y);
                       
                        y += yShift+5;

                    }
                    g2d.setColor(Color.black);
                    g2d.drawLine(213, 216, 213, y);
                    g2d.drawLine(291, 216, 291, y);
                    g2d.drawLine(340, 216, 340, y);
                    
                    g2d.drawLine(90, y, 420, y);
                    y += yShift;
                    g2d.drawString("Total amount  :  ", 250, y);
                    g2d.drawString("1000000", 360, y);
                    y += yShift;
                    g2d.drawLine(90, y, 420, y);
                    y += yShift;
                    g2d.drawString("Cash  :   " , 250, y);
                    g2d.drawString("10000000", 360, y);
                    y += yShift;
                    g2d.drawLine(90, y, 420, y);
                    y += yShift;
                    g2d.drawString("Balance   :   ", 250, y);
                    g2d.drawString("10000000", 360, y);
                    y += yShift;
                    g2d.drawLine(90, y, 420, y);
                    y += yShift;
                    g2d.drawLine(90, y, 420, y);
                    g2d.drawLine(90, 3, 90, y);
                    g2d.drawLine(420, y, 420, 3);
                    g2d.drawLine(420, 3, 90, 3);
//                    y += yShift;
//                    g2d.drawString("       SOFTWARE BY:CODEGUID          ", 92, y);
//                    y += yShift;
//                    g2d.drawString("   CONTACT: contact@codeguid.com       ", 92, y);
                    y += yShift;

                } catch (Exception e) {
                    e.printStackTrace();
                }

                result = PAGE_EXISTS;
            }
            return result;
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setBackground(new java.awt.Color(0, 181, 226));
        jButton1.setText("Print Bill");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(318, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(115, 115, 115)
                .addComponent(jButton1)
                .addContainerGap(160, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        bHeight = Double.valueOf(itemName.size());
        //JOptionPane.showMessageDialog(rootPane, bHeight);

        PrinterJob pj = PrinterJob.getPrinterJob();
        pj.setPrintable(new BillPrintable(), getPageFormat(pj));
        try {
            pj.print();
            

        } catch (PrinterException ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_jButton1MouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Invoice.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Invoice.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Invoice.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Invoice.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Invoice().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    // End of variables declaration//GEN-END:variables
}
