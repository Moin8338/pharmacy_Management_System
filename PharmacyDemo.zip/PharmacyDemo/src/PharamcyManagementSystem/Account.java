package PharamcyManagementSystem;

import java.awt.Color;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

public class Account extends javax.swing.JFrame {

    DefaultTableModel model, model1, model2, model3;
    String ExpenseReportQuery = "", CreditReportQuery = "";
    Map<String, Object> p = new HashMap<String, Object>();

    public Account() {
        initComponents();

        model = (DefaultTableModel) ExpenseMainTable.getModel();
        model1 = (DefaultTableModel) ExpenseTableForPay.getModel();
        model2 = (DefaultTableModel) PaymentHistoryTable.getModel();
        model3 = (DefaultTableModel) CreditTable.getModel();
        selection();
        selection1();
        selection3();
        getPharmacyDetails();
        Creditselection();
        // CompanyPaymentSelection();
    }
    Connection con = null;
    Statement st = null;
    ResultSet rs = null;

    public void getPharmacyDetails() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT * FROM REGISTER";
            rs = stmt.executeQuery(query);
            rs.next();
            p.put("StoreName", rs.getString(4));
            p.put("Address", rs.getString(6));
            p.put("Mobile", rs.getString(5));
            p.put("RegisterNo", rs.getString(8));
            con.close();

        } catch (Exception e) {
        }
    }

    void selection() {
        try {
            model.setNumRows(0);
            AddExpenseShow.setSelected(true);
            PaidExpenseSort.setSelected(false);
            NotPaidExpenseSort.setSelected(false);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from EXPENISES ORDER BY DATE";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                String Name = rs.getString(2);
                String Amount = rs.getString(3);
                String Date = rs.getString(4);
                String Category = rs.getString(5);
                String type = rs.getString(6);
                String PaidDate = rs.getString(7);
                String Id = rs.getString(1);
                String tbDate[] = {Id, Name, Amount, Date, Category, type, PaidDate};
                DefaultTableModel tb1Model = (DefaultTableModel) ExpenseMainTable.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
            ExpenseReportQuery = query;
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    void selection1() {
        try {
            model1.setNumRows(0);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from EXPENISES WHERE TYPE='NOT PAID'";
            rs = stmt.executeQuery(query);

            while (rs.next()) {

                String Name = rs.getString(2);
                String Amount = rs.getString(3);
                String Date = rs.getString(4);
                String Category = rs.getString(5);
                String type = rs.getString(6);
                String PaidDate = rs.getString(7);
                String Id = rs.getString(1);
                String tbDate[] = {Id, Name, Amount, Date, Category, type, PaidDate};
                DefaultTableModel tb1Model2 = (DefaultTableModel) ExpenseTableForPay.getModel();
                tb1Model2.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    void selection3() {
        try {
            model2.setNumRows(0);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from PAYMENT_HISTORY";
            rs = stmt.executeQuery(query);

            while (rs.next()) {

                String Name = rs.getString(1);
                String Amount = rs.getString(2);
                String Date = rs.getString(3);
                String Category = rs.getString(4);

                String tbDate[] = {Name, Amount, Date, Category};
                DefaultTableModel tb1Model2 = (DefaultTableModel) PaymentHistoryTable.getModel();
                tb1Model2.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    //selection of credit table
    void Creditselection() {
        try {
            model3.setNumRows(0);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from CREDIT ORDER BY DATE";
            rs = stmt.executeQuery(query);

            while (rs.next()) {

                String Name = rs.getString(2);
                String Amount = rs.getString(3);
                String Date = rs.getString(4);
                String Category = rs.getString(5);
                String Id = rs.getString(1);
                String tbDate[] = {Id, Name, Amount, Date, Category};
                DefaultTableModel tb1Model = (DefaultTableModel) CreditTable.getModel();
                tb1Model.addRow(tbDate);
            }
            CreditReportQuery = query;
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    void CompanyPaymentSelection() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from EXPENISES WHERE TYPE='NOT PAID'";
            rs = stmt.executeQuery(query);

            while (rs.next()) {

                String Name = rs.getString(1);
                String Amount = rs.getString(2);
                String Date = rs.getString(3);
                String Category = rs.getString(4);

                String tbDate[] = {Name, Amount, Date, Category};
                DefaultTableModel tb1Model = (DefaultTableModel) ExpenseTableForPay.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Somting Went Wrong...");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        ExpenseMainTable = new javax.swing.JTable();
        jPanel9 = new javax.swing.JPanel();
        ExpenseDateField = new com.toedter.calendar.JDateChooser();
        AddExpenseButtton = new javax.swing.JButton();
        UpdateExpenseButton = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        DeleteExpenseButton = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        ExpenseNameField = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        ExpenseAmtField = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        Paid = new javax.swing.JRadioButton();
        NotPaid = new javax.swing.JRadioButton();
        jPanel12 = new javax.swing.JPanel();
        StaringDate_forSearch = new com.toedter.calendar.JDateChooser();
        SearchExpenseButton = new javax.swing.JButton();
        SortExpenseButton = new javax.swing.JButton();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        ExpenseName_forSearch = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        EndingDate_forSearch = new com.toedter.calendar.JDateChooser();
        RefreshExpnseTableButton = new javax.swing.JButton();
        PaidExpenseSort = new javax.swing.JRadioButton();
        NotPaidExpenseSort = new javax.swing.JRadioButton();
        AddExpenseShow = new javax.swing.JRadioButton();
        PrintExpense = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        CreditTable = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        CreditNameField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        CreditAmtField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        CreditCategoryField = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        AddingDateFieldOfCredit = new com.toedter.calendar.JDateChooser();
        DeleteCreditButton = new javax.swing.JButton();
        AddCreditButton = new javax.swing.JButton();
        UpdateCreditBtton = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        CreditName_forSearch = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        StartingDate_forCreditSearch = new com.toedter.calendar.JDateChooser();
        jLabel16 = new javax.swing.JLabel();
        EndingDate_forSearchCredit = new com.toedter.calendar.JDateChooser();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        PrintCredit_record = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ExpenseTableForPay = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        PaymentHistoryTable = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        ExpenseName_forPayField = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        ExpenseAmt_forPayField = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        ExpenseCategory_forPayField = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        PayingDate = new com.toedter.calendar.JDateChooser();
        PayButton = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jDateChooser7 = new com.toedter.calendar.JDateChooser();
        jDateChooser8 = new com.toedter.calendar.JDateChooser();
        jLabel5 = new javax.swing.JLabel();
        sortExpenseByDateButton_forPay = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        SearchExpenseField_forPay = new javax.swing.JTextField();
        SearchExpenseButton_forPay = new javax.swing.JButton();
        Payment_report = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("Account"); // NOI18N
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Close all jframe.png"))); // NOI18N
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Sitka Text", 0, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("ACCOUNT");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1173, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel23.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("ALL EXPENSIVE");

        ExpenseMainTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Expensive_Name", "Amount", "Date", "Category", "Type", "PaidDate"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        ExpenseMainTable.setRowHeight(30);
        ExpenseMainTable.setSelectionBackground(new java.awt.Color(232, 57, 95));
        ExpenseMainTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ShowData(evt);
            }
        });
        jScrollPane5.setViewportView(ExpenseMainTable);
        if (ExpenseMainTable.getColumnModel().getColumnCount() > 0) {
            ExpenseMainTable.getColumnModel().getColumn(0).setResizable(false);
            ExpenseMainTable.getColumnModel().getColumn(1).setResizable(false);
            ExpenseMainTable.getColumnModel().getColumn(2).setResizable(false);
            ExpenseMainTable.getColumnModel().getColumn(3).setResizable(false);
            ExpenseMainTable.getColumnModel().getColumn(4).setResizable(false);
            ExpenseMainTable.getColumnModel().getColumn(5).setResizable(false);
            ExpenseMainTable.getColumnModel().getColumn(6).setResizable(false);
        }

        AddExpenseButtton.setBackground(new java.awt.Color(0, 102, 0));
        AddExpenseButtton.setText("ADD");
        AddExpenseButtton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddExpensive(evt);
            }
        });
        AddExpenseButtton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddExpenseButttonActionPerformed(evt);
            }
        });

        UpdateExpenseButton.setBackground(new java.awt.Color(51, 51, 255));
        UpdateExpenseButton.setText("UPDATE");
        UpdateExpenseButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UpdateExpensive(evt);
            }
        });

        jLabel27.setFont(new java.awt.Font("Yu Gothic UI Semilight", 1, 18)); // NOI18N
        jLabel27.setText("ADD NEW");

        DeleteExpenseButton.setBackground(new java.awt.Color(255, 0, 0));
        DeleteExpenseButton.setText("DELETE");
        DeleteExpenseButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DeleteExpensive(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel26.setText("EXPENSIVE TITLE : ");

        jLabel28.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel28.setText("AMOUNT : ");

        jLabel29.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel29.setText("EXPENSIVE DATE : ");

        Paid.setText("PAID");
        Paid.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PaidMouseClicked(evt);
            }
        });

        NotPaid.setSelected(true);
        NotPaid.setText("NOT PAID");
        NotPaid.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                NotPaidMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(152, 152, 152)
                .addComponent(jLabel27)
                .addContainerGap(134, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addComponent(AddExpenseButtton, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(UpdateExpenseButton, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(DeleteExpenseButton, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(Paid)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(NotPaid))
                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel29)
                                .addComponent(jLabel26)
                                .addComponent(ExpenseNameField)
                                .addComponent(jLabel28)
                                .addComponent(ExpenseAmtField)
                                .addComponent(ExpenseDateField, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(64, 64, 64))))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ExpenseNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ExpenseAmtField, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ExpenseDateField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Paid)
                    .addComponent(NotPaid))
                .addGap(14, 14, 14)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddExpenseButtton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UpdateExpenseButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DeleteExpenseButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        SearchExpenseButton.setBackground(new java.awt.Color(0, 102, 0));
        SearchExpenseButton.setText("SEARCH");
        SearchExpenseButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchExpensive(evt);
            }
        });

        SortExpenseButton.setBackground(new java.awt.Color(0, 102, 0));
        SortExpenseButton.setText("SORT");
        SortExpenseButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sortByDate(evt);
            }
        });

        jLabel30.setFont(new java.awt.Font("Yu Gothic UI Semilight", 1, 18)); // NOI18N
        jLabel30.setText("SEARCH EXPENSIVE");

        jLabel31.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel31.setText("EXPENSIVE TITLE : ");

        jLabel33.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel33.setText("STARTING DATE : ");

        jLabel34.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel34.setText("ENDING DATE : ");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel30)
                .addGap(94, 94, 94))
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addComponent(SearchExpenseButton, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(SortExpenseButton, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel34)
                            .addComponent(EndingDate_forSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel33)
                                .addComponent(jLabel31)
                                .addComponent(ExpenseName_forSearch)
                                .addComponent(StaringDate_forSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(65, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel30)
                .addGap(18, 18, 18)
                .addComponent(jLabel31)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ExpenseName_forSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel33)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(StaringDate_forSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel34)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(EndingDate_forSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SearchExpenseButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SortExpenseButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(49, Short.MAX_VALUE))
        );

        RefreshExpnseTableButton.setText("REFRESH TABLE");
        RefreshExpnseTableButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RefreshExpnseTableButtonMouseClicked(evt);
            }
        });

        PaidExpenseSort.setText("PAID");
        PaidExpenseSort.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PaidSort(evt);
            }
        });
        PaidExpenseSort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PaidExpenseSortActionPerformed(evt);
            }
        });

        NotPaidExpenseSort.setText("NOT PAID");
        NotPaidExpenseSort.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                NotPaid(evt);
            }
        });

        AddExpenseShow.setSelected(true);
        AddExpenseShow.setText("ALL");
        AddExpenseShow.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AllExpensive(evt);
            }
        });

        PrintExpense.setBackground(new java.awt.Color(51, 153, 0));
        PrintExpense.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        PrintExpense.setForeground(new java.awt.Color(255, 255, 255));
        PrintExpense.setText("PRINT");
        PrintExpense.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PrintExpenseMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 988, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(55, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(RefreshExpnseTableButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(PaidExpenseSort)
                        .addGap(18, 18, 18)
                        .addComponent(NotPaidExpenseSort)
                        .addGap(18, 18, 18)
                        .addComponent(AddExpenseShow)
                        .addGap(133, 133, 133)
                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(PrintExpense)
                        .addGap(79, 79, 79))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(PaidExpenseSort)
                                                .addComponent(NotPaidExpenseSort)
                                                .addComponent(AddExpenseShow))
                                            .addComponent(RefreshExpnseTableButton))
                                        .addGap(4, 4, 4))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(PrintExpense)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))))
                        .addComponent(jScrollPane5)))
                .addContainerGap())
        );

        jTabbedPane1.addTab("ALL EXPENSIVE", jPanel2);

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        CreditTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Amount", "Date", "Category"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        CreditTable.setRowHeight(30);
        CreditTable.setRowMargin(0);
        CreditTable.setSelectionBackground(new java.awt.Color(232, 57, 95));
        CreditTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        CreditTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CreditTable(evt);
            }
        });
        jScrollPane3.setViewportView(CreditTable);
        if (CreditTable.getColumnModel().getColumnCount() > 0) {
            CreditTable.getColumnModel().getColumn(0).setResizable(false);
            CreditTable.getColumnModel().getColumn(1).setResizable(false);
            CreditTable.getColumnModel().getColumn(2).setResizable(false);
            CreditTable.getColumnModel().getColumn(3).setResizable(false);
            CreditTable.getColumnModel().getColumn(4).setResizable(false);
        }

        jLabel6.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel6.setText("ADD CREDIT");

        jLabel7.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel7.setText("NAME OF CREDIT  : ");

        jLabel8.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel8.setText("AMOUNT : ");

        jLabel9.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel9.setText("CATEGORY : ");

        jLabel10.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel10.setText("DATE : ");

        DeleteCreditButton.setBackground(new java.awt.Color(204, 0, 0));
        DeleteCreditButton.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        DeleteCreditButton.setText("DELETE");
        DeleteCreditButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DeleteCredit(evt);
            }
        });

        AddCreditButton.setBackground(new java.awt.Color(0, 102, 0));
        AddCreditButton.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        AddCreditButton.setText("ADD");
        AddCreditButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddCredit(evt);
            }
        });

        UpdateCreditBtton.setBackground(new java.awt.Color(0, 102, 0));
        UpdateCreditBtton.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        UpdateCreditBtton.setText("UPDATE");
        UpdateCreditBtton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UpdateCredit(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(AddCreditButton, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(DeleteCreditButton, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(UpdateCreditBtton, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(CreditNameField)
                            .addComponent(CreditAmtField)
                            .addComponent(jLabel8)
                            .addComponent(CreditCategoryField)
                            .addComponent(jLabel9)
                            .addComponent(jLabel7)
                            .addComponent(jLabel10)
                            .addComponent(AddingDateFieldOfCredit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(106, 106, 106)
                        .addComponent(jLabel6)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CreditNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CreditAmtField, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CreditCategoryField, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AddingDateFieldOfCredit, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DeleteCreditButton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UpdateCreditBtton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddCreditButton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel11.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        jLabel11.setText("ALL CREDIT");

        jLabel12.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel12.setText("SEARCH DUE TO RECEIVE");

        jLabel14.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel14.setText("NAME OF CREDIT  : ");

        jLabel15.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel15.setText("STARTING DATE : ");

        jLabel16.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel16.setText("ENDING DATE : ");

        jButton14.setBackground(new java.awt.Color(0, 102, 0));
        jButton14.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        jButton14.setText("SEARCH");
        jButton14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchCredit(evt);
            }
        });
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jButton15.setBackground(new java.awt.Color(0, 102, 0));
        jButton15.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        jButton15.setText("SORT");
        jButton15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SortCredit(evt);
            }
        });
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(EndingDate_forSearchCredit, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(StartingDate_forCreditSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel6Layout.createSequentialGroup()
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel6Layout.createSequentialGroup()
                                    .addGap(12, 12, 12)
                                    .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING))
                            .addGap(7, 7, 7))
                        .addComponent(CreditName_forSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CreditName_forSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(StartingDate_forCreditSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(EndingDate_forSearchCredit, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        PrintCredit_record.setBackground(new java.awt.Color(0, 153, 0));
        PrintCredit_record.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        PrintCredit_record.setForeground(new java.awt.Color(255, 255, 255));
        PrintCredit_record.setText("PRINT");
        PrintCredit_record.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PrintCredit_recordMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(PrintCredit_record, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(91, 91, 91))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGap(429, 429, 429)
                                .addComponent(jLabel11))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1032, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(63, Short.MAX_VALUE))))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(PrintCredit_record, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jTabbedPane1.addTab("CREDIT", jPanel8);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        ExpenseTableForPay.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Expensive Name", "Amount", "Date", "Category"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        ExpenseTableForPay.setRowHeight(30);
        ExpenseTableForPay.setSelectionBackground(new java.awt.Color(232, 57, 95));
        ExpenseTableForPay.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                showExpensForPayment(evt);
            }
        });
        jScrollPane1.setViewportView(ExpenseTableForPay);
        if (ExpenseTableForPay.getColumnModel().getColumnCount() > 0) {
            ExpenseTableForPay.getColumnModel().getColumn(0).setResizable(false);
            ExpenseTableForPay.getColumnModel().getColumn(1).setResizable(false);
            ExpenseTableForPay.getColumnModel().getColumn(2).setResizable(false);
            ExpenseTableForPay.getColumnModel().getColumn(3).setResizable(false);
            ExpenseTableForPay.getColumnModel().getColumn(4).setResizable(false);
        }

        PaymentHistoryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Expensive Name", "Amount", "Date", "Category"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                true, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        PaymentHistoryTable.setRowHeight(30);
        PaymentHistoryTable.setSelectionBackground(new java.awt.Color(232, 57, 95));
        jScrollPane2.setViewportView(PaymentHistoryTable);
        if (PaymentHistoryTable.getColumnModel().getColumnCount() > 0) {
            PaymentHistoryTable.getColumnModel().getColumn(0).setResizable(false);
            PaymentHistoryTable.getColumnModel().getColumn(1).setResizable(false);
            PaymentHistoryTable.getColumnModel().getColumn(2).setResizable(false);
            PaymentHistoryTable.getColumnModel().getColumn(3).setResizable(false);
        }

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 18)); // NOI18N
        jLabel2.setText("MAKE PAYMENT");

        jLabel32.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel32.setText("EXPENSIVE TITLE : ");

        jLabel35.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel35.setText("AMOUNT : ");

        jLabel36.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel36.setText("CATEGORY : ");

        jLabel37.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel37.setText("DATE : ");

        PayButton.setBackground(new java.awt.Color(0, 102, 0));
        PayButton.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        PayButton.setText("PAY");
        PayButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Makepayment(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(161, 161, 161))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel32)
                            .addComponent(jLabel35)
                            .addComponent(ExpenseName_forPayField, javax.swing.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE)
                            .addComponent(ExpenseAmt_forPayField))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel36)
                            .addComponent(jLabel37)
                            .addComponent(ExpenseCategory_forPayField)
                            .addComponent(PayingDate, javax.swing.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(193, 193, 193)
                        .addComponent(PayButton)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ExpenseName_forPayField, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel35))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel36)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ExpenseCategory_forPayField, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel37)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ExpenseAmt_forPayField, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                    .addComponent(PayingDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(PayButton)
                .addGap(25, 25, 25))
        );

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI Semilight", 1, 18)); // NOI18N
        jLabel3.setText("RECENT PAYMENT");

        jButton10.setBackground(new java.awt.Color(255, 0, 0));
        jButton10.setText("REMOVE");

        jLabel4.setFont(new java.awt.Font("Yu Gothic UI Semilight", 1, 18)); // NOI18N
        jLabel4.setText("ALL EXPENSIVE");

        jLabel5.setFont(new java.awt.Font("Yu Gothic UI Semilight", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("TO");

        sortExpenseByDateButton_forPay.setBackground(new java.awt.Color(0, 102, 0));
        sortExpenseByDateButton_forPay.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        sortExpenseByDateButton_forPay.setText("SORT");
        sortExpenseByDateButton_forPay.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SortByDate_for_pay(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ByName", "ByCategory" }));

        SearchExpenseButton_forPay.setBackground(new java.awt.Color(0, 102, 0));
        SearchExpenseButton_forPay.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        SearchExpenseButton_forPay.setText("SEARCH");
        SearchExpenseButton_forPay.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchExpense_for_pay(evt);
            }
        });

        Payment_report.setBackground(new java.awt.Color(0, 153, 0));
        Payment_report.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        Payment_report.setForeground(new java.awt.Color(255, 255, 255));
        Payment_report.setText("PRINT");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 458, Short.MAX_VALUE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Payment_report)
                        .addGap(18, 18, 18)
                        .addComponent(jButton10)))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(277, 277, 277)
                        .addComponent(jLabel4))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 899, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SearchExpenseField_forPay, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SearchExpenseButton_forPay)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jDateChooser7, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(3, 3, 3)
                                .addComponent(jDateChooser8, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(sortExpenseByDateButton_forPay)))))
                .addContainerGap(57, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jButton10)
                    .addComponent(Payment_report))
                .addGap(4, 4, 4)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(SearchExpenseField_forPay)
                        .addComponent(jComboBox1)
                        .addComponent(SearchExpenseButton_forPay, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jDateChooser7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jDateChooser8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(sortExpenseByDateButton_forPay)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 505, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane1.addTab("PAYMENT", jPanel5);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jTabbedPane1))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(687, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(40, 40, 40)
                    .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 673, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(15, Short.MAX_VALUE)))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        dispose();
        MainForm m = new MainForm();
        m.show();
    }//GEN-LAST:event_jLabel1MouseClicked

    private void SearchExpensive(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchExpensive
        if (!ExpenseName_forSearch.getText().equals("")) {
            String search = ExpenseName_forSearch.getText();
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "select * from EXPENISES WHERE NAME LIKE '" + search + "'";
                rs = stmt.executeQuery(query);
                model.setNumRows(0);
                while (rs.next()) {
                    String id = rs.getString(1);
                    String Name = rs.getString(2);
                    String Amount = rs.getString(3);
                    String Date = rs.getString(4);
                    String Category = rs.getString(5);
                    String type = rs.getString(6);
                    String PaidDate = rs.getString(7);

                    String tbDate[] = {id, Name, Amount, Date, Category, type, PaidDate};
                    DefaultTableModel tb1Model = (DefaultTableModel) ExpenseMainTable.getModel();
                    tb1Model.addRow(tbDate);
                }
                ExpenseReportQuery = query;
                if (model.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "NO DATA Found....");
                    ExpenseReportQuery = "SELECT *FROM EXPENISES";
                    selection();
                }
                con.close();
            } catch (SQLException e) {
                System.out.println(e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "please Enter name of expensive....");
        }
    }//GEN-LAST:event_SearchExpensive

    private void DeleteExpensive(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeleteExpensive
        String type = "";
        if (Paid.isSelected()) {
            type = "PAID";
        } else {
            type = "NOT PAID";
        }
        try {
            if (!ExpenseNameField.getText().equals("")) {
                Date date1 = ExpenseDateField.getDate();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String strDate1 = dateFormat.format(date1);
                String name = ExpenseNameField.getText();
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                int i = ExpenseMainTable.getSelectedRow();
                String query = "DELETE FROM EXPENISES WHERE ID=" + Integer.parseInt(model.getValueAt(i, 0).toString()) + "";
                stmt.execute(query);
                JOptionPane.showMessageDialog(this, "DELETE SuccessFully...");
                con.close();
                model.setNumRows(0);
                model1.setNumRows(0);
                selection();
                selection1();
                ExpenseNameField.setText("");
                ExpenseAmtField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Please select the expenes you want to delete from table....");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Somting went wrong....");
            System.out.println(e);
        }
    }//GEN-LAST:event_DeleteExpensive

    private void UpdateExpensive(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdateExpensive
        String type = "";
        if (Paid.isSelected()) {
            type = "PAID";
        } else {
            type = "NOT PAID";
        }
        try {
            if (!ExpenseNameField.getText().equals("")) {
                Date date1 = ExpenseDateField.getDate();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String strDate1 = dateFormat.format(date1);
                String name = ExpenseNameField.getText();
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                int i = ExpenseMainTable.getSelectedRow();
                String query = "UPDATE EXPENISES SET NAME='" + ExpenseNameField.getText() + "',AMOUNT=" + ExpenseAmtField.getText() + " WHERE ID=" + Integer.parseInt(model.getValueAt(i, 0).toString()) + "";
                stmt.execute(query);
                JOptionPane.showMessageDialog(this, "Update SuccessFully...");
                con.close();
                model.setNumRows(0);
                model1.setNumRows(0);
                selection();
                selection1();
                ExpenseNameField.setText("");
                ExpenseAmtField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "please Select expens from table...");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Somting went wrong....");
            System.out.println(e);
        }
    }//GEN-LAST:event_UpdateExpensive

    private void AddExpensive(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddExpensive

        try {
            String name = ExpenseNameField.getText();
            String amount = ExpenseAmtField.getText();
            Date date1 = ExpenseDateField.getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyy-MM-dd");
            String strDate1 = dateFormat.format(date1);
            String type = "";
            Date date;

            Admin a = new Admin();
            if (name.equals("") || amount.equals("") || ExpenseDateField.toString().equals("") || a.isValidNumber(amount)) {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT * FROM EXPENISES WHERE NAME='" + name + "' and DATE='" + strDate1 + "' and TYPE='" + type + "'";
                rs = stmt.executeQuery(query);
                if (rs.next()) {
                    query = "UPDATE EXPENISES SET AMOUNT=" + (rs.getInt(3) + Integer.parseInt(amount)) + " WHERE NAME='" + name + "' and DATE='" + strDate1 + "' and TYPE='" + type + "'";
                    stmt.execute(query);
                    JOptionPane.showMessageDialog(this, "EXPENS Update SuccessFully...");
                } else {
                    query = "SELECT MAX(ID) FROM EXPENISES";
                    rs = stmt.executeQuery(query);
                    int maxId = 1;
                    if (rs.next()) {
                        maxId = (Integer) rs.getInt(1) + 1;
                    }
                    if (Paid.isSelected()) {
                        type = "PAID";
                        Date dt1 = new Date();
                        Calendar c = Calendar.getInstance();
                        dt1 = c.getTime();
                        SimpleDateFormat dataformat = new SimpleDateFormat("yyyy-MM-dd");
                        String strDate = dataformat.format(dt1);
                        PreparedStatement Add = con.prepareStatement("insert into EXPENISES (ID,NAME,AMOUNT,DATE,CATEGORY,TYPE,PAIDDATE) Values (" + maxId + ",'" + name + "'," + Integer.parseInt(amount) + ","
                                + "'" + strDate1 + "','General','" + type + "','" + strDate + "')");
                        int row = Add.executeUpdate();
                    } else {
                        type = "NOT PAID";
                        PreparedStatement Add = con.prepareStatement("insert into EXPENISES (ID,NAME,AMOUNT,DATE,CATEGORY,TYPE) Values (" + maxId + ",'" + name + "'," + Integer.parseInt(amount) + ","
                                + "'" + strDate1 + "','General','" + type + "')");
                        int row = Add.executeUpdate();
                    }

                    JOptionPane.showMessageDialog(this, "EXPENS Add SuccessFully...");
                    con.close();
                }
            } else {
                if (!a.isValidNumber(amount)) {
                    JOptionPane.showMessageDialog(this, "Enter valid Amount....");
                }
                if (name.equals("")) {
                    JOptionPane.showMessageDialog(this, "Enter valid Amount....");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Somting went wrong....");
            System.out.println(e);
        }
        model.setNumRows(0);
        model1.setNumRows(0);
        selection();
        selection1();
        ExpenseNameField.setText("");
        ExpenseAmtField.setText("");
    }//GEN-LAST:event_AddExpensive

    private void ShowData(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ShowData
        try {
            int i = ExpenseMainTable.getSelectedRow();
            TableModel model = ExpenseMainTable.getModel();
            ExpenseNameField.setText(model.getValueAt(i, 1).toString());
            ExpenseAmtField.setText(model.getValueAt(i, 2).toString());
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String date = model.getValueAt(i, 3).toString();
            Date dat = dateFormat.parse(date);
            ExpenseDateField.setDate(dat);
            if (model.getValueAt(i, 5).toString().equals("PAID")) {
                Paid.setSelected(true);
                NotPaid.setSelected(false);
            } else {
                Paid.setSelected(false);
                NotPaid.setSelected(true);
            }
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Somting went wrong....");
        }
    }//GEN-LAST:event_ShowData

    private void RefreshExpnseTableButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RefreshExpnseTableButtonMouseClicked
        model.setNumRows(0);
        model1.setNumRows(0);
        selection();

    }//GEN-LAST:event_RefreshExpnseTableButtonMouseClicked

    private void showExpensForPayment(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showExpensForPayment
        int i = ExpenseTableForPay.getSelectedRow();
        TableModel model = ExpenseTableForPay.getModel();
        ExpenseName_forPayField.setText(model.getValueAt(i, 1).toString());
        ExpenseAmt_forPayField.setText(model.getValueAt(i, 2).toString());
        ExpenseCategory_forPayField.setText(model.getValueAt(i, 4).toString());
    }//GEN-LAST:event_showExpensForPayment

    private void AddExpenseButttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddExpenseButttonActionPerformed

    }//GEN-LAST:event_AddExpenseButttonActionPerformed

    private void PaidExpenseSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaidExpenseSortActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PaidExpenseSortActionPerformed

    private void PaidSort(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PaidSort
        PaidExpenseSort.setSelected(true);
        NotPaidExpenseSort.setSelected(false);
        AddExpenseShow.setSelected(false);
        model.setNumRows(0);
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from EXPENISES WHERE TYPE='PAID'";
            rs = stmt.executeQuery(query);

            while (rs.next()) {

                String Name = rs.getString(2);
                String Amount = rs.getString(3);
                String Date = rs.getString(4);
                String Category = rs.getString(5);
                String type = rs.getString(6);
                String PaidDate = rs.getString(7);
                String Id = rs.getString(1);
                String tbDate[] = {Id, Name, Amount, Date, Category, type, PaidDate};
                DefaultTableModel tb1Model = (DefaultTableModel) ExpenseMainTable.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
            ExpenseReportQuery = query;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Somting went wrong....");
            System.out.println(e);
        }
    }//GEN-LAST:event_PaidSort

    private void NotPaid(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NotPaid
        PaidExpenseSort.setSelected(false);
        NotPaidExpenseSort.setSelected(true);
        AddExpenseShow.setSelected(false);
        model.setNumRows(0);
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from EXPENISES WHERE TYPE='NOT PAID'";
            rs = stmt.executeQuery(query);

            while (rs.next()) {

                String Name = rs.getString(2);
                String Amount = rs.getString(3);
                String Date = rs.getString(4);
                String Category = rs.getString(5);
                String type = rs.getString(6);
                String PaidDate = rs.getString(7);
                String Id = rs.getString(1);
                String tbDate[] = {Id, Name, Amount, Date, Category, type, PaidDate};
                DefaultTableModel tb1Model = (DefaultTableModel) ExpenseMainTable.getModel();
                tb1Model.addRow(tbDate);
            }
            ExpenseReportQuery = query;
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Somting went wrong....");
            System.out.println(e);
        }
    }//GEN-LAST:event_NotPaid

    private void AllExpensive(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AllExpensive
        PaidExpenseSort.setSelected(false);
        NotPaidExpenseSort.setSelected(false);
        AddExpenseShow.setSelected(true);
        model.setNumRows(0);
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from EXPENISES ORDER BY DATE";
            rs = stmt.executeQuery(query);

            while (rs.next()) {

                String Name = rs.getString(2);
                String Amount = rs.getString(3);
                String Date = rs.getString(4);
                String Category = rs.getString(5);
                String type = rs.getString(6);
                String PaidDate = rs.getString(7);
                String Id = rs.getString(1);
                String tbDate[] = {Id, Name, Amount, Date, Category, type, PaidDate};
                DefaultTableModel tb1Model = (DefaultTableModel) ExpenseMainTable.getModel();
                tb1Model.addRow(tbDate);
            }
            ExpenseReportQuery = query;
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Somting went wrong....");
            System.out.println(e);
        }
    }//GEN-LAST:event_AllExpensive

    private void NotPaidMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NotPaidMouseClicked
        NotPaid.setSelected(true);
        Paid.setSelected(false);
    }//GEN-LAST:event_NotPaidMouseClicked

    private void PaidMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PaidMouseClicked
        NotPaid.setSelected(false);
        Paid.setSelected(true);
    }//GEN-LAST:event_PaidMouseClicked

    private void sortByDate(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sortByDate
        if (!StaringDate_forSearch.toString().equals("") || !EndingDate_forSearch.toString().equals("")) {
            Date date1 = StaringDate_forSearch.getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate1 = dateFormat.format(date1);
            Date date2 = EndingDate_forSearch.getDate();
            SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
            String strDate2 = dateFormat.format(date2);
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "select * from EXPENISES WHERE DATE BETWEEN '" + strDate1 + "' and '" + strDate2 + "'";
                rs = stmt.executeQuery(query);
                model.setNumRows(0);
                while (rs.next()) {

                    String Name = rs.getString(2);
                    String Amount = rs.getString(3);
                    String Date = rs.getString(4);
                    String Category = rs.getString(5);
                    String type = rs.getString(6);
                    String PaidDate = rs.getString(7);
                    String Id = rs.getString(1);
                    String tbDate[] = {Id, Name, Amount, Date, Category, type, PaidDate};
                    DefaultTableModel tb1Model = (DefaultTableModel) ExpenseMainTable.getModel();
                    tb1Model.addRow(tbDate);
                }
                ExpenseReportQuery = query;
                if (model.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "NO DATA Found....");
                    selection();
                    ExpenseReportQuery = "SELECT * FROM EXPENISES";
                }
                con.close();

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Somting went wrong....");
                System.out.println(e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "please select date ....");
        }
    }//GEN-LAST:event_sortByDate

    private void Makepayment(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Makepayment
        if (ExpenseTableForPay.getSelectedRowCount() != 0) {
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                int i = ExpenseTableForPay.getSelectedRow();
                TableModel modeltable = ExpenseTableForPay.getModel();
                int mainAmt = Integer.parseInt(modeltable.getValueAt(i, 2).toString());
                String name = ExpenseName_forPayField.getText();
                String amount = ExpenseAmt_forPayField.getText();
                String category = ExpenseCategory_forPayField.getText();
                Date date1 = PayingDate.getDate();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyy-MM-dd");
                String strDate1 = dateFormat.format(date1);
                Admin a = new Admin();
                String date = model1.getValueAt(i, 3).toString();
                Date dat = dateFormat.parse(date);
                Date dt1 = new Date();
                Calendar c = Calendar.getInstance();
                dt1 = c.getTime();
                SimpleDateFormat dataformat = new SimpleDateFormat("yyyy-MM-dd");
                String strDate = dataformat.format(dt1);
                int j = ExpenseTableForPay.getSelectedRow();
                if (mainAmt == Integer.parseInt(amount)) {
                    //System.out.println("full pay");
                    String query = "UPDATE EXPENISES SET TYPE='PAID',PAIDDATE='" + strDate + "' WHERE ID=" + Integer.parseInt(model1.getValueAt(j, 0).toString()) + "";

                    stmt.execute(query);
                } else {
                    // System.out.println("half pay");
                    String query = "UPDATE EXPENISES SET AMOUNT=" + (mainAmt - Integer.parseInt(amount)) + " WHERE ID=" + Integer.parseInt(model1.getValueAt(j, 0).toString()) + "";

                    stmt.execute(query);
                    query = "SELECT MAX(ID) FROM EXPENISES";
                    rs = stmt.executeQuery(query);
                    int maxId = 1;
                    if (rs.next()) {
                        maxId = (Integer) rs.getInt(1) + 1;
                    }
                    PreparedStatement Add = con.prepareStatement("insert into EXPENISES (ID,NAME,AMOUNT,DATE,CATEGORY,TYPE,PAIDDATE) Values (" + maxId + ",'" + name + "'," + Integer.parseInt(amount) + ","
                            + "'" + strDate1 + "','General','PAID','" + strDate + "')");
                    int row = Add.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Add successfuly...");
                }
                if (name.equals("") || amount.equals("") || PayingDate.toString().equals("") || a.isValidNumber(amount)) {
                    PreparedStatement Add = con.prepareStatement("insert into PAYMENT_HISTORY (NAME,AMOUNT,DATE,CATEGORY) Values ('" + name + "'," + amount + ",'" + strDate1 + "','" + category + "')");
//                   
                    int row = Add.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Payment SuccessFully...");

                    model.setNumRows(0);
                    model1.setNumRows(0);
                    selection();
                    selection1();
                    ExpenseName_forPayField.setText("");
                    ExpenseAmt_forPayField.setText("");
                    ExpenseCategory_forPayField.setText("");
                } else {
                    if (!a.isValidNumber(amount)) {
                        JOptionPane.showMessageDialog(this, "Enter valid Amount....");
                    }
                    if (name.equals("")) {
                        JOptionPane.showMessageDialog(this, "Enter valid Amount....");
                    }
                }
                selection();
                selection1();
                selection3();
                con.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Somting went wrong....");
                System.out.println(e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "please select expense from table");
        }
    }//GEN-LAST:event_Makepayment

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        Date date = Calendar.getInstance().getTime();
        PayingDate.setDate(date);
    }//GEN-LAST:event_formWindowActivated

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton15ActionPerformed

    private void AddCredit(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddCredit
        try {

            Admin a = new Admin();
            if (CreditNameField.getText().equals("") || CreditCategoryField.getText().equals("") || CreditAmtField.getText().equals("") || AddingDateFieldOfCredit.toString().equals("") || !a.isValidNumber(CreditAmtField.getText())) {
                JOptionPane.showMessageDialog(this, "something went wrong...");

            } else {
                String name = CreditNameField.getText();
                Float Amount = Float.parseFloat(CreditAmtField.getText());
                String category = CreditCategoryField.getText();
                Date date1 = AddingDateFieldOfCredit.getDate();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyy-MM-dd");
                String strDate1 = dateFormat.format(date1);
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT MAX(ID) FROM CREDIT";
                rs = stmt.executeQuery(query);
                rs.next();
                int id = rs.getInt(1) + 1;
                query = "SELECT * FROM CREDIT WHERE NAME='" + name + "' and DATE='" + strDate1 + "'";
                rs = stmt.executeQuery(query);
                if (rs.next()) {
                    query = "UPDATE CREDIT SET AMOUNT=" + (rs.getFloat(3) + Amount) + " WHERE NAME='" + name + "' and DATE='" + strDate1 + "'";
                    stmt.execute(query);
                    JOptionPane.showMessageDialog(this, "Credit Update SuccessFully...");
                } else {

                    PreparedStatement Add = con.prepareStatement("insert into CREDIT (ID,NAME,AMOUNT,DATE,CATEGORY) Values (" + id + ",'" + name + "'," + (double) Amount + ","
                            + "'" + strDate1 + "','" + category + "')");
                    int row = Add.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Add SuccessFully...");
                }
                Creditselection();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Somting went wrong....");
            System.out.println("error in Add Credit");
            Creditselection();
        }


    }//GEN-LAST:event_AddCredit

    private void DeleteCredit(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeleteCredit
        try {
            if (!CreditNameField.getText().equals("")) {
                Date date1 = AddingDateFieldOfCredit.getDate();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String strDate1 = dateFormat.format(date1);
                String name = CreditNameField.getText();
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                int j = CreditTable.getSelectedRow();
                String query = "DELETE FROM CREDIT WHERE ID=" + Integer.parseInt(model3.getValueAt(j, 0).toString()) + "";
                stmt.execute(query);
                JOptionPane.showMessageDialog(this, "DELETE SuccessFully...");
                con.close();
                model3.setNumRows(0);
                Creditselection();
                CreditNameField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Please select the expenes you want to delete from table....");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Somting went wrong....");
            System.out.println(e);
        }
    }//GEN-LAST:event_DeleteCredit

    private void CreditTable(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CreditTable
        try {
            int i = CreditTable.getSelectedRow();
            TableModel model = CreditTable.getModel();
            CreditNameField.setText(model.getValueAt(i, 1).toString());
            CreditAmtField.setText(model.getValueAt(i, 2).toString());
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String date = model.getValueAt(i, 3).toString();
            Date dat = dateFormat.parse(date);
            AddingDateFieldOfCredit.setDate(dat);
            CreditCategoryField.setText(model.getValueAt(i, 4).toString());
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Somting went wrong....");
        }
    }//GEN-LAST:event_CreditTable

    private void UpdateCredit(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdateCredit
        try {
            if (!CreditNameField.getText().equals("")) {
                Date date1 = AddingDateFieldOfCredit.getDate();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String strDate1 = dateFormat.format(date1);
                String name = CreditNameField.getText();
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                int j = CreditTable.getSelectedRow();
                String query = "UPDATE CREDIT SET NAME='" + CreditNameField.getText() + "',AMOUNT=" + CreditAmtField.getText() + " WHERE ID=" + Integer.parseInt(model3.getValueAt(j, 0).toString()) + "";
                stmt.execute(query);
                JOptionPane.showMessageDialog(this, "Update SuccessFully...");
                con.close();
                model3.setNumRows(0);
                Creditselection();
                CreditNameField.setText("");
                CreditAmtField.setText("");
                CreditCategoryField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "please Select expens from table...");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Somting went wrong....");
            System.out.println(e);
        }
    }//GEN-LAST:event_UpdateCredit

    private void SearchCredit(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchCredit
        if (CreditName_forSearch.getText().equals("")) {
            CreditName_forSearch.setBackground(Color.red);
            JOptionPane.showMessageDialog(this, "please Enter name of Credit");
        } else {
            CreditName_forSearch.setBackground(Color.WHITE);
            try {
                String search = CreditName_forSearch.getText();
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "select * from CREDIT WHERE NAME LIKE '" + search + "'";
                rs = stmt.executeQuery(query);
                model3.setNumRows(0);
                while (rs.next()) {

                    String Name = rs.getString(2);
                    String Amount = rs.getString(3);
                    String Date = rs.getString(4);
                    String Category = rs.getString(5);
                    String Id = rs.getString(1);
                    String tbDate[] = {Id, Name, Amount, Date, Category};
                    DefaultTableModel tb1Model = (DefaultTableModel) CreditTable.getModel();
                    tb1Model.addRow(tbDate);
                }
                CreditReportQuery = query;
                if (model3.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "NO DATA Found....");
                    Creditselection();
                    CreditReportQuery = "SELECT * FROM CREDIT";
                }
                con.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Somting went wrong....");
                System.out.println(e);
                Creditselection();
            }

        }
    }//GEN-LAST:event_SearchCredit

    private void SortCredit(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SortCredit
        if (!StartingDate_forCreditSearch.toString().equals("") || !EndingDate_forSearchCredit.toString().equals("")) {
            Date date1 = StartingDate_forCreditSearch.getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate1 = dateFormat.format(date1);
            Date date2 = EndingDate_forSearchCredit.getDate();
            SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
            String strDate2 = dateFormat.format(date2);
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "select * from CREDIT WHERE DATE BETWEEN '" + strDate1 + "' and '" + strDate2 + "'";
                rs = stmt.executeQuery(query);
                model3.setNumRows(0);
                while (rs.next()) {

                    String Name = rs.getString(2);
                    String Amount = rs.getString(3);
                    String Date = rs.getString(4);
                    String Category = rs.getString(5);
                    String Id = rs.getString(1);
                    String tbDate[] = {Id, Name, Amount, Date, Category};
                    DefaultTableModel tb1Model = (DefaultTableModel) CreditTable.getModel();
                    tb1Model.addRow(tbDate);
                }
                CreditReportQuery = query;
                if (model3.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "NO DATA Found....");
                    Creditselection();
                    CreditReportQuery = "SELECT * FROM CREDIT";
                }
                con.close();

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Somting went wrong....");
                System.out.println(e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "please select date ....");
        }
    }//GEN-LAST:event_SortCredit

    private void SearchExpense_for_pay(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchExpense_for_pay
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT * FROM EXPENISES WHERE TYPE='NOT PAID'";
            String search = SearchExpenseField_forPay.getText();
            if (jComboBox1.getSelectedItem().toString().equals("ByCategory")) {
                query = "SELECT * FROM EXPENISES WHERE CATEGORY='" + search + "' and TYPE='NOT PAID'";
            } else if (jComboBox1.getSelectedItem().toString().equals("ByName")) {
                query = "SELECT * FROM EXPENISES WHERE NAME='" + search + "' and TYPE='NOT PAID'";
            }
            rs = stmt.executeQuery(query);
            model1.setNumRows(0);
            while (rs.next()) {

                String Name = rs.getString(2);
                String Amount = rs.getString(3);
                String Date = rs.getString(4);
                String Category = rs.getString(5);
                String Id = rs.getString(1);
                String tbDate[] = {Id, Name, Amount, Date, Category};
                DefaultTableModel tb1Model = (DefaultTableModel) ExpenseTableForPay.getModel();
                tb1Model.addRow(tbDate);
            }
            if (model1.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "NO DATA Found....");
                selection1();
            }
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Somting went wrong....");
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_SearchExpense_for_pay

    private void SortByDate_for_pay(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SortByDate_for_pay
        if (!jDateChooser7.toString().equals("") || !jDateChooser8.toString().equals("")) {
            Date date1 = jDateChooser7.getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate1 = dateFormat.format(date1);
            Date date2 = jDateChooser8.getDate();
            SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
            String strDate2 = dateFormat.format(date2);
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "select * from EXPENISES WHERE DATE BETWEEN '" + strDate1 + "' and '" + strDate2 + "' and TYPE='NOT PAID'";
                rs = stmt.executeQuery(query);
                model1.setNumRows(0);
                while (rs.next()) {

                    String Name = rs.getString(2);
                    String Amount = rs.getString(3);
                    String Date = rs.getString(4);
                    String Category = rs.getString(5);
                    String Id = rs.getString(1);
                    String tbDate[] = {Id, Name, Amount, Date, Category};
                    DefaultTableModel tb1Model = (DefaultTableModel) ExpenseTableForPay.getModel();
                    tb1Model.addRow(tbDate);
                }
                if (model1.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "NO DATA Found....");
                    selection1();
                }
                con.close();

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Somting went wrong....");
                System.out.println(e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "please select date ....");
        }
    }//GEN-LAST:event_SortByDate_for_pay

    private void PrintExpenseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PrintExpenseMouseClicked
        try {
            int sum = 0;
            int i = ExpenseMainTable.getRowCount();
            for (int j = 0; j < i; j++) {
                sum += Integer.parseInt(model.getValueAt(j, 2).toString());
            }
            p.put("TotalAmount", sum);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            JasperDesign jasdi = JRXmlLoader.load("C:\\Users\\moin_pc\\Documents\\NetBeansProjects\\PharmacyDemo\\src\\PharamcyManagementSystem\\ExpenseRecord.jrxml");
            String sql = ExpenseReportQuery;
            JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jasdi.setQuery(newQuery);
            JasperReport js = JasperCompileManager.compileReport(jasdi);
            JasperPrint jp = JasperFillManager.fillReport(js, p, con);
            //JasperViewer.viewReport(jp);
            JasperViewer.viewReport(jp, false);
            p.remove("TotalAmount");
        } catch (JRException ex) {
            System.out.println(ex);
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }//GEN-LAST:event_PrintExpenseMouseClicked

    private void PrintCredit_recordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PrintCredit_recordMouseClicked
        try {
            float sum = 0;
            int i = CreditTable.getRowCount();
            for (int j = 0; j < i; j++) {
                sum += Float.parseFloat(model3.getValueAt(j, 2).toString());
            }
            p.put("TotalAmount", sum);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            JasperDesign jasdi = JRXmlLoader.load("C:\\Users\\moin_pc\\Documents\\NetBeansProjects\\PharmacyDemo\\src\\PharamcyManagementSystem\\CreditRecord.jrxml");
            String sql = CreditReportQuery;
            JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jasdi.setQuery(newQuery);
            JasperReport js = JasperCompileManager.compileReport(jasdi);
            JasperPrint jp = JasperFillManager.fillReport(js, p, con);
            //JasperViewer.viewReport(jp);
            JasperViewer.viewReport(jp, false);
            p.remove("TotalAmount");
        } catch (JRException ex) {
            System.out.println(ex);
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }//GEN-LAST:event_PrintCredit_recordMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Account.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Account.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Account.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Account.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Account().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddCreditButton;
    private javax.swing.JButton AddExpenseButtton;
    private javax.swing.JRadioButton AddExpenseShow;
    private com.toedter.calendar.JDateChooser AddingDateFieldOfCredit;
    private javax.swing.JTextField CreditAmtField;
    private javax.swing.JTextField CreditCategoryField;
    private javax.swing.JTextField CreditNameField;
    private javax.swing.JTextField CreditName_forSearch;
    private javax.swing.JTable CreditTable;
    private javax.swing.JButton DeleteCreditButton;
    private javax.swing.JButton DeleteExpenseButton;
    private com.toedter.calendar.JDateChooser EndingDate_forSearch;
    private com.toedter.calendar.JDateChooser EndingDate_forSearchCredit;
    private javax.swing.JTextField ExpenseAmtField;
    private javax.swing.JTextField ExpenseAmt_forPayField;
    private javax.swing.JTextField ExpenseCategory_forPayField;
    private com.toedter.calendar.JDateChooser ExpenseDateField;
    private javax.swing.JTable ExpenseMainTable;
    private javax.swing.JTextField ExpenseNameField;
    private javax.swing.JTextField ExpenseName_forPayField;
    private javax.swing.JTextField ExpenseName_forSearch;
    private javax.swing.JTable ExpenseTableForPay;
    private javax.swing.JRadioButton NotPaid;
    private javax.swing.JRadioButton NotPaidExpenseSort;
    private javax.swing.JRadioButton Paid;
    private javax.swing.JRadioButton PaidExpenseSort;
    private javax.swing.JButton PayButton;
    private com.toedter.calendar.JDateChooser PayingDate;
    private javax.swing.JTable PaymentHistoryTable;
    private javax.swing.JButton Payment_report;
    private javax.swing.JButton PrintCredit_record;
    private javax.swing.JButton PrintExpense;
    private javax.swing.JButton RefreshExpnseTableButton;
    private javax.swing.JButton SearchExpenseButton;
    private javax.swing.JButton SearchExpenseButton_forPay;
    private javax.swing.JTextField SearchExpenseField_forPay;
    private javax.swing.JButton SortExpenseButton;
    private com.toedter.calendar.JDateChooser StaringDate_forSearch;
    private com.toedter.calendar.JDateChooser StartingDate_forCreditSearch;
    private javax.swing.JButton UpdateCreditBtton;
    private javax.swing.JButton UpdateExpenseButton;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JComboBox<String> jComboBox1;
    private com.toedter.calendar.JDateChooser jDateChooser7;
    private com.toedter.calendar.JDateChooser jDateChooser8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JButton sortExpenseByDateButton_forPay;
    // End of variables declaration//GEN-END:variables
}
