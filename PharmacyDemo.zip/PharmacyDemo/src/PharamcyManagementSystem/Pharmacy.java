package PharamcyManagementSystem;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

public final class Pharmacy extends javax.swing.JFrame {

    DefaultTableModel model, model2, model3, model4;
    int customerID;

    Map<String, Object> p = new HashMap<String, Object>();

    String storeName, Address, Mobile, sellingMedicineReportQuery = "SELECT ID,MED_ID,NAME, QTY,AMOUNT,DATE,SELLINGPRICE,CID FROM SELLINGMEDICINE";
    String CustomerReportQuery = "SELECT ID,NAME,AGE,GENDER,AMOUNT,DATE,CONTACT,QUANTITY FROM CUSTOMER";

    public Pharmacy() {
        initComponents();
        Selection();
        SelectionList();
        countGrossAmt();
        CustomerSelection();
        SellingMedicine_selection();
        getPharmacyDetails();
        model = (DefaultTableModel) AvailableMedicineTable.getModel();
        model2 = (DefaultTableModel) SellMedicineTableForCutomer.getModel();
        model3 = (DefaultTableModel) CutomerTable.getModel();
        model4 = (DefaultTableModel) SellingMedicineTable.getModel();
    }
    Connection con;
    ResultSet rs, rs1;

    public void getPharmacyDetails() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT * FROM REGISTER";
            rs = stmt.executeQuery(query);
            rs.next();
            storeName = rs.getString(4);
            Address = rs.getString(6);
            Mobile = rs.getString(5);
            p.put("StoreName", storeName);
            p.put("Address", Address);
            p.put("Mobile", Mobile);
            p.put("RegisterNo", rs.getString(8));
            con.close();

        } catch (Exception e) {
        }
    }

    void AddCustomer() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            String query = "SELECT * FROM C_MEDICINE_LIST";
            java.sql.Statement stmt = con.createStatement();
            rs = stmt.executeQuery(query);
            int qty = 0;
            while (rs.next()) {
                qty += rs.getInt(4);
            }
            query = "SELECT MAX(ID) FROM CUSTOMER";
            rs = stmt.executeQuery(query);
            int maxId = 1;
            if (rs.next()) {
                maxId = (Integer) rs.getInt(1) + 1;
            }
            Date date1 = sellingDateField.getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate1 = dateFormat.format(date1);
            PreparedStatement Add = con.prepareStatement("insert into CUSTOMER(ID,NAME,AGE,GENDER,AMOUNT,DATE,CONTACT,QUANTITY) VALUES"
                    + "(" + maxId + ",'" + CustomerNameField.getText() + "', " + Integer.parseInt(CustomerAgeField.getText()) + ",'" + GenderField.getSelectedItem().toString() + "'," + (int) Float.parseFloat(TotalAmtField.getText()) + ",'" + strDate1 + "','" + PhoneNumberField.getText() + "'," + qty + ")");

            int row = Add.executeUpdate();
            JOptionPane.showMessageDialog(this, "CUSTOMER Add SuccessFully...");

            con.close();
        } catch (SQLException e) {
            System.out.println("Error in add Customer");
            System.out.println(e);
        }
    }

    ///-----------Customer Selection
    void CustomerSelection() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT * FROM CUSTOMER ORDER BY ID";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                String id = rs.getString(1);
                String Name = rs.getString(2);
                String Age = rs.getString(3);
                String Gender = rs.getString(4);
                String Qty = rs.getString(8);
                String Amt = rs.getString(5);
                String Date = rs.getString(6);
                String Contact = rs.getString(7);

                String tbDate[] = {id, Name, Age, Gender, Qty, Amt, Date, Contact};
                DefaultTableModel tb1Model = (DefaultTableModel) CutomerTable.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();

        } catch (SQLException e) {
            System.out.println("Error in Customer selection");
            System.out.println(e);
        }
    }

    //----------Id and Date Available check
    boolean isAvailableID(int id) {
        boolean check = false;
        try {
            Date date1 = sellingDateField.getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            String strDate1 = dateFormat.format(date1);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT * FROM SELLINGMEDICINE WHERE MED_ID=" + id + " AND DATE='" + strDate1 + "'";
            rs = stmt.executeQuery(query);
            check = rs.next();
            System.out.println(check);
            con.close();
        } catch (SQLException e) {
            System.out.println("Error in Check");
            System.out.println(e);
        }
        return check;
    }

    //------------add selling medicine
    void Add_Sells() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT MAX(ID) FROM SELLINGMEDICINE";
            rs = stmt.executeQuery(query);
            int maxId = 1;
            if (rs.next()) {

                maxId = (Integer) rs.getInt(1);

            }
            query = "SELECT MAX(ID) FROM CUSTOMER";
            rs = stmt.executeQuery(query);
            customerID = 1;
            if (rs.next()) {
                customerID = (Integer) rs.getInt(1);
            }
            query = "SELECT * FROM C_MEDICINE_LIST ORDER BY ID";
            rs = stmt.executeQuery(query);
            Date date1 = sellingDateField.getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate = dateFormat.format(date1);
            while (rs.next()) {
                //getValue From C_MEDICINE_LIST

                int id = rs.getInt(1);
                String Name = rs.getString(2);
                int Qty = rs.getInt(4);
                double Amt = rs.getDouble(5);
                double sellPrice = rs.getDouble(3);

                maxId += 1;
                PreparedStatement Add = con.prepareStatement("insert into SELLINGMEDICINE (ID,MED_ID,NAME,QTY,AMOUNT,DATE,SELLINGPRICE,CID) Values (" + maxId + "," + id + ",'" + Name + "'," + Qty + "," + Amt + ",'" + strDate + "'," + sellPrice + "," + customerID + ")");

                int row = Add.executeUpdate();

            }
            JOptionPane.showMessageDialog(this, "Added Successfuly............");
            query = "SELECT MAX(ID) FROM CREDIT";
            rs = stmt.executeQuery(query);
            int id = 1;
            if (rs.next()) {
                id = rs.getInt(1) + 1;
            }
            PreparedStatement Add = con.prepareStatement("insert into CREDIT (ID,NAME,AMOUNT,DATE,CATEGORY) Values (" + id + ",'" + CustomerNameField.getText() + "'," + Float.parseFloat(TotalAmtField.getText()) + ","
                    + "'" + strDate + "','Customer')");
            int row = Add.executeUpdate();
            JOptionPane.showMessageDialog(this, "Credit Add SuccessFully...");
            con.close();
        } catch (SQLException e) {
            System.out.println("Error in sells...");
            System.out.println(e);
        }
    }

    ///-----------Selling Medicine Selection
    void SellingMedicine_selection() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT * FROM SELLINGMEDICINE ORDER BY ID";
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                String id = rs.getString(1);
                String Med_id = rs.getString(2);
                String Name = rs.getString(3);
                String Qty = rs.getString(4);
                String Amt = rs.getString(5);
                String Date = rs.getString(6);
                String SellPrice = rs.getString(7);
                String CID = rs.getString(8);

                String tbDate[] = {id, Med_id, Name, Qty, Amt, SellPrice, Date, CID};
                DefaultTableModel tb1Model = (DefaultTableModel) SellingMedicineTable.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error in selling medicine selection");
            System.out.println(e);
        }
    }

    //------------------check Medicine by ID
    boolean isAvailable(String id) throws SQLException {
        boolean check = true;
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT ID FROM MEDICINE WHERE ID=" + Integer.parseInt(id) + "";
            rs = stmt.executeQuery(query);
            check = rs.next();
        } catch (SQLException e) {
        }
        return check;
    }

    ///---------Count Total amt
    void countGrossAmt() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT * FROM C_MEDICINE_LIST";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                query = "SELECT SUM(AMOUNT) FROM C_MEDICINE_LIST";
                rs = stmt.executeQuery(query);
                rs.next();
                float amt = Float.parseFloat(rs.getString(1));
                float GST = amt * 18 / 100;
                NetTotalField.setText(Float.toString(amt));
                GstField.setText(Float.toString(GST));
                TotalAmtField.setText(Float.toString(amt + GST));
            }

        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    boolean isAvailableInList(int id) throws SQLException {
        boolean check = true;
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT ID FROM C_MEDICINE_LIST WHERE ID=" + id + "";
            rs = stmt.executeQuery(query);
            check = rs.next();
        } catch (SQLException e) {
        }
        return check;
    }

//-------- add data
    void InsertData(int qty) {
        try {
            float gross = Float.parseFloat(MedicinePriceField.getText()) * qty;
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            PreparedStatement Add = con.prepareStatement("insert into C_MEDICINE_LIST Values (?,?,?,?,?)");
            int i = AvailableMedicineTable.getSelectedRow();
            Add.setString(1, model.getValueAt(i, 0).toString());
            Add.setString(2, MedicineNameField.getText());
            Add.setString(3, MedicinePriceField.getText());
            Add.setString(4, SellingStockField.getText());
            Add.setString(5, Float.toString(gross));
            int row = Add.executeUpdate();
            JOptionPane.showMessageDialog(this, "Medicine Add SuccessFully...");

            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }

    }
//----------Update stock after buying 

    void UpdateAfterBuy_MainTable(int id) {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            int stock = Integer.parseInt(MedicineStockField.getText()) - Integer.parseInt(SellingStockField.getText());
            String query = "UPDATE MEDICINE SET QUANTITY=" + stock + " WHERE ID=" + id + "";
            stmt.execute(query);
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }

    }

    //-----------Number Validation
    boolean isValidNumber(String Number) {
        boolean isValid = true;
        String upperCaseChars = "(.*[A-Z].*)";
        if (Number.matches(upperCaseChars)) {
            isValid = false;
        }
        String lowerCaseChars = "(.*[a-z].*)";
        if (Number.matches(lowerCaseChars)) {
            isValid = false;
        }
        String numbers = "(.*[0-9].*)";
        if (!Number.matches(numbers)) {
            isValid = false;
        }
        String specialChars = "(.*[@,#,$,%].*$)";
        if (Number.matches(specialChars)) {
            isValid = false;
        }
        return isValid;
    }

    void Selection() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from MEDICINE ORDER BY ID";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                String id = rs.getString("ID");
                String Company = rs.getString("CAMPANY");
                String Category = rs.getString("CATEGORY");
                String Name = rs.getString("MEDICINENAME");
                String SellP = rs.getString("SELLINGPRICE");
                String Quantity = rs.getString("QUANTITY");

                String tbDate[] = {id, Company, Category, Name, SellP, Quantity};
                DefaultTableModel tb1Model = (DefaultTableModel) AvailableMedicineTable.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    //---selction list of medicine for customer
    void SelectionList() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from C_MEDICINE_LIST ORDER BY AMOUNT";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                String Id = rs.getString(1);
                String Name = rs.getString("NAME");
                String SellP = rs.getString("PRICE");
                String Quantity = rs.getString("QUANTITY");
                String Amt = rs.getString("AMOUNT");

                String tbDate[] = {Id, Name, SellP, Quantity, Amt};
                DefaultTableModel tb1Model = (DefaultTableModel) SellMedicineTableForCutomer.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        CustomerNameField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        PhoneNumberField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        CustomerAgeField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        GenderField = new javax.swing.JComboBox<>();
        sellingDateField = new com.toedter.calendar.JDateChooser();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        SellMedicineTableForCutomer = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        removeMedicineFromSellButton = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        SellingStockField = new javax.swing.JTextField();
        AddToCart = new javax.swing.JButton();
        MedicineNameField = new javax.swing.JTextField();
        MedicineCategoryField = new javax.swing.JTextField();
        MedicinePriceField = new javax.swing.JTextField();
        MedicineStockField = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        QtyOfMedicineField = new javax.swing.JTextField();
        TotalMedicineCountField = new javax.swing.JTextField();
        NetTotalField = new javax.swing.JTextField();
        GstField = new javax.swing.JTextField();
        TotalAmtField = new javax.swing.JTextField();
        sellMedicineButton = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        SearchModeByNameByID = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        AvailableMedicineTable = new javax.swing.JTable();
        SearchMedicineField = new javax.swing.JTextField();
        searchMedicineButton = new javax.swing.JButton();
        RefreshTableButton = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        SellingMedicineTable = new javax.swing.JTable();
        jLabel21 = new javax.swing.JLabel();
        SearchByNameByIDOption = new javax.swing.JComboBox<>();
        SearchSellingMedButton = new javax.swing.JButton();
        SearchSellingMedField = new javax.swing.JTextField();
        SellsStartingDateField = new com.toedter.calendar.JDateChooser();
        SellsEndingDateField = new com.toedter.calendar.JDateChooser();
        jLabel12 = new javax.swing.JLabel();
        SortingButton = new javax.swing.JButton();
        printSellingMmedicine = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        CutomerTable = new javax.swing.JTable();
        jComboBox4 = new javax.swing.JComboBox<>();
        SearchCustomerButton = new javax.swing.JButton();
        SearchCustomerField = new javax.swing.JTextField();
        StartingDateField = new com.toedter.calendar.JDateChooser();
        EndingDateField = new com.toedter.calendar.JDateChooser();
        jLabel10 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        PrintCustomerRecord = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setName("Pharmacy"); // NOI18N
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Close all jframe.png"))); // NOI18N
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Sitka Text", 0, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("PHARMACY");

        jButton11.setBackground(new java.awt.Color(255, 255, 255));
        jButton11.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jButton11.setText("calc");
        jButton11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                calculator(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        jLabel2.setText("INVOICE");

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        jLabel3.setText("NAME");

        jLabel4.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        jLabel4.setText("CONTACT");

        jLabel5.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        jLabel5.setText("AGE");

        jLabel6.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        jLabel6.setText(" DATE");

        jLabel7.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        jLabel7.setText("GENDER");

        GenderField.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MALE", "FEMALE" }));

        sellingDateField.setDateFormatString("dd/MM/yyyy");
        sellingDateField.setEnabled(false);
        sellingDateField.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N

        jButton1.setBackground(new java.awt.Color(0, 102, 204));
        jButton1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("NEW");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(255, 0, 0));
        jButton2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("DELETE");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(PhoneNumberField)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sellingDateField, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(69, 69, 69))
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(GenderField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(CustomerAgeField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CustomerNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(jTextField1)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CustomerNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(PhoneNumberField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(CustomerAgeField, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sellingDateField, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(GenderField)))
                .addContainerGap())
        );

        jPanel6.setBackground(new java.awt.Color(204, 204, 204));

        SellMedicineTableForCutomer.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Price", "Qty", "Amount"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        SellMedicineTableForCutomer.setGridColor(new java.awt.Color(204, 204, 204));
        SellMedicineTableForCutomer.setSelectionBackground(new java.awt.Color(0, 102, 204));
        jScrollPane1.setViewportView(SellMedicineTableForCutomer);
        if (SellMedicineTableForCutomer.getColumnModel().getColumnCount() > 0) {
            SellMedicineTableForCutomer.getColumnModel().getColumn(0).setResizable(false);
            SellMedicineTableForCutomer.getColumnModel().getColumn(1).setResizable(false);
            SellMedicineTableForCutomer.getColumnModel().getColumn(2).setResizable(false);
            SellMedicineTableForCutomer.getColumnModel().getColumn(3).setResizable(false);
            SellMedicineTableForCutomer.getColumnModel().getColumn(4).setResizable(false);
        }

        jLabel8.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("SELECTED MEDICINE");

        removeMedicineFromSellButton.setBackground(new java.awt.Color(255, 0, 0));
        removeMedicineFromSellButton.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        removeMedicineFromSellButton.setForeground(new java.awt.Color(255, 255, 255));
        removeMedicineFromSellButton.setText("REMOVE");
        removeMedicineFromSellButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                removeMedicineFromSellButtonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(removeMedicineFromSellButton))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(removeMedicineFromSellButton))
                .addGap(2, 2, 2)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
        );

        jLabel11.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("DETAILS");

        jLabel15.setText("NAME : ");

        jLabel16.setText("CATG : ");

        jLabel17.setText("PRICE : ");

        jLabel18.setText("STOCK : ");

        jLabel19.setText("QNT : ");

        AddToCart.setBackground(new java.awt.Color(0, 102, 255));
        AddToCart.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        AddToCart.setForeground(new java.awt.Color(255, 255, 255));
        AddToCart.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/icons8-shopping-cart-25.png"))); // NOI18N
        AddToCart.setText("ADD TO CART");
        AddToCart.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        AddToCart.setIconTextGap(15);
        AddToCart.setInheritsPopupMenu(true);
        AddToCart.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Add_To_cart(evt);
            }
        });

        MedicineNameField.setForeground(new java.awt.Color(0, 102, 0));
        MedicineNameField.setEnabled(false);

        MedicineCategoryField.setForeground(new java.awt.Color(0, 102, 0));
        MedicineCategoryField.setEnabled(false);

        MedicinePriceField.setForeground(new java.awt.Color(0, 102, 0));
        MedicinePriceField.setEnabled(false);

        MedicineStockField.setForeground(new java.awt.Color(0, 102, 0));
        MedicineStockField.setEnabled(false);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(AddToCart, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(MedicineStockField))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel16)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel17)))
                            .addComponent(jLabel19, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(SellingStockField)
                            .addComponent(MedicineNameField)
                            .addComponent(MedicineCategoryField)
                            .addComponent(MedicinePriceField))))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(95, 95, 95))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(MedicineNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(MedicineCategoryField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(MedicinePriceField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(MedicineStockField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(SellingStockField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(AddToCart)
                .addGap(35, 35, 35))
        );

        jLabel27.setText("GST : ");

        jLabel28.setText("BILL PAY : ");

        jLabel24.setText("QTY OF MEDICINE :");

        jLabel25.setText("MEDICINE COUNT :");

        jLabel26.setText("NET TOTAL : ");

        jLabel14.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("BILLING");

        QtyOfMedicineField.setForeground(new java.awt.Color(0, 102, 0));
        QtyOfMedicineField.setEnabled(false);

        TotalMedicineCountField.setForeground(new java.awt.Color(0, 102, 0));
        TotalMedicineCountField.setEnabled(false);

        NetTotalField.setForeground(new java.awt.Color(0, 102, 0));
        NetTotalField.setEnabled(false);

        GstField.setForeground(new java.awt.Color(0, 102, 0));
        GstField.setEnabled(false);

        sellMedicineButton.setBackground(new java.awt.Color(0, 153, 51));
        sellMedicineButton.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        sellMedicineButton.setForeground(new java.awt.Color(255, 255, 255));
        sellMedicineButton.setText("SAVE & PRINT");
        sellMedicineButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Save_and_Print(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(103, 103, 103)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(sellMedicineButton, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel27)
                                    .addComponent(jLabel24))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(TotalMedicineCountField, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(QtyOfMedicineField, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(NetTotalField, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(GstField, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel28)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(TotalAmtField, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel26)
                            .addComponent(jLabel25))))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(QtyOfMedicineField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(TotalMedicineCountField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(NetTotalField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(GstField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(TotalAmtField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addComponent(sellMedicineButton, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        jLabel9.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("RUNNING STOCK");

        SearchModeByNameByID.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ByID", "ByName", "ByCategory" }));

        AvailableMedicineTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Company", "Category", "medicine Name", "Selling Price", "Quantity"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        AvailableMedicineTable.setIntercellSpacing(new java.awt.Dimension(0, 0));
        AvailableMedicineTable.setRowHeight(30);
        AvailableMedicineTable.setSelectionBackground(new java.awt.Color(232, 57, 95));
        AvailableMedicineTable.setShowVerticalLines(false);
        AvailableMedicineTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SetDetail(evt);
            }
        });
        jScrollPane2.setViewportView(AvailableMedicineTable);
        if (AvailableMedicineTable.getColumnModel().getColumnCount() > 0) {
            AvailableMedicineTable.getColumnModel().getColumn(0).setResizable(false);
            AvailableMedicineTable.getColumnModel().getColumn(1).setResizable(false);
            AvailableMedicineTable.getColumnModel().getColumn(2).setResizable(false);
            AvailableMedicineTable.getColumnModel().getColumn(3).setResizable(false);
            AvailableMedicineTable.getColumnModel().getColumn(4).setResizable(false);
            AvailableMedicineTable.getColumnModel().getColumn(5).setResizable(false);
        }

        searchMedicineButton.setBackground(new java.awt.Color(0, 204, 0));
        searchMedicineButton.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        searchMedicineButton.setForeground(new java.awt.Color(255, 255, 255));
        searchMedicineButton.setText("SEARCH");
        searchMedicineButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchMedicineButtonMouseClicked(evt);
            }
        });

        RefreshTableButton.setBackground(new java.awt.Color(0, 204, 0));
        RefreshTableButton.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        RefreshTableButton.setForeground(new java.awt.Color(255, 255, 255));
        RefreshTableButton.setText("REFRESH TABLE");
        RefreshTableButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RefreshTableButtonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(312, 312, 312))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(SearchModeByNameByID, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(SearchMedicineField, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(searchMedicineButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(RefreshTableButton))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 743, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 15, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(SearchModeByNameByID, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                    .addComponent(SearchMedicineField, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(searchMedicineButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(RefreshTableButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 559, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(19, 19, 19))
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("       PHARMACY    ", jPanel2);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        SellingMedicineTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "MED_ID", "Name", "Quantity", "Amount", "SellingPrice", "Date", "CustomerID"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        SellingMedicineTable.setGridColor(new java.awt.Color(102, 204, 255));
        SellingMedicineTable.setIntercellSpacing(new java.awt.Dimension(0, 0));
        SellingMedicineTable.setRowHeight(30);
        SellingMedicineTable.setSelectionBackground(new java.awt.Color(232, 57, 95));
        SellingMedicineTable.setVerifyInputWhenFocusTarget(false);
        jScrollPane4.setViewportView(SellingMedicineTable);
        if (SellingMedicineTable.getColumnModel().getColumnCount() > 0) {
            SellingMedicineTable.getColumnModel().getColumn(0).setResizable(false);
            SellingMedicineTable.getColumnModel().getColumn(1).setResizable(false);
            SellingMedicineTable.getColumnModel().getColumn(2).setResizable(false);
            SellingMedicineTable.getColumnModel().getColumn(3).setResizable(false);
            SellingMedicineTable.getColumnModel().getColumn(4).setResizable(false);
            SellingMedicineTable.getColumnModel().getColumn(5).setResizable(false);
            SellingMedicineTable.getColumnModel().getColumn(6).setResizable(false);
            SellingMedicineTable.getColumnModel().getColumn(7).setResizable(false);
        }

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("SELLING MEDICINE");

        SearchByNameByIDOption.setForeground(new java.awt.Color(0, 102, 0));
        SearchByNameByIDOption.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ByName", "ByID", "ByCustomerID" }));
        SearchByNameByIDOption.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchByNameByIDOptionActionPerformed(evt);
            }
        });

        SearchSellingMedButton.setBackground(new java.awt.Color(0, 51, 204));
        SearchSellingMedButton.setForeground(new java.awt.Color(255, 255, 255));
        SearchSellingMedButton.setText("SEARCH");
        SearchSellingMedButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchSellingMedButtonMouseClicked(evt);
            }
        });

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("TO");

        SortingButton.setBackground(new java.awt.Color(0, 102, 0));
        SortingButton.setText("SORT");
        SortingButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SortByDate_of_SellingMedicine(evt);
            }
        });

        printSellingMmedicine.setBackground(new java.awt.Color(0, 51, 204));
        printSellingMmedicine.setForeground(new java.awt.Color(255, 255, 255));
        printSellingMmedicine.setText("PRINT");
        printSellingMmedicine.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                printSellingMmedicineMouseClicked(evt);
            }
        });
        printSellingMmedicine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printSellingMmedicineActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SearchByNameByIDOption, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchSellingMedField, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchSellingMedButton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(printSellingMmedicine, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(SellsStartingDateField, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(SellsEndingDateField, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SortingButton)
                .addGap(25, 25, 25))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(567, 567, 567)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(580, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SearchByNameByIDOption, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SearchSellingMedButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SearchSellingMedField, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(printSellingMmedicine, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(528, 528, 528))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(SellsStartingDateField, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(SortingButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(SellsEndingDateField, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 519, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        jTabbedPane1.addTab("SELLING MEDICINE", jPanel3);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel20.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("CUSTOMER RECORD");

        CutomerTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Age", "Gender", "Quantity", "Amount", "Date", "Contact"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        CutomerTable.setIntercellSpacing(new java.awt.Dimension(0, 0));
        CutomerTable.setRowHeight(30);
        CutomerTable.setSelectionBackground(new java.awt.Color(232, 57, 95));
        CutomerTable.setShowVerticalLines(false);
        jScrollPane3.setViewportView(CutomerTable);
        if (CutomerTable.getColumnModel().getColumnCount() > 0) {
            CutomerTable.getColumnModel().getColumn(0).setResizable(false);
            CutomerTable.getColumnModel().getColumn(1).setResizable(false);
            CutomerTable.getColumnModel().getColumn(2).setResizable(false);
            CutomerTable.getColumnModel().getColumn(3).setResizable(false);
            CutomerTable.getColumnModel().getColumn(4).setResizable(false);
            CutomerTable.getColumnModel().getColumn(5).setResizable(false);
            CutomerTable.getColumnModel().getColumn(6).setResizable(false);
            CutomerTable.getColumnModel().getColumn(7).setResizable(false);
        }

        jComboBox4.setForeground(new java.awt.Color(0, 102, 0));
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ByID", "ByName" }));

        SearchCustomerButton.setBackground(new java.awt.Color(0, 51, 204));
        SearchCustomerButton.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        SearchCustomerButton.setForeground(new java.awt.Color(255, 255, 255));
        SearchCustomerButton.setText("SEARCH");
        SearchCustomerButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchCustomerButtonMouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("To");

        jButton8.setBackground(new java.awt.Color(0, 153, 51));
        jButton8.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("SORT BY DATE");
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SortByDate_CUSTOMER(evt);
            }
        });

        PrintCustomerRecord.setBackground(new java.awt.Color(0, 51, 204));
        PrintCustomerRecord.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        PrintCustomerRecord.setForeground(new java.awt.Color(255, 255, 255));
        PrintCustomerRecord.setText("PRINT");
        PrintCustomerRecord.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PrintCustomerRecordMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(SearchCustomerField, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchCustomerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PrintCustomerRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 439, Short.MAX_VALUE)
                .addComponent(StartingDateField, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(EndingDateField, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton8)
                .addGap(53, 53, 53))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(575, 575, 575)
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(SearchCustomerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(SearchCustomerField, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(PrintCustomerRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(EndingDateField, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(StartingDateField, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 547, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("   CUSTOMER   ", jPanel4);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 699, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        dispose();
        MainForm m = new MainForm();
        m.show();
    }//GEN-LAST:event_jLabel1MouseClicked

    private void SearchByNameByIDOptionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchByNameByIDOptionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchByNameByIDOptionActionPerformed

    private void searchMedicineButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchMedicineButtonMouseClicked
        if (SearchMedicineField.getText().equals("")) {
            SearchMedicineField.setBackground(Color.red);
        } else {
            SearchMedicineField.setBackground(Color.WHITE);
            String search = SearchMedicineField.getText();
            if (SearchModeByNameByID.getSelectedItem().toString().equals("ByID")) {
                try {
                    if (isValidNumber(SearchMedicineField.getText())) {
                        con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                        java.sql.Statement stmt = con.createStatement();
                        String query = "select * FROM MEDICINE WHERE ID=" + Integer.parseInt(search) + "";
                        rs = stmt.executeQuery(query);
                        model.setNumRows(0);

                        while (rs.next()) {
                            String id = rs.getString("MED_ID");
                            String Company = rs.getString("CAMPANY");
                            String Category = rs.getString("CATEGORY");
                            String Name = rs.getString("MEDICINENAME");
                            String SellP = rs.getString("SELLINGPRICE");
                            String Quantity = rs.getString("QUANTITY");

                            String tbDate[] = {id, Company, Category, Name, SellP, Quantity};
                            DefaultTableModel tb1Model = (DefaultTableModel) AvailableMedicineTable.getModel();

                            tb1Model.addRow(tbDate);

                        }
                        con.close();

                    } else {
                        JOptionPane.showMessageDialog(this, "Enter Valid Id Only Number");
                    }
                } catch (SQLException e) {
                    System.out.println(e);
                }
            } else if (SearchModeByNameByID.getSelectedItem().toString().equals("ByName")) {
                try {
                    con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                    java.sql.Statement stmt = con.createStatement();
                    String query = "SELECT * FROM MEDICINE WHERE MEDICINENAME LIKE '" + search + "'";
                    rs = stmt.executeQuery(query);
                    model.setNumRows(0);
                    while (rs.next()) {
                        //if (rs.getString(5).toLowerCase().equals(SearchMedicineField.getText().toLowerCase())) {
                        String id = rs.getString("MED_ID");
                        String Company = rs.getString("CAMPANY");
                        String Category = rs.getString("CATEGORY");
                        String Name = rs.getString("MEDICINENAME");
                        String SellP = rs.getString("SELLINGPRICE");
                        String Quantity = rs.getString("QUANTITY");

                        String tbDate[] = {id, Company, Category, Name, SellP, Quantity};
                        DefaultTableModel tb1Model = (DefaultTableModel) AvailableMedicineTable.getModel();

                        tb1Model.addRow(tbDate);
                        // }

                    }
                    con.close();
                    if (AvailableMedicineTable.getRowCount() == 0) {
                        JOptionPane.showMessageDialog(this, "No Data Found ...");
                        Selection();
                    }
                } catch (SQLException e) {
                    System.out.println(e);
                }
            }
        }

    }//GEN-LAST:event_searchMedicineButtonMouseClicked

    private void RefreshTableButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RefreshTableButtonMouseClicked
        model.setNumRows(0);
        Selection();
    }//GEN-LAST:event_RefreshTableButtonMouseClicked

    private void SetDetail(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SetDetail
        if (AvailableMedicineTable.getSelectedRowCount() == 1) {
            int i = AvailableMedicineTable.getSelectedRow();
            MedicineNameField.setText(model.getValueAt(i, 3).toString());
            MedicineCategoryField.setText(model.getValueAt(i, 2).toString());
            MedicinePriceField.setText(model.getValueAt(i, 4).toString());
            MedicineStockField.setText(model.getValueAt(i, 5).toString());
            SellingStockField.setText(model.getValueAt(i, 5).toString());
        } else {
            JOptionPane.showMessageDialog(this, "Please selction valid ....");
        }
    }//GEN-LAST:event_SetDetail

    private void Add_To_cart(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Add_To_cart

        try {
            int i = AvailableMedicineTable.getSelectedRowCount();
            int i1 = AvailableMedicineTable.getSelectedRow();
            int id = Integer.parseInt(model.getValueAt(i1, 0).toString());
            if (isAvailableInList(id)) {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT * FROM C_MEDICINE_LIST WHERE ID=" + id + "";
                rs = stmt.executeQuery(query);
                rs.next();
                int qty = rs.getInt(4);
                int qtyForBuy = Integer.parseInt(SellingStockField.getText());
                qty += qtyForBuy;
                float gross = qty * Float.parseFloat(MedicinePriceField.getText());
                query = "UPDATE C_MEDICINE_LIST SET QUANTITY=" + qty + ",AMOUNT=" + gross + " WHERE ID=" + id + "";
                stmt.execute(query);
                UpdateAfterBuy_MainTable(id);
            } else {
                if (i == 1) {
                    if (Integer.parseInt(MedicineStockField.getText()) >= Integer.parseInt(SellingStockField.getText())) {
                        try {
                            int quntity = Integer.parseInt(MedicineStockField.getText());
                            int BuyingQty = Integer.parseInt(SellingStockField.getText());
                            quntity -= BuyingQty;
                            InsertData(Integer.parseInt(SellingStockField.getText()));
                            UpdateAfterBuy_MainTable(id);
                        } catch (Exception e) {

                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "less stock.....");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Please Select Row..");
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
            System.out.println("Error in add to cart");
        }
        model2.setNumRows(0);
        model.setNumRows(0);
        Selection();
        SelectionList();

        //--------------===========Billing==========---------------------------
        countGrossAmt();
    }//GEN-LAST:event_Add_To_cart

    private void removeMedicineFromSellButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_removeMedicineFromSellButtonMouseClicked
        int i = SellMedicineTableForCutomer.getSelectedRow();
        int i1 = SellMedicineTableForCutomer.getSelectedRowCount();
        if (i1 == 1) {
            try {
                int id = Integer.parseInt(model2.getValueAt(i, 0).toString());
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT * FROM C_MEDICINE_LIST WHERE MED_ID=" + id + "";
                rs = stmt.executeQuery(query);
                rs.next();
                int qty = rs.getInt(4);
                query = "SELECT * FROM MEDICINE WHERE MED_ID=" + id + "";
                rs = stmt.executeQuery(query);
                rs.next();
                int qty1 = rs.getInt(7);
//                System.out.println(qty + "  " + qty1);
                query = "UPDATE MEDICINE SET QUANTITY=" + (qty1 + qty) + " WHERE MED_ID=" + id + "";
                stmt.execute(query);
                query = "DELETE FROM C_MEDICINE_LIST WHERE MED_ID=" + id + "";
                stmt.execute(query);
            } catch (SQLException e) {
                System.out.println(e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please Select Row..");
        }
        model2.setNumRows(0);
        model.setNumRows(0);
        Selection();
        SelectionList();
        countGrossAmt();
    }//GEN-LAST:event_removeMedicineFromSellButtonMouseClicked

    //save customer details and bills
    private void Save_and_Print(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Save_and_Print
        Admin a = new Admin();
        if (a.isValidString(CustomerNameField.getText()) && !CustomerNameField.getText().equals("")) {
            CustomerNameField.setBackground(Color.WHITE);
            if (a.isValidNumber(PhoneNumberField.getText()) && PhoneNumberField.getText().length() == 10) {
                PhoneNumberField.setBackground(Color.WHITE);
                if (a.isValidNumber(CustomerAgeField.getText())) {
                    CustomerAgeField.setBackground(Color.WHITE);

                    /// -----------Insert Data of Customer
                    AddCustomer();
                    model3.setNumRows(0);
                    CustomerSelection();

                    //------------Add Selling Medicine 
                    model4.setNumRows(0);
                    Add_Sells();
                    SellingMedicine_selection();

                    try {
                        con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                        java.sql.Statement stmt = con.createStatement();
                        String query = "SELECT * FROM CUSTOMER ORDER BY ID DESC FETCH FIRST 1 ROWS ONLY";
                        getPharmacyDetails();
                        rs = stmt.executeQuery(query);
                        rs.next();
                        p.clear();
                        p.put("C_Name", rs.getString(2));
                        p.put("C_Age", rs.getString(3));
                        p.put("C_Gender", rs.getString(4));
                        p.put("C_Contact", rs.getString(7));
                        p.put("C_Id", rs.getString(1));
                        p.put("Total", NetTotalField.getText());
                        p.put("Gst", GstField.getText());
                        p.put("Pay", TotalAmtField.getText());
                        con.close();
                        getPharmacyDetails();
                        con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                        JasperDesign jasdi = JRXmlLoader.load("C:\\Users\\moin_pc\\Documents\\NetBeansProjects\\PharmacyDemo\\src\\PharamcyManagementSystem\\C_Invoice.jrxml");
                        String sql = "SELECT * FROM C_MEDICINE_LIST";
                        JRDesignQuery newQuery = new JRDesignQuery();
                        newQuery.setText(sql);
                        jasdi.setQuery(newQuery);
                        JasperReport js = JasperCompileManager.compileReport(jasdi);
                        JasperPrint jp = JasperFillManager.fillReport(js, p, con);
                        JasperViewer.viewReport(jp, false);
                    } catch (JRException ex) {
                        System.out.println(ex);
                    } catch (SQLException ex) {
                        System.out.println(ex);
                    }

                    //------------After Print Bill delete The Medicine from C_MEDICINE_LIST TABLE
                    try {
                        con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                        java.sql.Statement stmt = con.createStatement();
                        String query = "DELETE FROM C_MEDICINE_LIST";
                        stmt.execute(query);
                        JOptionPane.showMessageDialog(this, "Deleted.....");
                        model2.setNumRows(0);
                        SelectionList();

                    } catch (SQLException e) {
                        System.out.println(e);
                    }
                    CustomerNameField.setText("");
                    PhoneNumberField.setText("");
                    CustomerAgeField.setText("");

                } else {
                    CustomerAgeField.setBackground(Color.red);
                    JOptionPane.showMessageDialog(this, "Please Enter Valid Age....");
                }
            } else {
                PhoneNumberField.setBackground(Color.red);
                JOptionPane.showMessageDialog(this, "Please Enter Valid MobileNumber....");
            }
        } else {
            CustomerNameField.setBackground(Color.red);
            JOptionPane.showMessageDialog(this, "Please Enter Valid Name....");
        }

    }//GEN-LAST:event_Save_and_Print

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        Date date = Calendar.getInstance().getTime();
        sellingDateField.setDate(date);
    }//GEN-LAST:event_formWindowActivated

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        System.out.println(sellingDateField.getDate().toString());
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        System.out.println(isAvailableID(1));
        System.out.println(isAvailableID(24));
        System.out.println(isAvailableID(11));
    }//GEN-LAST:event_jButton1MouseClicked

    private void calculator(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_calculator
        calculator c = new calculator();
        c.show();
    }//GEN-LAST:event_calculator

    private void SearchSellingMedButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchSellingMedButtonMouseClicked
        try {
            String type = SearchByNameByIDOption.getSelectedItem().toString();
            String search = SearchSellingMedField.getText();
            try {
                model4.setNumRows(0);
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT * FROM SELLINGMEDICINE";

                if (type.equals("ByName")) {
                    query = "SELECT * FROM SELLINGMEDICINE WHERE NAME LIKE '" + search + "'";
                } else if (type.equals("ByID")) {
                    query = "SELECT * FROM SELLINGMEDICINE WHERE MED_ID=" + search + "";
                } else if (type.equals("ByCustomerID")) {
                    query = "SELECT * FROM SELLINGMEDICINE WHERE CID=" + Integer.parseInt(search) + "";
                } else {
                    JOptionPane.showMessageDialog(this, "Please Enter Data....");
                }
                rs = stmt.executeQuery(query);

                while (rs.next()) {
                    String id=rs.getString(1);
                    String Med_id = rs.getString(2);
                    String Name = rs.getString(3);
                    String Qty = rs.getString(4);
                    String Amt = rs.getString(5);
                    String Date = rs.getString(6);
                    String SellPrice = rs.getString(7);
                    String CID = rs.getString(8);

                    String tbDate[] = {id, Med_id, Name, Qty, Amt, SellPrice, Date, CID};
                    DefaultTableModel tb1Model = (DefaultTableModel) SellingMedicineTable.getModel();
                    tb1Model.addRow(tbDate);
                }
                sellingMedicineReportQuery = query;
                con.close();

            } catch (SQLException e) {
                System.out.println(e);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Somthing Went Wrong......");
            SellingMedicine_selection();
        }
        if (SellingMedicineTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Data Not Found.....");
            SellingMedicine_selection();
        }
    }//GEN-LAST:event_SearchSellingMedButtonMouseClicked

    private void SearchCustomerButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchCustomerButtonMouseClicked
        try {
            String type = jComboBox4.getSelectedItem().toString();
            String search = SearchCustomerField.getText();
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT * FROM CUSTOMER";
                model3.setNumRows(0);

                if (type.equals("ByName")) {
                    query = "SELECT * FROM CUSTOMER WHERE NAME LIKE '" + search + "'";
                } else if (type.equals("ByID")) {
                    query = "SELECT * FROM CUSTOMER WHERE ID=" + Integer.parseInt(search) + "";
                } else {
                    JOptionPane.showMessageDialog(this, "Please Enter Data....");
                }
                rs = stmt.executeQuery(query);

                while (rs.next()) {
                    String id = rs.getString(1);
                    String Name = rs.getString(2);
                    String Age = rs.getString(3);
                    String Gender = rs.getString(4);
                    String Qty = rs.getString(8);
                    String Amt = rs.getString(5);
                    String Date = rs.getString(6);
                    String Contact = rs.getString(7);

                    String tbDate[] = {id, Name, Age, Gender, Qty, Amt, Date, Contact};
                    DefaultTableModel tb1Model = (DefaultTableModel) CutomerTable.getModel();
                    tb1Model.addRow(tbDate);
                }
                CustomerReportQuery = query;
                con.close();

            } catch (SQLException e) {
                System.out.println(e);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Somthing Went Wrong......");
            CustomerSelection();
        }
    }//GEN-LAST:event_SearchCustomerButtonMouseClicked

    private void SortByDate_of_SellingMedicine(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SortByDate_of_SellingMedicine
        if (!SellsStartingDateField.toString().equals("") || !SellsEndingDateField.toString().equals("")) {
            Date date1 = SellsStartingDateField.getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate1 = dateFormat.format(date1);
            Date date2 = SellsEndingDateField.getDate();
            SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
            String strDate2 = dateFormat.format(date2);
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "select * from SELLINGMEDICINE WHERE DATE BETWEEN '" + strDate1 + "' and '" + strDate2 + "'";
                rs = stmt.executeQuery(query);
                model4.setNumRows(0);
                while (rs.next()) {
                    String id=rs.getString(1);
                    String Med_id = rs.getString(2);
                    String Name = rs.getString(3);
                    String Qty = rs.getString(4);
                    String Amt = rs.getString(5);
                    String Date = rs.getString(6);
                    String SellPrice = rs.getString(7);
                    String CID = rs.getString(8);

                    String tbDate[] = {id, Med_id, Name, Qty, Amt, SellPrice, Date, CID};
                    DefaultTableModel tb1Model = (DefaultTableModel) SellingMedicineTable.getModel();
                    tb1Model.addRow(tbDate);
                }
                if (model4.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "NO DATA Found....");
                    SellingMedicine_selection();
                }
                sellingMedicineReportQuery = query;
                con.close();

            } catch (SQLException e) {
                System.out.println(e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "please select date ....");
        }
    }//GEN-LAST:event_SortByDate_of_SellingMedicine

    private void SortByDate_CUSTOMER(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SortByDate_CUSTOMER
        if (!StartingDateField.toString().equals("") || !EndingDateField.toString().equals("")) {
            Date date1 = StartingDateField.getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate1 = dateFormat.format(date1);
            Date date2 = EndingDateField.getDate();
            SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
            String strDate2 = dateFormat.format(date2);
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "select * from CUSTOMER WHERE DATE BETWEEN '" + strDate1 + "' and '" + strDate2 + "'";
                rs = stmt.executeQuery(query);
                model3.setNumRows(0);
                while (rs.next()) {
                    String id = rs.getString(1);
                    String Name = rs.getString(2);
                    String Age = rs.getString(3);
                    String Gender = rs.getString(4);
                    String Qty = rs.getString(8);
                    String Amt = rs.getString(5);
                    String Date = rs.getString(6);
                    String Contact = rs.getString(7);

                    String tbDate[] = {id, Name, Age, Gender, Qty, Amt, Date, Contact};
                    DefaultTableModel tb1Model = (DefaultTableModel) CutomerTable.getModel();
                    tb1Model.addRow(tbDate);
                }
                if (model3.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "NO DATA Found....");
                    CustomerSelection();
                }
                CustomerReportQuery = query;
                con.close();

            } catch (SQLException e) {
                System.out.println(e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "please select date ....");
        }
    }//GEN-LAST:event_SortByDate_CUSTOMER

    private void PrintCustomerRecordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PrintCustomerRecordMouseClicked

        try {
             float sum=0,qtySum=0;
            int i=CutomerTable.getRowCount();
            for(int j=0;j<i;j++){
               sum+=Float.parseFloat(model3.getValueAt(j, 5).toString());
               qtySum+=Float.parseFloat(model3.getValueAt(j, 4).toString());
            }
            p.put("TotalAmount", sum);
            p.put("Qty", qtySum);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            JasperDesign jasdi = JRXmlLoader.load("C:\\Users\\moin_pc\\Documents\\NetBeansProjects\\PharmacyDemo\\src\\PharamcyManagementSystem\\customerRecord.jrxml");
            String sql = CustomerReportQuery;
            JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jasdi.setQuery(newQuery);
            JasperReport js = JasperCompileManager.compileReport(jasdi);
            JasperPrint jp = JasperFillManager.fillReport(js, p, con);
            JasperViewer.viewReport(jp, false);
            p.remove("TotalAmount");
            p.remove("Qty");
        } catch (JRException ex) {
            System.out.println(ex);
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }//GEN-LAST:event_PrintCustomerRecordMouseClicked

    private void printSellingMmedicineMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_printSellingMmedicineMouseClicked
        try {
            float sum=0,qtySum=0;
            int i=SellingMedicineTable.getRowCount();
            for(int j=0;j<i;j++){
               sum+=Float.parseFloat(model4.getValueAt(j, 4).toString());
               qtySum+=Float.parseFloat(model4.getValueAt(j, 3).toString());
            }
            p.put("TotalAmount", sum);
            p.put("Qty", qtySum);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            JasperDesign jasdi = JRXmlLoader.load("C:\\Users\\moin_pc\\Documents\\NetBeansProjects\\PharmacyDemo\\src\\PharamcyManagementSystem\\SellingMedicine.jrxml");
            String sql = sellingMedicineReportQuery;
            JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jasdi.setQuery(newQuery);
            JasperReport js = JasperCompileManager.compileReport(jasdi);
            JasperPrint jp = JasperFillManager.fillReport(js, p, con);
            JasperViewer.viewReport(jp, false);
            p.remove("TotalAmount");
            p.remove("Qty");

        } catch (JRException ex) {
            System.out.println(ex);
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }//GEN-LAST:event_printSellingMmedicineMouseClicked

    private void printSellingMmedicineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printSellingMmedicineActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_printSellingMmedicineActionPerformed

    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Pharmacy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Pharmacy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Pharmacy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Pharmacy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Pharmacy().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddToCart;
    private javax.swing.JTable AvailableMedicineTable;
    private javax.swing.JTextField CustomerAgeField;
    private javax.swing.JTextField CustomerNameField;
    private javax.swing.JTable CutomerTable;
    private com.toedter.calendar.JDateChooser EndingDateField;
    private javax.swing.JComboBox<String> GenderField;
    private javax.swing.JTextField GstField;
    private javax.swing.JTextField MedicineCategoryField;
    private javax.swing.JTextField MedicineNameField;
    private javax.swing.JTextField MedicinePriceField;
    private javax.swing.JTextField MedicineStockField;
    private javax.swing.JTextField NetTotalField;
    private javax.swing.JTextField PhoneNumberField;
    private javax.swing.JButton PrintCustomerRecord;
    private javax.swing.JTextField QtyOfMedicineField;
    private javax.swing.JButton RefreshTableButton;
    private javax.swing.JComboBox<String> SearchByNameByIDOption;
    private javax.swing.JButton SearchCustomerButton;
    private javax.swing.JTextField SearchCustomerField;
    private javax.swing.JTextField SearchMedicineField;
    private javax.swing.JComboBox<String> SearchModeByNameByID;
    private javax.swing.JButton SearchSellingMedButton;
    private javax.swing.JTextField SearchSellingMedField;
    private javax.swing.JTable SellMedicineTableForCutomer;
    private javax.swing.JTable SellingMedicineTable;
    private javax.swing.JTextField SellingStockField;
    private com.toedter.calendar.JDateChooser SellsEndingDateField;
    private com.toedter.calendar.JDateChooser SellsStartingDateField;
    private javax.swing.JButton SortingButton;
    private com.toedter.calendar.JDateChooser StartingDateField;
    private javax.swing.JTextField TotalAmtField;
    private javax.swing.JTextField TotalMedicineCountField;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton8;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton printSellingMmedicine;
    private javax.swing.JButton removeMedicineFromSellButton;
    private javax.swing.JButton searchMedicineButton;
    private javax.swing.JButton sellMedicineButton;
    private com.toedter.calendar.JDateChooser sellingDateField;
    // End of variables declaration//GEN-END:variables
}
