package PharamcyManagementSystem;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public final class DAILY extends javax.swing.JFrame {

    public DAILY() {
        initComponents();
        selection();
        model = (DefaultTableModel) DailyCustomer_Table.getModel();
        model1 = (DefaultTableModel) jTable1.getModel();
        model2 = (DefaultTableModel) DailyExpenseTable.getModel();
        model3 = (DefaultTableModel) DailyCreditTable.getModel();
        model4 = (DefaultTableModel) Sellingmedicine_table.getModel();
        model5 = (DefaultTableModel) DailyCustomer_Table.getModel();
        ExpenseSelection();
        CreditSelection();
        SellingMedicine_selection();
        CustomerSelection();
    }
    Connection con;
    ResultSet rs;
    DefaultTableModel model, model1, model2, model3, model4, model5;

    //-----------------show data
    void selection() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            Date date = Calendar.getInstance().getTime();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate1 = dateFormat.format(date);
            String query = "select * from MEDICINE WHERE DATE='" + strDate1 + "'";
            System.out.println(strDate1);
            rs = stmt.executeQuery(query);
            while (rs.next()) {

                String id = rs.getString("MED_ID");
                String Company = rs.getString("CAMPANY");
                String Category = rs.getString("CATEGORY");
                String Name = rs.getString("MEDICINENAME");
                String BuyP = rs.getString("BUYINGPRICE");
                String SellP = rs.getString("SELLINGPRICE");
                String Quantity = rs.getString("QUANTITY");
                String Date = rs.getString("DATE");

                String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date};
                DefaultTableModel tb1Model = (DefaultTableModel) jTable1.getModel();
                tb1Model.addRow(tbDate);

            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    //Daily selling Medicine data
    void SellingMedicine_selection() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate = dateFormat.format(date);
            String query = "SELECT * FROM SELLINGMEDICINE WHERE DATE='" + strDate + "' ORDER BY ID";
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                String id = rs.getString(2);
                String Name = rs.getString(3);
                String Qty = rs.getString(4);
                String Amt = rs.getString(5);
                String Date = rs.getString(6);
                String SellPrice = rs.getString(7);
                String CID = rs.getString(8);

                String tbDate[] = {id, Name, Qty, Amt, SellPrice, Date, CID};
                DefaultTableModel tb1Model = (DefaultTableModel) Sellingmedicine_table.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println("Error in selling medicine selection");
            System.out.println(e);
        }
    }

    //Daily Customer data
    void CustomerSelection() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate = dateFormat.format(date);
            String query = "SELECT * FROM CUSTOMER WHERE DATE='" + strDate + "' ORDER BY ID";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                String id = rs.getString(1);
                String Name = rs.getString(2);
                String Age = rs.getString(3);
                String Gender = rs.getString(4);
                String Qty = rs.getString(8);
                String Amt = rs.getString(5);
                String Date = rs.getString(6);
                String Contact = rs.getString(7);

                String tbDate[] = {id, Name, Age, Gender, Qty, Amt, Date, Contact};
                DefaultTableModel tb1Model = (DefaultTableModel) DailyCustomer_Table.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();

        } catch (SQLException e) {
            System.out.println("Error in Customer selection");
            System.out.println(e);
        }
    }

    ///---------------show All Expenses
    void ExpenseSelection() {
        PAID_Expense_sort.setSelected(false);
        Not_PAID_Expense_sort1.setSelected(false);
        AllExpenseSort.setSelected(true);
        model2.setNumRows(0);
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate = dateFormat.format(date);
            String query = "select * from EXPENISES WHERE DATE='" + strDate + "'";
            rs = stmt.executeQuery(query);

            while (rs.next()) {

                String Name = rs.getString(2);
                String Amount = rs.getString(3);
                String Date = rs.getString(4);
                String Category = rs.getString(5);

                String tbDate[] = {Name, Amount, Date, Category};
                DefaultTableModel tb1Model = (DefaultTableModel) DailyExpenseTable.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    //credit data selection
    void CreditSelection() {
        PAID_Expense_sort.setSelected(false);
        Not_PAID_Expense_sort1.setSelected(false);
        AllExpenseSort.setSelected(true);
        model2.setNumRows(0);
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate = dateFormat.format(date);
            String query = "select * from CREDIT WHERE DATE='" + strDate + "'";
            rs = stmt.executeQuery(query);

            while (rs.next()) {

                String Name = rs.getString(2);
                String Amount = rs.getString(3);
                String Date = rs.getString(4);
                String Category = rs.getString(5);

                String tbDate[] = {Name, Amount, Date, Category};
                DefaultTableModel tb1Model = (DefaultTableModel) DailyCreditTable.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    //----number validation
    boolean isValidNumber(String Number) {
        boolean isValid = true;
        String upperCaseChars = "(.*[A-Z].*)";
        if (Number.matches(upperCaseChars)) {
            isValid = false;
        }
        String lowerCaseChars = "(.*[a-z].*)";
        if (Number.matches(lowerCaseChars)) {
            isValid = false;
        }
        String numbers = "(.*[0-9].*)";
        if (!Number.matches(numbers)) {
            isValid = false;
        }
        String specialChars = "(.*[@,#,$,%].*$)";
        if (Number.matches(specialChars)) {
            isValid = false;
        }
        return isValid;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel6 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jButton13 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton12 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        DailyExpenseTable = new javax.swing.JTable();
        SearchExpense_Field = new javax.swing.JTextField();
        SearchExpense_Button = new javax.swing.JButton();
        PAID_Expense_sort = new javax.swing.JRadioButton();
        Not_PAID_Expense_sort1 = new javax.swing.JRadioButton();
        AllExpenseSort = new javax.swing.JRadioButton();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        DailyCustomer_Table = new javax.swing.JTable();
        jLabel45 = new javax.swing.JLabel();
        SearchCustomer_comboBox = new javax.swing.JComboBox<>();
        SearchCustomer_textField = new javax.swing.JTextField();
        SearchCustomer_button = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jLabel46 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        DailyCreditTable = new javax.swing.JTable();
        SearchCredit_button = new javax.swing.JButton();
        SearchCredit_textField = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        Sellingmedicine_table = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        SearchSellingMedicine_ComboBox = new javax.swing.JComboBox<>();
        SearchSellingMedicine_TextField = new javax.swing.JTextField();
        SearchSellingMedicine_button = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jLabel47.setFont(new java.awt.Font("Sitka Text", 0, 18)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel47.setText("DAILY");

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Close all jframe.png"))); // NOI18N
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel47, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
        );

        jTabbedPane3.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane3.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        jTabbedPane3.setInheritsPopupMenu(true);
        jTabbedPane3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane3MouseClicked(evt);
            }
        });

        jPanel6.setBackground(new java.awt.Color(204, 204, 204));

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));

        jLabel41.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel41.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel41.setText("DAILY PURCHASE HISTORY");

        jButton13.setBackground(new java.awt.Color(0, 102, 204));
        jButton13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton13.setForeground(new java.awt.Color(255, 255, 255));
        jButton13.setText("PRINT");

        jTable1.setAutoCreateRowSorter(true);
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Company", "Category", "Medicine Name", "Buying Price", "Selling price", "Quantity", "Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setColumnSelectionAllowed(true);
        jTable1.setFocusCycleRoot(true);
        jTable1.setGridColor(new java.awt.Color(0, 204, 255));
        jTable1.setIntercellSpacing(new java.awt.Dimension(0, 0));
        jTable1.setRowHeight(30);
        jTable1.setSelectionBackground(new java.awt.Color(232, 57, 95));
        jTable1.setShowVerticalLines(false);
        jScrollPane1.setViewportView(jTable1);
        jTable1.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
            jTable1.getColumnModel().getColumn(5).setResizable(false);
            jTable1.getColumnModel().getColumn(6).setResizable(false);
            jTable1.getColumnModel().getColumn(7).setResizable(false);
        }

        jButton12.setBackground(new java.awt.Color(0, 102, 0));
        jButton12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton12.setForeground(new java.awt.Color(255, 255, 255));
        jButton12.setText("Refresh Table");
        jButton12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton12MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton13)
                .addGap(45, 45, 45))
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap(660, Short.MAX_VALUE)
                .addComponent(jLabel41)
                .addGap(479, 479, 479))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(0, 19, Short.MAX_VALUE)
                        .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane3.addTab("DAILY MEDICINE", jPanel6);

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));

        jLabel23.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("DAILY EXPENSIVE");

        DailyExpenseTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Amount", "Date", "Category"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        DailyExpenseTable.setRowHeight(30);
        DailyExpenseTable.setSelectionBackground(new java.awt.Color(232, 57, 95));
        jScrollPane4.setViewportView(DailyExpenseTable);
        if (DailyExpenseTable.getColumnModel().getColumnCount() > 0) {
            DailyExpenseTable.getColumnModel().getColumn(0).setResizable(false);
            DailyExpenseTable.getColumnModel().getColumn(1).setResizable(false);
            DailyExpenseTable.getColumnModel().getColumn(2).setResizable(false);
            DailyExpenseTable.getColumnModel().getColumn(3).setResizable(false);
        }

        SearchExpense_Field.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N

        SearchExpense_Button.setBackground(new java.awt.Color(0, 153, 0));
        SearchExpense_Button.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        SearchExpense_Button.setText("SEARCH");
        SearchExpense_Button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchExpense_button(evt);
            }
        });

        PAID_Expense_sort.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        PAID_Expense_sort.setText("PAID");
        PAID_Expense_sort.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Paid_Expense_sort(evt);
            }
        });

        Not_PAID_Expense_sort1.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        Not_PAID_Expense_sort1.setText("NOT PAID");
        Not_PAID_Expense_sort1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Not_Paid_sort_expense(evt);
            }
        });

        AllExpenseSort.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        AllExpenseSort.setSelected(true);
        AllExpenseSort.setText("ALL");
        AllExpenseSort.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AllExpenseSortMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SearchExpense_Field, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchExpense_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(PAID_Expense_sort)
                .addGap(18, 18, 18)
                .addComponent(Not_PAID_Expense_sort1)
                .addGap(18, 18, 18)
                .addComponent(AllExpenseSort)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(617, Short.MAX_VALUE)
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(614, 614, 614))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SearchExpense_Field, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SearchExpense_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PAID_Expense_sort)
                    .addComponent(Not_PAID_Expense_sort1)
                    .addComponent(AllExpenseSort))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 559, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane3.addTab("DAILY EXPENSIVE", jPanel9);

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        DailyCustomer_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Age", "Gender", "Quantity", "Amount", "Date", "Contact"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, true, true, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        DailyCustomer_Table.setRowHeight(30);
        DailyCustomer_Table.setSelectionBackground(new java.awt.Color(232, 57, 95));
        jScrollPane2.setViewportView(DailyCustomer_Table);
        if (DailyCustomer_Table.getColumnModel().getColumnCount() > 0) {
            DailyCustomer_Table.getColumnModel().getColumn(0).setResizable(false);
            DailyCustomer_Table.getColumnModel().getColumn(1).setResizable(false);
            DailyCustomer_Table.getColumnModel().getColumn(2).setResizable(false);
        }

        jLabel45.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        jLabel45.setText("DAILY CUSTOMER");

        SearchCustomer_comboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ByName", "ByID" }));

        SearchCustomer_button.setBackground(new java.awt.Color(0, 153, 0));
        SearchCustomer_button.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        SearchCustomer_button.setForeground(new java.awt.Color(255, 255, 255));
        SearchCustomer_button.setText("SEARCH");
        SearchCustomer_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchCustomer_buttonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1379, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel45)
                .addGap(586, 586, 586))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SearchCustomer_comboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchCustomer_textField, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchCustomer_button, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel45)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(SearchCustomer_button, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(SearchCustomer_textField)
                        .addComponent(SearchCustomer_comboBox, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 545, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane3.addTab("DAILY CUSTOMER", jPanel8);

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));

        jLabel46.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(0, 0, 0));
        jLabel46.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel46.setText("DAILY CREDITS");

        DailyCreditTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Amount", "Date", "Category"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        DailyCreditTable.setRowHeight(30);
        DailyCreditTable.setSelectionBackground(new java.awt.Color(232, 57, 95));
        jScrollPane3.setViewportView(DailyCreditTable);
        if (DailyCreditTable.getColumnModel().getColumnCount() > 0) {
            DailyCreditTable.getColumnModel().getColumn(0).setResizable(false);
            DailyCreditTable.getColumnModel().getColumn(1).setResizable(false);
            DailyCreditTable.getColumnModel().getColumn(2).setResizable(false);
            DailyCreditTable.getColumnModel().getColumn(3).setResizable(false);
        }

        SearchCredit_button.setBackground(new java.awt.Color(0, 102, 204));
        SearchCredit_button.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        SearchCredit_button.setForeground(new java.awt.Color(255, 255, 255));
        SearchCredit_button.setText("SEARCH");
        SearchCredit_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchCredit_buttonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 1379, Short.MAX_VALUE)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(565, 565, 565)
                        .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(SearchCredit_textField, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SearchCredit_button)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(SearchCredit_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(SearchCredit_textField, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 1, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 548, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("DAILY CREDIT", jPanel11);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        Sellingmedicine_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Quantity", "Amount", "Price", "Date", "CustomerID"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        Sellingmedicine_table.setRowHeight(30);
        Sellingmedicine_table.setSelectionBackground(new java.awt.Color(232, 57, 95));
        jScrollPane5.setViewportView(Sellingmedicine_table);

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("SELLING MEDICINE");

        SearchSellingMedicine_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ByID", "ByName", "ByCustomerID" }));

        SearchSellingMedicine_button.setBackground(new java.awt.Color(0, 153, 0));
        SearchSellingMedicine_button.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        SearchSellingMedicine_button.setForeground(new java.awt.Color(255, 255, 255));
        SearchSellingMedicine_button.setText("SEARCH");
        SearchSellingMedicine_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchSellingMedicine_buttonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(571, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(564, 564, 564))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SearchSellingMedicine_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchSellingMedicine_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchSellingMedicine_button, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(SearchSellingMedicine_button, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(SearchSellingMedicine_TextField)
                        .addComponent(SearchSellingMedicine_ComboBox, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 547, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane3.addTab("DAILY SELLING MEDICINE", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTabbedPane3, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 705, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTabbedPane3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane3MouseClicked

    }//GEN-LAST:event_jTabbedPane3MouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        dispose();
        MainForm m = new MainForm();
        m.show();
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jButton12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton12MouseClicked
        model1.setNumRows(0);
        selection();
    }//GEN-LAST:event_jButton12MouseClicked

    private void AllExpenseSortMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AllExpenseSortMouseClicked
        ExpenseSelection();
    }//GEN-LAST:event_AllExpenseSortMouseClicked

    private void Not_Paid_sort_expense(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Not_Paid_sort_expense
        PAID_Expense_sort.setSelected(false);
        Not_PAID_Expense_sort1.setSelected(true);
        AllExpenseSort.setSelected(false);
        model2.setNumRows(0);
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate = dateFormat.format(date);
            String query = "select * from EXPENISES WHERE DATE='" + strDate + "' and TYPE='NOT PAID'";
            rs = stmt.executeQuery(query);

            while (rs.next()) {

                String Name = rs.getString(2);
                String Amount = rs.getString(3);
                String Date = rs.getString(4);
                String Category = rs.getString(5);

                String tbDate[] = {Name, Amount, Date, Category};
                DefaultTableModel tb1Model = (DefaultTableModel) DailyExpenseTable.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_Not_Paid_sort_expense

    private void Paid_Expense_sort(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Paid_Expense_sort
        PAID_Expense_sort.setSelected(true);
        Not_PAID_Expense_sort1.setSelected(false);
        AllExpenseSort.setSelected(false);
        model2.setNumRows(0);
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate = dateFormat.format(date);
            String query = "select * from EXPENISES WHERE DATE='" + strDate + "' and TYPE='PAID'";
            rs = stmt.executeQuery(query);

            while (rs.next()) {

                String Name = rs.getString(2);
                String Amount = rs.getString(3);
                String Date = rs.getString(4);
                String Category = rs.getString(5);

                String tbDate[] = {Name, Amount, Date, Category};
                DefaultTableModel tb1Model = (DefaultTableModel) DailyExpenseTable.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_Paid_Expense_sort

    private void SearchExpense_button(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchExpense_button
        String type = "";
        if (PAID_Expense_sort.isSelected()) {
            type = "PAID";
        } else if (Not_PAID_Expense_sort1.isSelected()) {
            type = "NOT PAID";
        }
        try {
            String search = SearchExpense_Field.getText();
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate = dateFormat.format(date);
            String query;
            if (AllExpenseSort.isSelected()) {
                query = "select * from EXPENISES WHERE NAME='" + search + "'";
            } else {
                query = "select * from EXPENISES WHERE NAME='" + search + "' and TYPE='" + type + "'";
            }

            rs = stmt.executeQuery(query);
            model2.setNumRows(0);
            while (rs.next()) {

                String Name = rs.getString(2);
                String Amount = rs.getString(3);
                String Date = rs.getString(4);
                String Category = rs.getString(5);

                String tbDate[] = {Name, Amount, Date, Category};
                DefaultTableModel tb1Model = (DefaultTableModel) DailyExpenseTable.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_SearchExpense_button

    private void SearchCustomer_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchCustomer_buttonMouseClicked
        try {
            String type = SearchCustomer_comboBox.getSelectedItem().toString();
            String search = SearchCustomer_textField.getText();
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT * FROM CUSTOMER";
                model5.setNumRows(0);
                Date date = Calendar.getInstance().getTime();
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String strDate = dateFormat.format(date);
                if (type.equals("ByName")) {
                    query = "SELECT * FROM CUSTOMER WHERE DATE='" + strDate + "' AND NAME LIKE '" + search + "'";
                } else if (type.equals("ByID")) {
                    query = "SELECT * FROM CUSTOMER WHERE DATE='" + strDate + "' AND ID=" + Integer.parseInt(search) + "";
                } else {
                    JOptionPane.showMessageDialog(this, "Please Enter Data....");
                }
                rs = stmt.executeQuery(query);

                while (rs.next()) {
                    String id = rs.getString(1);
                    String Name = rs.getString(2);
                    String Age = rs.getString(3);
                    String Gender = rs.getString(4);
                    String Qty = rs.getString(8);
                    String Amt = rs.getString(5);
                    String Date = rs.getString(6);
                    String Contact = rs.getString(7);

                    String tbDate[] = {id, Name, Age, Gender, Qty, Amt, Date, Contact};
                    DefaultTableModel tb1Model = (DefaultTableModel) DailyCustomer_Table.getModel();
                    tb1Model.addRow(tbDate);
                }

                con.close();

            } catch (SQLException e) {
                System.out.println(e);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Somthing Went Wrong......");
            CustomerSelection();
        }
    }//GEN-LAST:event_SearchCustomer_buttonMouseClicked

    private void SearchCredit_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchCredit_buttonMouseClicked
        if (SearchCredit_textField.getText().equals("")) {
            SearchCredit_textField.setBackground(Color.red);
            JOptionPane.showMessageDialog(this, "please Enter name of Credit");
        } else {
            SearchCredit_textField.setBackground(Color.WHITE);
            try {
                String search = SearchCredit_textField.getText();
                Date date = Calendar.getInstance().getTime();
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String strDate = dateFormat.format(date);
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "select * from CREDIT WHERE DATE='" + strDate + "' AND NAME LIKE '" + search + "'";
                rs = stmt.executeQuery(query);
                model3.setNumRows(0);
                while (rs.next()) {

                    String Name = rs.getString(2);
                    String Amount = rs.getString(3);
                    String Date = rs.getString(4);
                    String Category = rs.getString(5);

                    String tbDate[] = {Name, Amount, Date, Category};
                    DefaultTableModel tb1Model = (DefaultTableModel) DailyCreditTable.getModel();
                    tb1Model.addRow(tbDate);
                }
                if (model3.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "NO DATA Found....");
                    CreditSelection();
                }
                con.close();
            } catch (SQLException e) {
                System.out.println(e);
                CreditSelection();
            }

        }
    }//GEN-LAST:event_SearchCredit_buttonMouseClicked

    private void SearchSellingMedicine_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchSellingMedicine_buttonMouseClicked
        try {
            String type = SearchSellingMedicine_ComboBox.getSelectedItem().toString();
            String search = SearchSellingMedicine_TextField.getText();
            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate = dateFormat.format(date);
            try {
                model4.setNumRows(0);
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT * FROM SELLINGMEDICINE WHERE DATE='" + strDate + "'";

                if (type.equals("ByName")) {
                    query = "SELECT * FROM SELLINGMEDICINE WHERE DATE='" + strDate + "' AND NAME LIKE '" + search + "'";
                } else if (type.equals("ByID")) {
                    query = "SELECT * FROM SELLINGMEDICINE WHERE DATE='" + strDate + "' AND MED_ID='" + search + "'";
                } else if (type.equals("ByCustomerID")) {
                    query = "SELECT * FROM SELLINGMEDICINE WHERE DATE='" + strDate + "' AND CID=" + Integer.parseInt(search) + "";
                } else {
                    JOptionPane.showMessageDialog(this, "Please Enter Data....");
                }
                rs = stmt.executeQuery(query);

                while (rs.next()) {
                    String id = rs.getString(2);
                    String Name = rs.getString(3);
                    String Qty = rs.getString(4);
                    String Amt = rs.getString(5);
                    String Date = rs.getString(6);
                    String SellPrice = rs.getString(7);
                    String CID = rs.getString(8);

                    String tbDate[] = {id, Name, Qty, Amt, SellPrice, Date, CID};
                    DefaultTableModel tb1Model = (DefaultTableModel) Sellingmedicine_table.getModel();
                    tb1Model.addRow(tbDate);
                }

                con.close();

            } catch (SQLException e) {
                System.out.println(e);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Somthing Went Wrong......");
            SellingMedicine_selection();
        }
        if (Sellingmedicine_table.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Data Not Found.....");
            SellingMedicine_selection();
        }
    }//GEN-LAST:event_SearchSellingMedicine_buttonMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DAILY.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DAILY.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DAILY.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DAILY.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DAILY().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton AllExpenseSort;
    private javax.swing.JTable DailyCreditTable;
    private javax.swing.JTable DailyCustomer_Table;
    private javax.swing.JTable DailyExpenseTable;
    private javax.swing.JRadioButton Not_PAID_Expense_sort1;
    private javax.swing.JRadioButton PAID_Expense_sort;
    private javax.swing.JButton SearchCredit_button;
    private javax.swing.JTextField SearchCredit_textField;
    private javax.swing.JButton SearchCustomer_button;
    private javax.swing.JComboBox<String> SearchCustomer_comboBox;
    private javax.swing.JTextField SearchCustomer_textField;
    private javax.swing.JButton SearchExpense_Button;
    private javax.swing.JTextField SearchExpense_Field;
    private javax.swing.JComboBox<String> SearchSellingMedicine_ComboBox;
    private javax.swing.JTextField SearchSellingMedicine_TextField;
    private javax.swing.JButton SearchSellingMedicine_button;
    private javax.swing.JTable Sellingmedicine_table;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

}
