/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PharamcyManagementSystem;

import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JRViewer;

/**
 *
 * @author moin_pc
 */
public class Make_report extends javax.swing.JFrame {

    /**
     * Creates new form Make_report
     */
    public Make_report() {
        initComponents();
        getPharmacyDetails();
    }
    Connection con;
    ResultSet rs;

    Map<String, Object> p = new HashMap<String, Object>();

    public void getDetails() {
        p.clear();
        getPharmacyDetails();
     //   String OtherCredit, TotalSells, TotalExp = "0", TotalCre = "0", Purchases, GeneralExp, Total;
        int OtherCredit=0, TotalSells=0,TotalCre=0,Purchases=0,GeneralExp=0,TotalExp=0,Total=0;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String strDate1 = dateFormat.format(StartingDate.getDate());
        String strDate2 = dateFormat.format(EndingDate.getDate());
        p.put("Start", strDate1);
        p.put("End", strDate2);
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();

            //Total Sells OR Credited By customer
            String query = "SELECT SUM(AMOUNT) FROM CREDIT WHERE CATEGORY='Customer' AND DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "'";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                rs.next();
                TotalSells += rs.getInt(1);
                p.put("TotalSells", TotalSells);
            } else {
                p.put("TotalSells", "0");
            }

            //Other Credit
            query = "SELECT SUM(AMOUNT) FROM CREDIT WHERE CATEGORY!='Customer' AND  DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "'";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                rs.next();
                OtherCredit += rs.getInt(1);
                p.put("OtherCredit", OtherCredit);
            } else {
                p.put("OtherCredit", "0");
            }

            //Count Total Expenses
            query = "SELECT SUM(AMOUNT) FROM EXPENISES WHERE DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "'";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                rs.next();
                TotalExp += rs.getInt(1);
                p.put("TotalExpense", TotalExp);
            } else {
                p.put("TotalExpense", "0");
            }

            //Count Total Credit
            query = "SELECT SUM(AMOUNT) FROM CREDIT WHERE DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "'";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                rs.next();
                TotalCre += rs.getInt(1);
                p.put("TotalCredit", TotalCre);
            } else {
                p.put("TotalCredit", "0");
            }

            //Count Total Purchas
            query = "SELECT SUM(AMOUNT) FROM EXPENISES WHERE CATEGORY='company' AND DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "'";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                rs.next();
                Purchases +=rs.getInt(1);
                p.put("TotalPurchase", Purchases);
            } else {
                p.put("TotalPurchase", "0");
            }

            //Other Expense
            query = "SELECT SUM(AMOUNT) FROM EXPENISES WHERE CATEGORY='General' AND DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "'";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                rs.next();
                GeneralExp += rs.getInt(1);
                p.put("OtherExpense", GeneralExp);
            } else {
                p.put("OtherExpense", "0");
            }

            ///Count Total Credit - Expense
            Total = TotalCre - TotalExp;
            p.put("Total", Total);

        } catch (SQLException e) {
            System.out.println("Error : " + e);
        }
    }

    public void getPharmacyDetails() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT * FROM REGISTER";
            rs = stmt.executeQuery(query);
            rs.next();
            p.put("StoreName", rs.getString(4));
            p.put("Address", rs.getString(6));
            p.put("Mobile", rs.getString(5));
            p.put("RegisterNo", rs.getString(8));
            con.close();

        } catch (Exception e) {
        }
    }

    public void ReportLoad() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String start = dateFormat.format(StartingDate.getDate());
            String End = dateFormat.format(EndingDate.getDate());
            ReportContainer.removeAll();
            ReportContainer.repaint();
            ReportContainer.revalidate();

            JasperDesign jdesign = JRXmlLoader.load("C:\\Users\\moin_pc\\Documents\\NetBeansProjects\\PharmacyDemo\\src\\PharamcyManagementSystem\\report.jrxml");
            JasperReport jreport = JasperCompileManager.compileReport(jdesign);
            JasperPrint jprint = JasperFillManager.fillReport(jreport, p, con);

            JRViewer v = new JRViewer(jprint);
            ReportContainer.setLayout(new BorderLayout());
            ReportContainer.add(v);
        } catch (Exception e) {
            System.out.println("Error in view: " + e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        StartingDate = new com.toedter.calendar.JDateChooser();
        EndingDate = new com.toedter.calendar.JDateChooser();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        MakeReport = new javax.swing.JButton();
        ReportContainer = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 22)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("MAKE REPORT");

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Close all jframe.png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 538, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel3.setText("Date From : ");

        jLabel4.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel4.setText("Date To : ");

        MakeReport.setBackground(new java.awt.Color(0, 153, 0));
        MakeReport.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        MakeReport.setForeground(new java.awt.Color(255, 255, 255));
        MakeReport.setText("MAKE");
        MakeReport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MakeReportMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(StartingDate, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(EndingDate, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(MakeReport, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(MakeReport, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(EndingDate, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(StartingDate, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout ReportContainerLayout = new javax.swing.GroupLayout(ReportContainer);
        ReportContainer.setLayout(ReportContainerLayout);
        ReportContainerLayout.setHorizontalGroup(
            ReportContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        ReportContainerLayout.setVerticalGroup(
            ReportContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 454, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(ReportContainer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ReportContainer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void MakeReportMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MakeReportMouseClicked
        getDetails();
        ReportLoad();
    }//GEN-LAST:event_MakeReportMouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
       MainForm mf=new MainForm();
       dispose();
       mf.show();
    }//GEN-LAST:event_jLabel2MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Make_report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Make_report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Make_report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Make_report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Make_report().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser EndingDate;
    private javax.swing.JButton MakeReport;
    private javax.swing.JPanel ReportContainer;
    private com.toedter.calendar.JDateChooser StartingDate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
