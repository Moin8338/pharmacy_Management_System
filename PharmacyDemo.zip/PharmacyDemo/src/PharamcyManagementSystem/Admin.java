package PharamcyManagementSystem;

import java.awt.*;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import static java.awt.print.Printable.NO_SUCH_PAGE;
import static java.awt.print.Printable.PAGE_EXISTS;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.beans.Statement;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

public final class Admin extends javax.swing.JFrame {

    DefaultTableModel model, model1, model2, model3;

    Map<String, Object> p = new HashMap<String, Object>();

    String MedicineQuery = "SELECT * FROM MEDICINE";

    public Admin() {
        initComponents();
        selection();
        selection1();
        selection2();
        selection3();
        company_and_category();
        getPharmacyDetails();
        //  getPharmacyDetails();
        model = (DefaultTableModel) AddedMedcineTable.getModel();
        model1 = (DefaultTableModel) AvailableStockTable.getModel();
        model2 = (DefaultTableModel) CompanyTable.getModel();
        model3 = (DefaultTableModel) MakeListTable.getModel();
    }
    Connection con = null;
    Statement st = null;
    ResultSet rs = null;

    public void getPharmacyDetails() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT * FROM REGISTER";
            rs = stmt.executeQuery(query);
            rs.next();
            p.put("StoreName", rs.getString(4));
            p.put("Address", rs.getString(6));
            p.put("Mobile", rs.getString(5));
            p.put("RegisterNo", rs.getString(8));
            con.close();

        } catch (Exception e) {
        }
    }

//   ///--------------Check Id is Available or Not
    boolean isAvailable(String id) throws SQLException {
        boolean check = true;
        Date date1 = MedicineAddDate.getDate();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String strDate1 = dateFormat.format(date1);
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT ID FROM MEDICINE WHERE MED_ID=" + Integer.parseInt(id) + " and DATE='" + strDate1 + "'";
            System.out.println(strDate1);
            rs = stmt.executeQuery(query);
            check = rs.next();
        } catch (SQLException e) {
        }
        return check;
    }

    ///---------Show Data in Jtable From database
    void selection() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from MEDICINE ORDER BY DATE DESC";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                String id = rs.getString("MED_ID");
                String Company = rs.getString("CAMPANY");
                String Category = rs.getString("CATEGORY");
                String Name = rs.getString("MEDICINENAME");
                String BuyP = rs.getString("BUYINGPRICE");
                String SellP = rs.getString("SELLINGPRICE");
                String Quantity = rs.getString("QUANTITY");
                String Date = rs.getString("DATE");
                String ExpDate = rs.getString("EXPDATE");

                String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                DefaultTableModel tb1Model = (DefaultTableModel) AddedMedcineTable.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    //show Company & Category
    void company_and_category() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from CAMPANY ORDER BY ID";
            rs = stmt.executeQuery(query);

            while (rs.next()) {

                String Company = rs.getString(2);
                CompanyNameField.addItem(Company);

            }
            query = "select * from CATEGORY";
            rs = stmt.executeQuery(query);

            while (rs.next()) {

                String name = rs.getString(1);
                CategoryField.addItem(name);

            }
            con.close();
        } catch (Exception e) {
        }
    }

    //second table show date
    void selection1() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from MEDICINE ORDER BY ID";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                String id = rs.getString("MED_ID");
                String Company = rs.getString("CAMPANY");
                String Category = rs.getString("CATEGORY");
                String Name = rs.getString("MEDICINENAME");
                String BuyP = rs.getString("BUYINGPRICE");
                String SellP = rs.getString("SELLINGPRICE");
                String Quantity = rs.getString("QUANTITY");
                String Date = rs.getString("DATE");
                String ExpDate = rs.getString("EXPDATE");

                String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                DefaultTableModel tb1Mode2 = (DefaultTableModel) AvailableStockTable.getModel();
                tb1Mode2.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    ////----------------CreateList selection
    void selection2() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from CreateList ORDER BY ID";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                String id = rs.getString("ID");
                String Company = rs.getString("COMPANY");
                String Category = rs.getString("CATEGORY");
                String Name = rs.getString("NAME");
                String Quantity = rs.getString("QUANTITY");

                String tbDate[] = {id, Company, Category, Name, Quantity};
                DefaultTableModel tb1Model = (DefaultTableModel) MakeListTable.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    //----------------Campany Data show
    void selection3() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "select * from CAMPANY ORDER BY ID";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                String id = rs.getString("ID");
                String Name = rs.getString("Name");
                String Email = rs.getString("Email");
                String Phone = rs.getString("PhoneNumber");
                String Address = rs.getString("Address");

                String tbDate[] = {id, Name, Email, Name, Address};
                DefaultTableModel tb1Model = (DefaultTableModel) CompanyTable.getModel();
                tb1Model.addRow(tbDate);
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    /////---------Update Medicine
    void Update() throws SQLException {
        Date date1 = MedicineAddDate.getDate();
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        String strDate1 = dateFormat1.format(date1);
        int id = Integer.parseInt(SerialNumberOfMedicineField.getText());
        String company = CompanyNameField.getSelectedItem().toString();
        String category = CategoryField.getSelectedItem().toString();
        String Medicine_Name = MedicineNameField.getText();
        float buyingPrice = Float.parseFloat(BuyingPriceField.getText());
        float sellingPrice = Float.parseFloat(SellingPriceField.getText());
        int Quantity = Integer.parseInt(QuantityField.getText());
        try {
            if (isAvailable(SerialNumberOfMedicineField.getText())) {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "UPDATE MEDICINE SET CAMPANY='" + company + "',CATEGORY='" + category + "',MEDICINENAME='" + Medicine_Name + "',BUYINGPRICE=" + buyingPrice + ",SELLINGPRICE=" + sellingPrice + ",QUANTITY=" + Quantity + " WHERE MED_ID=" + id + " and DATE='" + strDate1 + "'";
                stmt.execute(query);
                JOptionPane.showMessageDialog(this, "Update Successfully...");
            } else {
                JOptionPane.showMessageDialog(this, "Medicine is Not Available First you Add the Medicine...");
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    //----------validate TextBox
    boolean validate_TextBox() {
        if (SerialNumberOfMedicineField.getText().isEmpty() || BuyingPriceField.getText().isEmpty() || SellingPriceField.getText().isEmpty() || QuantityField.getText().isEmpty() || MedicineNameField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Fill The Blank TextBox");
        } else {
            //---------validate ID
            if (isValidNumber(SerialNumberOfMedicineField.getText())) {
                SerialNumberOfMedicineField.setBackground(Color.GREEN);
                //--------Validate buying price
                if (isValidNumber(BuyingPriceField.getText())) {
                    BuyingPriceField.setBackground(Color.GREEN);
                    //-----------Vaidate Selling Price
                    if (isValidNumber(SellingPriceField.getText())) {
                        SellingPriceField.setBackground(Color.GREEN);
                        //--------------Validate Quantity
                        if (isValidNumber(QuantityField.getText())) {
                            QuantityField.setBackground(Color.GREEN);
                            return true;
                        } else {
                            QuantityField.setBackground(Color.red);
                            JOptionPane.showMessageDialog(this, "Enter Valid Quantity 'Only Number'");
                        }
                    } else {
                        SellingPriceField.setBackground(Color.red);
                        JOptionPane.showMessageDialog(this, "Enter Valid selling Price 'Only Number'");
                    }
                } else {
                    BuyingPriceField.setBackground(Color.red);
                    JOptionPane.showMessageDialog(this, "Enter Valid Buying Price 'Only Number'");
                }
            } else {
                SerialNumberOfMedicineField.setBackground(Color.red);
                JOptionPane.showMessageDialog(this, "Enter Valid ID 'Only Number'");
            }
        }
        return false;
    }

    ///---------------Insert Data into Database
    void InsertData() {
        try {
            Date date1 = MedicineAddDate.getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyy-MM-dd");
            String strDate1 = dateFormat.format(date1);
            Date date2 = MedicineExpireDate.getDate();
            dateFormat = new SimpleDateFormat("yyy-MM-dd");
            String ExpDate = dateFormat.format(date2);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT MAX(ID) FROM MEDICINE";
            rs = stmt.executeQuery(query);
            int ID = 1;
            if (rs.next()) {
                ID = (Integer) rs.getInt(1) + 1;
            }
            PreparedStatement Add = con.prepareStatement("INSERT INTO MEDICINE (ID,MED_ID,CAMPANY,CATEGORY,MEDICINENAME,BUYINGPRICE,SELLINGPRICE,QUANTITY,DATE,EXPDATE) VALUES (" + ID + "," + Integer.parseInt(SerialNumberOfMedicineField.getText()) + ",'" + CompanyNameField.getSelectedItem().toString() + "','" + CategoryField.getSelectedItem().toString() + "'," + "'" + MedicineNameField.getText() + "'," + Double.parseDouble(BuyingPriceField.getText()) + "," + Double.parseDouble(SellingPriceField.getText()) + "," + Integer.parseInt(QuantityField.getText()) + ",'" + strDate1 + "','" + ExpDate + "')");
//            Add.setString(1, SerialNumberOfMedicineField.getText());
//            Add.setString(2, CompanyNameField.getSelectedItem().toString());
//            Add.setString(3, CategoryField.getSelectedItem().toString());
//            Add.setString(4, MedicineNameField.getText());
//            Add.setString(5, BuyingPriceField.getText());
//            Add.setString(6, SellingPriceField.getText());
//            Add.setString(7, QuantityField.getText());
//            Add.setString(8, strDate1);
            int row = Add.executeUpdate();
            JOptionPane.showMessageDialog(this, "Medicine Add SuccessFully...");
            con.close();
        } catch (SQLException e) {
            System.out.println("error in insert data  " + e);
        }

    }

    //---reset the textField
    void reset() {
        SerialNumberOfMedicineField.setText("");
        MedicineNameField.setText("");
        BuyingPriceField.setText("");
        SellingPriceField.setText("");
        QuantityField.setText("");
        SerialNumberOfMedicineField.setBackground(Color.WHITE);
        MedicineNameField.setBackground(Color.WHITE);
        BuyingPriceField.setBackground(Color.WHITE);
        SellingPriceField.setBackground(Color.WHITE);
        QuantityField.setBackground(Color.WHITE);
    }

    //-------------Number Validation
    boolean isValidNumber(String Number) {
        boolean isValid = true;
        String upperCaseChars = "(.*[A-Z].*)";
        if (Number.matches(upperCaseChars)) {
            isValid = false;
        }
        String lowerCaseChars = "(.*[a-z].*)";
        if (Number.matches(lowerCaseChars)) {
            isValid = false;
        }
        String numbers = "(.*[0-9].*)";
        if (!Number.matches(numbers)) {
            isValid = false;
        }
        String specialChars = "(.*[@,#,$,%].*$)";
        if (Number.matches(specialChars)) {
            isValid = false;
        }
        return isValid;
    }

    ///-------String Validation
    boolean isValidString(String Number) {
        boolean isValid = true;
        String upperCaseChars = "(.*[A-Z].*)";
        if (Number.matches(upperCaseChars)) {
            isValid = true;
        }
        String lowerCaseChars = "(.*[a-z].*)";
        if (Number.matches(lowerCaseChars)) {
            isValid = true;
        }
        String numbers = "(.*[0-9].*)";
        if (!Number.matches(numbers)) {
            isValid = true;
        }
        String specialChars = "(.*[@,#,$,%].*$)";
        if (!Number.matches(specialChars)) {
            isValid = true;
        }
        return isValid;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        BackToHome = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        RefreshPage = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        SerialNumberOfMedicineField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        MedicineNameField = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        SellingPriceField = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        QuantityField = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        BuyingPriceField = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        MedicineAddDate = new com.toedter.calendar.JDateChooser();
        CompanyNameField = new javax.swing.JComboBox<>();
        CategoryField = new javax.swing.JComboBox<>();
        AddMedicine = new javax.swing.JButton();
        UpdateMedicine = new javax.swing.JButton();
        DeleteMedicine = new javax.swing.JButton();
        addCompanylabel = new javax.swing.JLabel();
        addCategoryLabel = new javax.swing.JLabel();
        Paid = new javax.swing.JRadioButton();
        notPaid = new javax.swing.JRadioButton();
        MedicineExpireDate = new com.toedter.calendar.JDateChooser();
        jLabel21 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        SearchMedicine = new javax.swing.JButton();
        Print = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        AddedMedcineTable = new javax.swing.JTable();
        SearchMedicineFieldl = new javax.swing.JTextField();
        jComboBox3 = new javax.swing.JComboBox<>();
        EndingStockOfMedicine2 = new javax.swing.JTextField();
        CheckStock = new javax.swing.JButton();
        startingStockOfMedicine2 = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        AvailableStockTable = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        MakeListTable = new javax.swing.JTable();
        printListButton = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        SortByDateButton = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jDateChooser4 = new com.toedter.calendar.JDateChooser();
        jDateChooser5 = new com.toedter.calendar.JDateChooser();
        ModeOfSearchBySPbyBP = new javax.swing.JComboBox<>();
        jTextField15 = new javax.swing.JTextField();
        SortByPriceButton = new javax.swing.JButton();
        jTextField16 = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        SortMode_byDate = new javax.swing.JComboBox<>();
        jPanel12 = new javax.swing.JPanel();
        searchMedicineByNameByIDField = new javax.swing.JTextField();
        searchButttonByName_ID = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel27 = new javax.swing.JLabel();
        jComboBox6 = new javax.swing.JComboBox<>();
        SearchMedicineBycategoryByCompany = new javax.swing.JTextField();
        SearchButtonByCategory_Company = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        EndingstockOfMedicineField = new javax.swing.JTextField();
        checkLessStckButton = new javax.swing.JButton();
        startingstockOfMedicineField = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        refreshButton = new javax.swing.JButton();
        RemoveMedicineFromList = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        UpdateMode = new javax.swing.JRadioButton();
        stockUpdateField = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        CompanyTable = new javax.swing.JTable();
        AddCompanyButton = new javax.swing.JButton();
        SearchCompanyButton = new javax.swing.JButton();
        searchCompanyField = new javax.swing.JTextField();
        serachModeFor_search_company = new javax.swing.JComboBox<>();
        DeleteCompanyButton = new javax.swing.JButton();
        RefreshCompanyTableButton = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setLocation(new java.awt.Point(0, 0));
        setName("Admin"); // NOI18N
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel8.setBackground(new java.awt.Color(51, 51, 51));

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Kadiwal Moinudin");

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 153, 0));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("( ADMIN )");

        BackToHome.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BackToHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Close all jframe.png"))); // NOI18N
        BackToHome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BackToHomeMouseClicked(evt);
            }
        });

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/profilecopy2.png"))); // NOI18N

        RefreshPage.setBackground(new java.awt.Color(255, 255, 255));
        RefreshPage.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        RefreshPage.setText("REFRESH PAGE");
        RefreshPage.setName("searchMedicine"); // NOI18N
        RefreshPage.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RefreshPage(evt);
            }
        });

        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel28.setText("WHEN YOU SEE ANY UN-EXPECTED ERROR THEN CLICK HERE   ->");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 440, Short.MAX_VALUE)
                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 372, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(RefreshPage, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addComponent(BackToHome, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BackToHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(RefreshPage)
                .addContainerGap(12, Short.MAX_VALUE))
            .addComponent(jLabel28, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        jTabbedPane1.setInheritsPopupMenu(true);
        jTabbedPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane1MouseClicked(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel9.setText("PURCHASE / ADD");

        jLabel5.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel5.setText("MEDICINE ID / SERIAL");

        SerialNumberOfMedicineField.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        SerialNumberOfMedicineField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        SerialNumberOfMedicineField.setName("Med_ID"); // NOI18N
        SerialNumberOfMedicineField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SerialNumberOfMedicineFieldActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel8.setText("COMPANY");

        jLabel10.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N

        jLabel11.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel11.setText("PRODUCT TITLE");

        MedicineNameField.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        MedicineNameField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        MedicineNameField.setName("MedicineName"); // NOI18N
        MedicineNameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MedicineNameFieldActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel12.setText("SELLING PRICE");

        SellingPriceField.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        SellingPriceField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        SellingPriceField.setName("Sellingprice"); // NOI18N

        jLabel13.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel13.setText("QUANTITY");

        QuantityField.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        QuantityField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        QuantityField.setName("QtyOfMedicine"); // NOI18N

        jLabel14.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel14.setText("DATE OF ADDED");

        jLabel15.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel15.setText("BUYING PRICE");

        BuyingPriceField.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        BuyingPriceField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        BuyingPriceField.setName("BuyingPrice"); // NOI18N

        jLabel16.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel16.setText("CATEGORY");

        MedicineAddDate.setName("DateOfAddStock"); // NOI18N

        CompanyNameField.setName("Campany"); // NOI18N

        CategoryField.setName("Category"); // NOI18N

        AddMedicine.setBackground(new java.awt.Color(0, 102, 0));
        AddMedicine.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        AddMedicine.setForeground(new java.awt.Color(255, 255, 255));
        AddMedicine.setText("PURCHASE");
        AddMedicine.setName("AddMedicine"); // NOI18N
        AddMedicine.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddMedicine(evt);
            }
        });

        UpdateMedicine.setBackground(new java.awt.Color(0, 51, 255));
        UpdateMedicine.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        UpdateMedicine.setForeground(new java.awt.Color(255, 255, 255));
        UpdateMedicine.setText("STOCK UPDATE");
        UpdateMedicine.setName("UpdateMedicine"); // NOI18N
        UpdateMedicine.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UpdateMedicine(evt);
            }
        });

        DeleteMedicine.setBackground(new java.awt.Color(255, 0, 0));
        DeleteMedicine.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        DeleteMedicine.setForeground(new java.awt.Color(255, 255, 255));
        DeleteMedicine.setText("DELETE SELECTED");
        DeleteMedicine.setName("DeleteMedicine"); // NOI18N
        DeleteMedicine.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DeleteMedicine(evt);
            }
        });

        addCompanylabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        addCompanylabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/plus-icon d.jpg"))); // NOI18N
        addCompanylabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddCompany(evt);
            }
        });

        addCategoryLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        addCategoryLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/plus-icon d.jpg"))); // NOI18N
        addCategoryLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddCategory(evt);
            }
        });

        Paid.setText("PAID");
        Paid.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PaidMedicine(evt);
            }
        });

        notPaid.setSelected(true);
        notPaid.setText("NOT PAID");
        notPaid.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                NotPaidMedicine(evt);
            }
        });

        MedicineExpireDate.setName("DateOfAddStock"); // NOI18N

        jLabel21.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel21.setText("DATE OF EXPIRE");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addGap(80, 80, 80)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(MedicineNameField, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(SerialNumberOfMedicineField, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(CompanyNameField, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(CategoryField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel15)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(MedicineExpireDate, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(MedicineAddDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addComponent(BuyingPriceField, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel12)
                        .addComponent(SellingPriceField, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel13)
                        .addComponent(QuantityField, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(Paid)
                            .addGap(18, 18, 18)
                            .addComponent(notPaid))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addCompanylabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addCategoryLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(86, 86, 86))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(AddMedicine)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DeleteMedicine)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(UpdateMedicine, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(147, 147, 147)
                .addComponent(jLabel9)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(263, 263, 263)
                        .addComponent(jLabel10)
                        .addGap(266, 266, 266))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SerialNumberOfMedicineField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(CompanyNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addCompanylabel, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CategoryField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addCategoryLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(MedicineNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(MedicineAddDate, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel21)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(MedicineExpireDate, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel15)
                        .addGap(5, 5, 5)
                        .addComponent(BuyingPriceField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SellingPriceField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(QuantityField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Paid)
                            .addComponent(notPaid))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DeleteMedicine, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UpdateMedicine, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddMedicine, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
        );

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setName(""); // NOI18N

        jLabel17.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("PURCHASE HISTORY");

        SearchMedicine.setBackground(new java.awt.Color(0, 102, 0));
        SearchMedicine.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        SearchMedicine.setForeground(new java.awt.Color(255, 255, 255));
        SearchMedicine.setText("SEARCH");
        SearchMedicine.setName("searchMedicine"); // NOI18N
        SearchMedicine.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchMedicne(evt);
            }
        });

        Print.setBackground(new java.awt.Color(0, 102, 204));
        Print.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Print.setForeground(new java.awt.Color(255, 255, 255));
        Print.setText("PRINT");
        Print.setName("Print"); // NOI18N
        Print.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PrintMouseClicked(evt);
            }
        });
        Print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintActionPerformed(evt);
            }
        });

        AddedMedcineTable.setAutoCreateRowSorter(true);
        AddedMedcineTable.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        AddedMedcineTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Company", "Category", "Name", "BuyingPrice", "SellingPrce", "Quantity", "Date", "Exp Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        AddedMedcineTable.setColumnSelectionAllowed(true);
        AddedMedcineTable.setFocusCycleRoot(true);
        AddedMedcineTable.setGridColor(new java.awt.Color(102, 204, 255));
        AddedMedcineTable.setInheritsPopupMenu(true);
        AddedMedcineTable.setIntercellSpacing(new java.awt.Dimension(0, 0));
        AddedMedcineTable.setName("addMedicineTable"); // NOI18N
        AddedMedcineTable.setRowHeight(30);
        AddedMedcineTable.setSelectionBackground(new java.awt.Color(232, 57, 95));
        AddedMedcineTable.setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        AddedMedcineTable.setShowVerticalLines(false);
        AddedMedcineTable.getTableHeader().setReorderingAllowed(false);
        AddedMedcineTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddedMedcineTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(AddedMedcineTable);
        AddedMedcineTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (AddedMedcineTable.getColumnModel().getColumnCount() > 0) {
            AddedMedcineTable.getColumnModel().getColumn(0).setResizable(false);
            AddedMedcineTable.getColumnModel().getColumn(1).setResizable(false);
            AddedMedcineTable.getColumnModel().getColumn(2).setResizable(false);
            AddedMedcineTable.getColumnModel().getColumn(3).setResizable(false);
            AddedMedcineTable.getColumnModel().getColumn(4).setResizable(false);
            AddedMedcineTable.getColumnModel().getColumn(5).setResizable(false);
            AddedMedcineTable.getColumnModel().getColumn(6).setResizable(false);
        }

        SearchMedicineFieldl.setName("SearchingText"); // NOI18N
        SearchMedicineFieldl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchMedicineFieldlActionPerformed(evt);
            }
        });

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ByName", "ByID", "ByCompany", "byCategory" }));
        jComboBox3.setName("SerchingMode"); // NOI18N

        EndingStockOfMedicine2.setText("0");
        EndingStockOfMedicine2.setName("EndingStock"); // NOI18N

        CheckStock.setBackground(new java.awt.Color(0, 102, 0));
        CheckStock.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        CheckStock.setForeground(new java.awt.Color(255, 255, 255));
        CheckStock.setText("CHECK");
        CheckStock.setName("searchMedicine"); // NOI18N
        CheckStock.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CheckStock(evt);
            }
        });

        startingStockOfMedicine2.setText("0");
        startingStockOfMedicine2.setName("startingStock"); // NOI18N

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SearchMedicineFieldl, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SearchMedicine)
                                .addGap(94, 103, Short.MAX_VALUE)
                                .addComponent(startingStockOfMedicine2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(EndingStockOfMedicine2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel17)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(CheckStock)
                        .addGap(135, 135, 135)
                        .addComponent(Print)))
                .addGap(51, 51, 51))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Print, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(CheckStock, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(startingStockOfMedicine2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(EndingStockOfMedicine2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SearchMedicineFieldl, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(SearchMedicine, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 537, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 649, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Add Medicine", jPanel2);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel19.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        jLabel19.setText("Available Stock");

        AvailableStockTable.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        AvailableStockTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Campany", "Category", "Name", "BuyingPrice", "SellingPrice", "Quantity", "Date", "Exp Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        AvailableStockTable.setGridColor(new java.awt.Color(51, 153, 255));
        AvailableStockTable.setIntercellSpacing(new java.awt.Dimension(0, 0));
        AvailableStockTable.setRowHeight(30);
        AvailableStockTable.setSelectionBackground(new java.awt.Color(232, 57, 95));
        AvailableStockTable.setShowVerticalLines(false);
        AvailableStockTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AvailableStockTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(AvailableStockTable);
        if (AvailableStockTable.getColumnModel().getColumnCount() > 0) {
            AvailableStockTable.getColumnModel().getColumn(0).setResizable(false);
            AvailableStockTable.getColumnModel().getColumn(1).setResizable(false);
            AvailableStockTable.getColumnModel().getColumn(2).setResizable(false);
            AvailableStockTable.getColumnModel().getColumn(3).setResizable(false);
            AvailableStockTable.getColumnModel().getColumn(4).setResizable(false);
            AvailableStockTable.getColumnModel().getColumn(5).setResizable(false);
            AvailableStockTable.getColumnModel().getColumn(6).setResizable(false);
        }

        MakeListTable.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        MakeListTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Category", "Company", "Name", "Quantity"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        MakeListTable.setGridColor(new java.awt.Color(51, 204, 255));
        MakeListTable.setIntercellSpacing(new java.awt.Dimension(0, 0));
        MakeListTable.setRowHeight(30);
        MakeListTable.setSelectionBackground(new java.awt.Color(232, 57, 95));
        MakeListTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Update_stock(evt);
            }
        });
        jScrollPane4.setViewportView(MakeListTable);
        if (MakeListTable.getColumnModel().getColumnCount() > 0) {
            MakeListTable.getColumnModel().getColumn(0).setResizable(false);
            MakeListTable.getColumnModel().getColumn(1).setResizable(false);
            MakeListTable.getColumnModel().getColumn(2).setResizable(false);
            MakeListTable.getColumnModel().getColumn(3).setResizable(false);
            MakeListTable.getColumnModel().getColumn(4).setResizable(false);
        }

        printListButton.setBackground(new java.awt.Color(0, 153, 51));
        printListButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        printListButton.setForeground(new java.awt.Color(255, 255, 255));
        printListButton.setText("PRINT");
        printListButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                printListButtonSearchMedicine(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setText("GET LIST");

        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("TO");

        SortByDateButton.setBackground(new java.awt.Color(0, 102, 204));
        SortByDateButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        SortByDateButton.setForeground(new java.awt.Color(255, 255, 255));
        SortByDateButton.setText("SORT");
        SortByDateButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SortMedicineByDate(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("SORT BY DATE : ");

        jDateChooser4.setForeground(new java.awt.Color(0, 102, 0));

        jDateChooser5.setForeground(new java.awt.Color(0, 102, 0));

        ModeOfSearchBySPbyBP.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        ModeOfSearchBySPbyBP.setForeground(new java.awt.Color(0, 102, 0));
        ModeOfSearchBySPbyBP.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "BySELLING", "ByBUYING" }));

        jTextField15.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextField15.setForeground(new java.awt.Color(0, 102, 0));
        jTextField15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField15ActionPerformed(evt);
            }
        });

        SortByPriceButton.setBackground(new java.awt.Color(0, 102, 204));
        SortByPriceButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        SortByPriceButton.setForeground(new java.awt.Color(255, 255, 255));
        SortByPriceButton.setText("SORT");
        SortByPriceButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SortMedicine_byBP_bySP(evt);
            }
        });

        jTextField16.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextField16.setForeground(new java.awt.Color(0, 102, 0));
        jTextField16.setText("0");
        jTextField16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField16ActionPerformed(evt);
            }
        });

        jLabel24.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("SORT BY BUYING PRICE  & SELLING PRICE : ");

        SortMode_byDate.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ByAdding_Date", "ByExpire_Date" }));

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(ModeOfSearchBySPbyBP, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(SortByPriceButton, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(jDateChooser4, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jDateChooser5, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SortByDateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(SortMode_byDate, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SortMode_byDate, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(SortByDateButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jDateChooser4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jDateChooser5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ModeOfSearchBySPbyBP, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SortByPriceButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43))
        );

        searchMedicineByNameByIDField.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        searchMedicineByNameByIDField.setForeground(new java.awt.Color(0, 102, 0));
        searchMedicineByNameByIDField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchMedicineByNameByIDFieldActionPerformed(evt);
            }
        });

        searchButttonByName_ID.setBackground(new java.awt.Color(0, 102, 204));
        searchButttonByName_ID.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        searchButttonByName_ID.setForeground(new java.awt.Color(255, 255, 255));
        searchButttonByName_ID.setText("SEARCH");
        searchButttonByName_ID.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchMedicine(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("SEARCH byID & byNAME : ");

        jComboBox4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jComboBox4.setForeground(new java.awt.Color(0, 102, 0));
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ByName", "ByID" }));
        jComboBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4ActionPerformed(evt);
            }
        });

        jLabel27.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel27.setText("SEARCH BY CATEGORY  & CAMPANY: ");

        jComboBox6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jComboBox6.setForeground(new java.awt.Color(0, 102, 0));
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ByCATEGORY", "ByCAMPANY" }));

        SearchMedicineBycategoryByCompany.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        SearchMedicineBycategoryByCompany.setForeground(new java.awt.Color(0, 102, 0));
        SearchMedicineBycategoryByCompany.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchMedicineBycategoryByCompanyActionPerformed(evt);
            }
        });

        SearchButtonByCategory_Company.setBackground(new java.awt.Color(0, 102, 204));
        SearchButtonByCategory_Company.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        SearchButtonByCategory_Company.setForeground(new java.awt.Color(255, 255, 255));
        SearchButtonByCategory_Company.setText("SEARCH");
        SearchButtonByCategory_Company.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SortMedicine_byCategory_byCompany(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setText("CHECK LESS STOCK : ");

        EndingstockOfMedicineField.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        EndingstockOfMedicineField.setForeground(new java.awt.Color(0, 102, 0));
        EndingstockOfMedicineField.setText("0");
        EndingstockOfMedicineField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EndingstockOfMedicineFieldActionPerformed(evt);
            }
        });

        checkLessStckButton.setBackground(new java.awt.Color(0, 102, 204));
        checkLessStckButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        checkLessStckButton.setForeground(new java.awt.Color(255, 255, 255));
        checkLessStckButton.setText("CHECK");
        checkLessStckButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                stockSearch(evt);
            }
        });

        startingstockOfMedicineField.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        startingstockOfMedicineField.setForeground(new java.awt.Color(0, 102, 0));
        startingstockOfMedicineField.setText("0");
        startingstockOfMedicineField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startingstockOfMedicineFieldActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel12Layout.createSequentialGroup()
                            .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(SearchMedicineBycategoryByCompany, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(SearchButtonByCategory_Company, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel12Layout.createSequentialGroup()
                            .addGap(88, 88, 88)
                            .addComponent(jLabel27)))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel12Layout.createSequentialGroup()
                                .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(searchMedicineByNameByIDField, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(searchButttonByName_ID, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addComponent(startingstockOfMedicineField, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(EndingstockOfMedicineField, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(checkLessStckButton, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(77, 77, 77))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchMedicineByNameByIDField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchButttonByName_ID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SearchMedicineBycategoryByCompany, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SearchButtonByCategory_Company, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EndingstockOfMedicineField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(checkLessStckButton, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(startingstockOfMedicineField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel29.setForeground(new java.awt.Color(0, 153, 0));
        jLabel29.setText("(  Select medicine from Right side Table )");

        refreshButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        refreshButton.setText("Refresh Table ->");
        refreshButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RefreshTableOfAvalilableStock(evt);
            }
        });

        RemoveMedicineFromList.setBackground(new java.awt.Color(255, 51, 51));
        RemoveMedicineFromList.setForeground(new java.awt.Color(255, 255, 255));
        RemoveMedicineFromList.setText("REMOVE MEDICNE");
        RemoveMedicineFromList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RemoveMedicineFromListMouseClicked(evt);
            }
        });

        jLabel31.setForeground(new java.awt.Color(0, 204, 0));
        jLabel31.setText("For Update stock :- step 1 - Check Update, step 2 - enter stock, 3 - select row which you want to add stock");

        jLabel32.setForeground(new java.awt.Color(255, 0, 0));
        jLabel32.setText("Note 1 :-");

        UpdateMode.setText("Update");

        stockUpdateField.setText("0");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                                .addComponent(printListButton, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(RemoveMedicineFromList, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(stockUpdateField, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(UpdateMode, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addComponent(jLabel19)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(refreshButton)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 852, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(155, 155, 155)
                        .addComponent(jLabel32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel31)))
                .addGap(72, 72, 72))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 324, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(refreshButton))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, 246, Short.MAX_VALUE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addGap(40, 40, 40)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(printListButton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                        .addComponent(RemoveMedicineFromList, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(UpdateMode, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(stockUpdateField))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel32)
                        .addComponent(jLabel31)))
                .addGap(24, 24, 24))
        );

        jTabbedPane1.addTab("Available Stock", jPanel4);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jLabel23.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("ADD COMPANY");

        CompanyTable.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        CompanyTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Email Address", "Phone Number", "Address"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        CompanyTable.setIntercellSpacing(new java.awt.Dimension(0, 0));
        CompanyTable.setRowHeight(25);
        CompanyTable.setSelectionBackground(new java.awt.Color(232, 57, 95));
        CompanyTable.setShowVerticalLines(false);
        jScrollPane3.setViewportView(CompanyTable);
        if (CompanyTable.getColumnModel().getColumnCount() > 0) {
            CompanyTable.getColumnModel().getColumn(0).setResizable(false);
            CompanyTable.getColumnModel().getColumn(1).setResizable(false);
            CompanyTable.getColumnModel().getColumn(2).setResizable(false);
            CompanyTable.getColumnModel().getColumn(3).setResizable(false);
            CompanyTable.getColumnModel().getColumn(4).setResizable(false);
        }

        AddCompanyButton.setBackground(new java.awt.Color(0, 102, 0));
        AddCompanyButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        AddCompanyButton.setForeground(new java.awt.Color(255, 255, 255));
        AddCompanyButton.setText("ADD COMPANY");
        AddCompanyButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddCompanyButtonMouseClicked(evt);
            }
        });

        SearchCompanyButton.setBackground(new java.awt.Color(0, 102, 204));
        SearchCompanyButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        SearchCompanyButton.setForeground(new java.awt.Color(255, 255, 255));
        SearchCompanyButton.setText("SEARCH");
        SearchCompanyButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchCompany(evt);
            }
        });

        serachModeFor_search_company.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ByID", "ByName" }));

        DeleteCompanyButton.setBackground(new java.awt.Color(255, 51, 0));
        DeleteCompanyButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        DeleteCompanyButton.setForeground(new java.awt.Color(255, 255, 255));
        DeleteCompanyButton.setText("DELETE COMPANY");
        DeleteCompanyButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DeleteCompanyButtonMouseClicked(evt);
            }
        });

        RefreshCompanyTableButton.setText("Refresh Table");
        RefreshCompanyTableButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshCompanyTableButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 1375, Short.MAX_VALUE)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(AddCompanyButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DeleteCompanyButton)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(276, 276, 276)
                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(RefreshCompanyTableButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(serachModeFor_search_company, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(searchCompanyField, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(SearchCompanyButton)
                        .addGap(118, 118, 118))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(RefreshCompanyTableButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(11, 11, 11))
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(AddCompanyButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(DeleteCompanyButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(SearchCompanyButton, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                    .addComponent(searchCompanyField)
                    .addComponent(serachModeFor_search_company))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 528, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Add Company", jPanel5);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 683, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BackToHomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackToHomeMouseClicked
        MainForm mf = new MainForm();
        mf.show();
        dispose();
    }//GEN-LAST:event_BackToHomeMouseClicked

    private void SerialNumberOfMedicineFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SerialNumberOfMedicineFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SerialNumberOfMedicineFieldActionPerformed

    private void MedicineNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MedicineNameFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MedicineNameFieldActionPerformed

    private void searchMedicineByNameByIDFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchMedicineByNameByIDFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchMedicineByNameByIDFieldActionPerformed

    private void jTabbedPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MouseClicked

    }//GEN-LAST:event_jTabbedPane1MouseClicked

    private void AddCompanyButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddCompanyButtonMouseClicked
        AddCompany ac = new AddCompany();
        ac.show();

    }//GEN-LAST:event_AddCompanyButtonMouseClicked

    private void AddCompany(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddCompany
        AddCompany ac = new AddCompany();
        ac.show();

    }//GEN-LAST:event_AddCompany

    private void AddCategory(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddCategory
        Category c = new Category();
        c.show();
    }//GEN-LAST:event_AddCategory

    private void AddMedicine(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddMedicine

        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat;
        dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String strDate = dateFormat.format(date);
        String type;
        Date date1 = MedicineAddDate.getDate();
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        String strDate1 = dateFormat1.format(date1);
        int id = Integer.parseInt(SerialNumberOfMedicineField.getText());
        float buyingPrice = Float.parseFloat(BuyingPriceField.getText());
        int Quantity = Integer.parseInt(QuantityField.getText());
        String Company = CompanyNameField.getSelectedItem().toString();
        Date dt1 = new Date();
        Calendar c = Calendar.getInstance();
        dt1 = c.getTime();
        SimpleDateFormat dataformat = new SimpleDateFormat("yyyy-MM-dd");
        String strDate2 = dataformat.format(dt1);
        try {
            if (validate_TextBox()) {
                ///check serial number is available in today session
                if (isAvailable(SerialNumberOfMedicineField.getText())) {

                    JOptionPane.showMessageDialog(this, "already exists ");
                    con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                    java.sql.Statement stmt = con.createStatement();
                    String query = "select * FROM MEDICINE WHERE MED_ID=" + id + " and BUYINGPRICE=" + buyingPrice + " and DATE='" + strDate1 + "'";
                    rs = stmt.executeQuery(query);
                    rs.next();
                    int quantity = rs.getInt(8);
                    quantity += Quantity;
                    query = "UPDATE MEDICINE SET QUANTITY=" + quantity + " WHERE MED_ID=" + id + " AND DATE='" + strDate1 + "'";
                    stmt.execute(query);
                    JOptionPane.showMessageDialog(this, "Update Successfully...");
                    //set buying stock is paid or Not
                    if (notPaid.isSelected()) {
                        type = "NOT PAID";
                    } else {
                        type = "PAID";
                    }
                    float amt = buyingPrice * Quantity;
                    try {
                        con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                        query = "SELECT * FROM EXPENISES WHERE NAME='" + Company + "' AND TYPE='" + type + "' AND DATE='" + strDate + "'";

                        rs = stmt.executeQuery(query);

                        //check the expense is already available in today session for Update the Expense
                        //if Expanse is available then expense is updated
                        //else expense is Added
                        if (rs.next()) {
                            rs = stmt.executeQuery(query);
                            rs.next();
                            amt += rs.getInt(3);
                            query = "UPDATE EXPENISES SET AMOUNT=" + amt + " WHERE NAME='" + Company + "' and DATE='" + strDate + "' and TYPE='" + type + "'";
                            stmt.execute(query);
                            JOptionPane.showMessageDialog(this, "UPDATE SUUCESSFULLY...");
                        } else {
//                          
                            query = "SELECT MAX(ID) FROM EXPENISES";
                            int maxId = 1;
                            rs = stmt.executeQuery(query);
                            System.out.println("1");
                            if (rs.next()) {
                                maxId = (Integer) rs.getInt(1) + 1;
                            }
                            System.out.println("2" + maxId);

                            if (type.equals("PAID")) {
                                System.out.println("Hello  " + strDate2);
                                PreparedStatement Add = con.prepareStatement("INSERT INTO EXPENISES (ID,NAME,AMOUNT,DATE,CATEGORY,TYPE,PAIDDATE) VALUES(" + maxId + ",'" + Company + "'," + amt + ",'" + strDate1 + "','company','" + type + "','" + strDate2 + "')");
                                int row = Add.executeUpdate();
                            } else {
                                PreparedStatement Add = con.prepareStatement("insert into EXPENISES (ID,NAME,AMOUNT,DATE,CATEGORY,TYPE) Values (" + maxId + ",'" + Company + "'," + amt + ","
                                        + "'" + strDate1 + "','company','" + type + "')");
                                int row = Add.executeUpdate();
                            }

                            JOptionPane.showMessageDialog(this, "Expens Add SuccessFully...");
                        }
                    } catch (SQLException e) {
                        System.out.println(e);
                        System.out.println("error in add medicine....");
                    }
                    reset();
                    model.setNumRows(0);
                    selection();
                    model1.setNumRows(0);
                    selection1();
                } else {
                    InsertData();
                    //---------inseert  EXPENISVE
                    if (notPaid.isSelected()) {
                        type = "NOT PAID";
                    } else {
                        type = "PAID";
                    }
                    float amt = buyingPrice * Quantity;
                    try {
                        con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                        System.out.println("0");
                        String query = "SELECT * FROM EXPENISES WHERE NAME='" + Company + "' AND TYPE='" + type + "' AND DATE='" + strDate + "'";
                        java.sql.Statement stmt = con.createStatement();
                        rs = stmt.executeQuery(query);
                        if (rs.next()) {
                            rs = stmt.executeQuery(query);
                            rs.next();
                            amt += rs.getInt(3);
                            System.out.println("1");
                            query = "UPDATE EXPENISES SET AMOUNT=" + (int) amt + " WHERE NAME='" + Company + "' AND TYPE='" + type + "'";
                            stmt.execute(query);
                            JOptionPane.showMessageDialog(this, "UPDATE SUUCESSFULLY...");
                            System.out.println("2");
                        } else {
                            query = "SELECT MAX(ID) FROM EXPENISES";
                            rs = stmt.executeQuery(query);
                            int maxId = 1;
                            if (rs.next()) {
                                maxId = (Integer) rs.getInt(1) + 1;
                            }
                            if (type.equals("PAID")) {
                                System.out.println("Hello  " + strDate2);
                                PreparedStatement Add = con.prepareStatement("INSERT INTO EXPENISES (ID,NAME,AMOUNT,DATE,CATEGORY,TYPE,PAIDDATE) VALUES(" + maxId + ",'" + Company + "'," + amt + ",'" + strDate1 + "','company','" + type + "','" + strDate2 + "')");
                                int row = Add.executeUpdate();
                            } else {
                                PreparedStatement Add = con.prepareStatement("insert into EXPENISES (ID,NAME,AMOUNT,DATE,CATEGORY,TYPE) Values (" + maxId + ",'" + Company + "'," + amt + ","
                                        + "'" + strDate1 + "','company','" + type + "')");
                                int row = Add.executeUpdate();
                            }
                            System.out.println("3");
                           // int row = Add.executeUpdate();
                            System.out.println("4");
                            JOptionPane.showMessageDialog(this, "Expens Add SuccessFully...");
                        }
                    } catch (SQLException e) {
                        System.out.println(e);
                        System.out.println("error in add medicine....");
                    }
                    con.close();
                    reset();
                    model.setNumRows(0);
                    selection();
                    model1.setNumRows(0);
                    selection1();

                }
            }
        } catch (HeadlessException | NumberFormatException | SQLException e) {
            System.out.println(e);
            System.out.println("error in add medicine....");
        }


    }//GEN-LAST:event_AddMedicine

    private void DeleteMedicine(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeleteMedicine
        Date date1 = MedicineAddDate.getDate();
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        String strDate1 = dateFormat1.format(date1);
        int id = Integer.parseInt(SerialNumberOfMedicineField.getText());
        if (SerialNumberOfMedicineField.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "please Enter Medicine ID OR Select medicine from table");
        } else {
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                // int i = jTable1.getSelectedRow();
                stmt.executeUpdate("DELETE FROM MEDICINE WHERE MED_ID=" + id + " and DATE='" + strDate1 + "'");
                JOptionPane.showMessageDialog(this, "Medicine Delete successfuly...");
                try {
                    PreparedStatement Add = con.prepareStatement("insert into DELETED_MEDICINE Values (?,?,?,?,?,?,?,?)");
                    Add.setString(1, SerialNumberOfMedicineField.getText());
                    Add.setString(2, CompanyNameField.getSelectedItem().toString());
                    Add.setString(3, CategoryField.getSelectedItem().toString());
                    Add.setString(4, MedicineNameField.getText());
                    Add.setString(5, BuyingPriceField.getText());
                    Add.setString(6, SellingPriceField.getText());
                    Add.setString(7, QuantityField.getText());
                    Add.setString(8, strDate1);
                    int row = Add.executeUpdate();

                } catch (SQLException e) {
                    System.out.println(e);
                }
                model.setNumRows(0);
                selection();
                model1.setNumRows(0);
                selection1();
                reset();
                AddedMedcineTable.clearSelection();
                con.close();
            } catch (SQLException e) {
                System.out.println(e);
            }
        }
    }//GEN-LAST:event_DeleteMedicine

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        Date date = Calendar.getInstance().getTime();
        MedicineAddDate.setDate(date);

    }//GEN-LAST:event_formWindowActivated

    private void AddedMedcineTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddedMedcineTableMouseClicked
        try {
            int i = AddedMedcineTable.getSelectedRow();
            TableModel model = AddedMedcineTable.getModel();
            SerialNumberOfMedicineField.setText(model.getValueAt(i, 0).toString());
            CompanyNameField.setSelectedItem(model.getValueAt(i, 1).toString());
            CategoryField.setSelectedItem(model.getValueAt(i, 2).toString());
            MedicineNameField.setText(model.getValueAt(i, 3).toString());
            BuyingPriceField.setText(model.getValueAt(i, 4).toString());
            SellingPriceField.setText(model.getValueAt(i, 5).toString());
            QuantityField.setText(model.getValueAt(i, 6).toString());
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String date = model.getValueAt(i, 7).toString();
            Date dat = dateFormat.parse(date);
            String date2 = model.getValueAt(i, 8).toString();
            Date dat2 = dateFormat.parse(date2);
            MedicineAddDate.setDate(dat);
            MedicineExpireDate.setDate(dat2);
        } catch (ParseException e) {
        }
    }//GEN-LAST:event_AddedMedcineTableMouseClicked

    private void UpdateMedicine(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdateMedicine
        try {
            if (validate_TextBox()) {
                Update();
                model.setNumRows(0);
                selection();
                model1.setNumRows(0);
                selection1();
                reset();
            }
        } catch (SQLException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
//        try {
//            con = DriverManager.getConnection("jdbc:derby://localhost:1527/REGISTER", "moin", "Moin$8338");
//            PreparedStatement Add = con.prepareStatement("insert into RE Values (?,?,?,?)");
//            Add.setString(1, "1");
//            Add.setString(2, "moin");
//            Add.setString(3, "Moin$8338 ");
//            Add.setString(4, "moin@gmail.com");
//
//            int row = Add.executeUpdate();
//            JOptionPane.showMessageDialog(this, "done");
//            con.close();
//        } catch (SQLException ex) {
//            Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
//            System.out.println(ex);
//        }


    }//GEN-LAST:event_UpdateMedicine

    private void SearchMedicne(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchMedicne
        String query = "SELECT * FROM MEDICINE";
        if (SearchMedicineFieldl.getText().equals("")) {
            SearchMedicineFieldl.setBackground(Color.red);
        } else {
            SearchMedicineFieldl.setBackground(Color.WHITE);
            String search = SearchMedicineFieldl.getText();
            if (jComboBox3.getSelectedItem().toString().equals("ByID")) {
                try {
                    if (isValidNumber(SearchMedicineFieldl.getText())) {

                        con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                        java.sql.Statement stmt = con.createStatement();
                        query = "select * FROM MEDICINE WHERE MED_ID=" + Integer.parseInt(search) + "";
                        rs = stmt.executeQuery(query);
                        model.setNumRows(0);
                        while (rs.next()) {
                            String id = rs.getString("MED_ID");
                            String Company = rs.getString("CAMPANY");
                            String Category = rs.getString("CATEGORY");
                            String Name = rs.getString("MEDICINENAME");
                            String BuyP = rs.getString("BUYINGPRICE");
                            String SellP = rs.getString("SELLINGPRICE");
                            String Quantity = rs.getString("QUANTITY");
                            String Date = rs.getString("DATE");
                            String ExpDate = rs.getString("EXPDATE");

                            String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                            DefaultTableModel tb1Model = (DefaultTableModel) AddedMedcineTable.getModel();

                            tb1Model.addRow(tbDate);
                        }
                        con.close();

                    } else {
                        JOptionPane.showMessageDialog(this, "Enter Valid Id Only Number");
                    }
                } catch (SQLException e) {
                    System.out.println(e);
                }
            } else if (jComboBox3.getSelectedItem().toString().equals("ByName")) {
                try {
                    con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                    java.sql.Statement stmt = con.createStatement();
                    query = "SELECT * FROM MEDICINE WHERE MEDICINENAME LIKE '" + SearchMedicineFieldl.getText() + "'";
                    rs = stmt.executeQuery(query);
                    model.setNumRows(0);
                    while (rs.next()) {
                        // if (rs.getString(5).toLowerCase().equals(SearchMedicineFieldl.getText().toLowerCase())) {
                        String id = rs.getString("MED_ID");
                        String Company = rs.getString("CAMPANY");
                        String Category = rs.getString("CATEGORY");
                        String Name = rs.getString("MEDICINENAME");
                        String BuyP = rs.getString("BUYINGPRICE");
                        String SellP = rs.getString("SELLINGPRICE");
                        String Quantity = rs.getString("QUANTITY");
                        String Date = rs.getString("DATE");
                        String ExpDate = rs.getString("EXPDATE");

                        String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                        DefaultTableModel tb1Model = (DefaultTableModel) AddedMedcineTable.getModel();

                        tb1Model.addRow(tbDate);
                        // }

                    }
                    con.close();

                } catch (SQLException e) {
                    System.out.println(e);
                }
            } else if (jComboBox3.getSelectedItem().toString().equals("ByCompany")) {
                try {
                    con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                    java.sql.Statement stmt = con.createStatement();
                    query = "SELECT * FROM MEDICINE WHERE CAMPANY LIKE '" + SearchMedicineFieldl.getText() + "'";
                    rs = stmt.executeQuery(query);
                    model.setNumRows(0);
                    while (rs.next()) {
                        // if (rs.getString(5).toLowerCase().equals(SearchMedicineFieldl.getText().toLowerCase())) {
                        String id = rs.getString("MED_ID");
                        String Company = rs.getString("CAMPANY");
                        String Category = rs.getString("CATEGORY");
                        String Name = rs.getString("MEDICINENAME");
                        String BuyP = rs.getString("BUYINGPRICE");
                        String SellP = rs.getString("SELLINGPRICE");
                        String Quantity = rs.getString("QUANTITY");
                        String Date = rs.getString("DATE");
                        String ExpDate = rs.getString("EXPDATE");

                        String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                        DefaultTableModel tb1Model = (DefaultTableModel) AddedMedcineTable.getModel();

                        tb1Model.addRow(tbDate);
                        // }

                    }
                    con.close();

                } catch (SQLException e) {
                    System.out.println(e);
                }
            } else if (jComboBox3.getSelectedItem().toString().equals("ByCategory")) {
                try {
                    con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                    java.sql.Statement stmt = con.createStatement();
                    query = "SELECT * FROM MEDICINE WHERE CATEGORY LIKE '" + SearchMedicineFieldl.getText() + "'";
                    rs = stmt.executeQuery(query);
                    model.setNumRows(0);
                    while (rs.next()) {
                        // if (rs.getString(5).toLowerCase().equals(SearchMedicineFieldl.getText().toLowerCase())) {
                        String id = rs.getString("MED_ID");
                        String Company = rs.getString("CAMPANY");
                        String Category = rs.getString("CATEGORY");
                        String Name = rs.getString("MEDICINENAME");
                        String BuyP = rs.getString("BUYINGPRICE");
                        String SellP = rs.getString("SELLINGPRICE");
                        String Quantity = rs.getString("QUANTITY");
                        String Date = rs.getString("DATE");
                        String ExpDate = rs.getString("EXPDATE");

                        String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                        DefaultTableModel tb1Model = (DefaultTableModel) AddedMedcineTable.getModel();

                        tb1Model.addRow(tbDate);
                        // }

                    }

                    con.close();

                } catch (SQLException e) {
                    System.out.println(e);
                }
            }
        }
        MedicineQuery = query;
        System.out.println(MedicineQuery);
        if (AddedMedcineTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No Data Found ...");
            selection();
            MedicineQuery = "SELECT * FROM MEDICINE";
        }

    }//GEN-LAST:event_SearchMedicne

    private void RefreshPage(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RefreshPage
        Admin a = new Admin();
        dispose();
        a.show();
    }//GEN-LAST:event_RefreshPage

    private void CheckStock(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CheckStock
        if (isValidNumber(startingStockOfMedicine2.getText()) && isValidNumber(EndingStockOfMedicine2.getText())) {
            startingStockOfMedicine2.setBackground(Color.WHITE);
            EndingStockOfMedicine2.setBackground(Color.WHITE);
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT * FROM MEDICINE WHERE QUANTITY BETWEEN " + Integer.parseInt(startingStockOfMedicine2.getText()) + " AND " + Integer.parseInt(EndingStockOfMedicine2.getText()) + "";
                rs = stmt.executeQuery(query);
                model.setNumRows(0);
                while (rs.next()) {
                    String id = rs.getString("MED_ID");
                    String Company = rs.getString("CAMPANY");
                    String Category = rs.getString("CATEGORY");
                    String Name = rs.getString("MEDICINENAME");
                    String BuyP = rs.getString("BUYINGPRICE");
                    String SellP = rs.getString("SELLINGPRICE");
                    String Quantity = rs.getString("QUANTITY");
                    String Date = rs.getString("DATE");
                    String ExpDate = rs.getString("EXPDATE");

                    String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                    DefaultTableModel tb1Model = (DefaultTableModel) AddedMedcineTable.getModel();

                    tb1Model.addRow(tbDate);

                }
                MedicineQuery = query;
                System.out.println("hello " + MedicineQuery);
                con.close();
            } catch (SQLException e) {
                System.out.println(e);
                MedicineQuery = "SELECT * FROM MEDICINE";
            }

        } else {
            if (isValidNumber(startingStockOfMedicine2.getText())) {
                startingStockOfMedicine2.setBackground(Color.WHITE);
            } else {
                startingStockOfMedicine2.setBackground(Color.red);
            }
            if (isValidNumber(EndingStockOfMedicine2.getText())) {
                EndingStockOfMedicine2.setBackground(Color.WHITE);
            } else {
                EndingStockOfMedicine2.setBackground(Color.red);
            }
            JOptionPane.showMessageDialog(this, "Enter valid stock...");
            MedicineQuery = "SELECT * FROM MEDICINE";
        }

        if (AddedMedcineTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No Data Found ...");
            selection();
            MedicineQuery = "SELECT * FROM MEDICINE";
        }
    }//GEN-LAST:event_CheckStock

    private void PrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PrintActionPerformed

    private void SearchMedicineFieldlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchMedicineFieldlActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchMedicineFieldlActionPerformed

    private void SearchMedicine(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchMedicine
        if (jComboBox4.getSelectedItem().toString().equals("ByName")) {
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT * FROM MEDICINE WHERE MEDICINENAME='" + searchMedicineByNameByIDField.getText() + "'";
                rs = stmt.executeQuery(query);
                model1.setNumRows(0);
                while (rs.next()) {
                    String id = rs.getString("MED_ID");
                    String Company = rs.getString("CAMPANY");
                    String Category = rs.getString("CATEGORY");
                    String Name = rs.getString("MEDICINENAME");
                    String BuyP = rs.getString("BUYINGPRICE");
                    String SellP = rs.getString("SELLINGPRICE");
                    String Quantity = rs.getString("QUANTITY");
                    String Date = rs.getString("DATE");
                    String ExpDate = rs.getString("EXPDATE");

                    String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                    DefaultTableModel tb1Model = (DefaultTableModel) AvailableStockTable.getModel();

                    tb1Model.addRow(tbDate);
                }

                con.close();

            } catch (SQLException e) {
                System.out.println(e);
            }
        } else if (jComboBox4.getSelectedItem().toString().equals("ByID")) {

            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT * FROM MEDICINE WHERE MED_ID=" + Integer.parseInt(searchMedicineByNameByIDField.getText()) + "";
                rs = stmt.executeQuery(query);
                if (isValidNumber(searchMedicineByNameByIDField.getText())) {
                    model1.setNumRows(0);
                    query = "select * FROM MEDICINE WHERE MED_ID=" + Integer.parseInt(searchMedicineByNameByIDField.getText()) + "";
                    rs = stmt.executeQuery(query);
                    model.setNumRows(0);
                    while (rs.next()) {
                        String id = rs.getString("MED_ID");
                        String Company = rs.getString("CAMPANY");
                        String Category = rs.getString("CATEGORY");
                        String Name = rs.getString("MEDICINENAME");
                        String BuyP = rs.getString("BUYINGPRICE");
                        String SellP = rs.getString("SELLINGPRICE");
                        String Quantity = rs.getString("QUANTITY");
                        String Date = rs.getString("DATE");
                        String ExpDate = rs.getString("EXPDATE");

                        String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                        DefaultTableModel tb1Model = (DefaultTableModel) AvailableStockTable.getModel();

                        tb1Model.addRow(tbDate);
                    }

                } else {
                    JOptionPane.showMessageDialog(this, "Enter Valid ID...");
                }
                con.close();

            } catch (SQLException e) {
                System.out.println(e);
            }

        }
        if (AvailableStockTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No Data Found ...");
            selection1();
        }
    }//GEN-LAST:event_SearchMedicine

    private void EndingstockOfMedicineFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EndingstockOfMedicineFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EndingstockOfMedicineFieldActionPerformed

    private void stockSearch(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_stockSearch
        if (isValidNumber(startingstockOfMedicineField.getText()) && isValidNumber(EndingstockOfMedicineField.getText())) {
            startingstockOfMedicineField.setBackground(Color.WHITE);
            EndingstockOfMedicineField.setBackground(Color.WHITE);
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT * FROM MEDICINE ORDER BY ID";
                rs = stmt.executeQuery(query);
                model1.setNumRows(0);
                while (rs.next()) {
                    if (rs.getInt(8) <= Integer.parseInt(EndingstockOfMedicineField.getText()) && rs.getInt(8) >= Integer.parseInt(startingstockOfMedicineField.getText())) {
                        String id = rs.getString("MED_ID");
                        String Company = rs.getString("CAMPANY");
                        String Category = rs.getString("CATEGORY");
                        String Name = rs.getString("MEDICINENAME");
                        String BuyP = rs.getString("BUYINGPRICE");
                        String SellP = rs.getString("SELLINGPRICE");
                        String Quantity = rs.getString("QUANTITY");
                        String Date = rs.getString("DATE");
                        String ExpDate = rs.getString("EXPDATE");

                        String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                        DefaultTableModel tb1Model = (DefaultTableModel) AvailableStockTable.getModel();

                        tb1Model.addRow(tbDate);
                    }
                }
                con.close();

            } catch (SQLException e) {
                System.out.println(e);
            }

        } else {
            if (isValidNumber(startingstockOfMedicineField.getText())) {
                startingstockOfMedicineField.setBackground(Color.WHITE);
            } else {
                startingstockOfMedicineField.setBackground(Color.red);
            }
            if (isValidNumber(EndingstockOfMedicineField.getText())) {
                EndingstockOfMedicineField.setBackground(Color.WHITE);
            } else {
                EndingstockOfMedicineField.setBackground(Color.red);
            }
            JOptionPane.showMessageDialog(this, "Enter valid stock...");
        }
        if (AvailableStockTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No Data Found ...");
            selection1();
        }
    }//GEN-LAST:event_stockSearch

    private void startingstockOfMedicineFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startingstockOfMedicineFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_startingstockOfMedicineFieldActionPerformed

    private void SearchMedicineBycategoryByCompanyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchMedicineBycategoryByCompanyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchMedicineBycategoryByCompanyActionPerformed

    private void SortMedicine_byCategory_byCompany(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SortMedicine_byCategory_byCompany
        if (jComboBox6.getSelectedItem().toString().equals("ByCAMPANY")) {
            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT * FROM MEDICINE ORDER BY ID";
                rs = stmt.executeQuery(query);
                model1.setNumRows(0);
                while (rs.next()) {
                    if (rs.getString(3).toLowerCase().equals(SearchMedicineBycategoryByCompany.getText().toLowerCase())) {
                        String id = rs.getString("MED_ID");
                        String Company = rs.getString("CAMPANY");
                        String Category = rs.getString("CATEGORY");
                        String Name = rs.getString("MEDICINENAME");
                        String BuyP = rs.getString("BUYINGPRICE");
                        String SellP = rs.getString("SELLINGPRICE");
                        String Quantity = rs.getString("QUANTITY");
                        String Date = rs.getString("DATE");
                        String ExpDate = rs.getString("EXPDATE");

                        String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                        DefaultTableModel tb1Model = (DefaultTableModel) AvailableStockTable.getModel();

                        tb1Model.addRow(tbDate);
                    }
                }

                con.close();

            } catch (SQLException e) {
                System.out.println(e);
            }
        } else if (jComboBox6.getSelectedItem().toString().equals("ByCATEGORY")) {

            try {
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                String query = "SELECT * FROM MEDICINE ORDER BY ID";
                rs = stmt.executeQuery(query);
                model1.setNumRows(0);
                while (rs.next()) {
                    if (rs.getString(4).toLowerCase().equals(SearchMedicineBycategoryByCompany.getText().toLowerCase())) {
                        String id = rs.getString("MED_ID");
                        String Company = rs.getString("CAMPANY");
                        String Category = rs.getString("CATEGORY");
                        String Name = rs.getString("MEDICINENAME");
                        String BuyP = rs.getString("BUYINGPRICE");
                        String SellP = rs.getString("SELLINGPRICE");
                        String Quantity = rs.getString("QUANTITY");
                        String Date = rs.getString("DATE");
                        String ExpDate = rs.getString("EXPDATE");

                        String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                        DefaultTableModel tb1Model = (DefaultTableModel) AvailableStockTable.getModel();

                        tb1Model.addRow(tbDate);
                    }

                }
                con.close();

            } catch (SQLException e) {
                System.out.println(e);
            }

        }
        if (AvailableStockTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No Data Found ...");
            selection1();
        }
    }//GEN-LAST:event_SortMedicine_byCategory_byCompany

    private void SortMedicineByDate(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SortMedicineByDate
        Date date1 = jDateChooser4.getDate();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String strDate1 = dateFormat.format(date1);
        Date date2 = jDateChooser5.getDate();
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        String strDate2 = dateFormat.format(date2);
        String query = "";
        try {

            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            if (SortMode_byDate.getSelectedItem().toString().equals("ByAdding_Date")) {
                query = "select * from MEDICINE WHERE DATE BETWEEN '" + strDate1 + "' and '" + strDate2 + "'";
            } else {
                query = "select * from MEDICINE WHERE EXPDATE BETWEEN '" + strDate1 + "' and '" + strDate2 + "'";
            }
            rs = stmt.executeQuery(query);
            model1.setNumRows(0);
            while (rs.next()) {
                String id = rs.getString(2);
                String Name = rs.getString(3);
                String CAMPANY = rs.getString(4);
                String CATEGORY = rs.getString(5);
                String B_price = rs.getString(6);
                String S_price = rs.getString(7);
                String Quantity = rs.getString(8);
                String Date = rs.getString(9);
                String ExpDate = rs.getString(10);

                String tbDate[] = {id, Name, CAMPANY, CATEGORY, B_price, S_price, Quantity, Date, ExpDate};
                DefaultTableModel tb1Model = (DefaultTableModel) AvailableStockTable.getModel();
                tb1Model.addRow(tbDate);
            }
            if (model1.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "NO DATA Found....");
                selection1();
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_SortMedicineByDate

    private void jTextField15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField15ActionPerformed

    private void SortMedicine_byBP_bySP(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SortMedicine_byBP_bySP
        if (jTextField15.getText().equals("")) {
            jTextField15.setBackground(Color.red);
        } else {
            jTextField15.setBackground(Color.WHITE);
            if (ModeOfSearchBySPbyBP.getSelectedItem().toString().equals("ByBUYING")) {
                try {
                    con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                    java.sql.Statement stmt = con.createStatement();
                    String query = "SELECT * FROM MEDICINE ORDER BY ID";
                    rs = stmt.executeQuery(query);
                    model1.setNumRows(0);
                    while (rs.next()) {
                        if (rs.getDouble(6) >= Double.parseDouble(jTextField16.getText()) && rs.getDouble(6) <= Double.parseDouble(jTextField15.getText())) {
                            String id = rs.getString("MED_ID");
                            String Company = rs.getString("CAMPANY");
                            String Category = rs.getString("CATEGORY");
                            String Name = rs.getString("MEDICINENAME");
                            String BuyP = rs.getString("BUYINGPRICE");
                            String SellP = rs.getString("SELLINGPRICE");
                            String Quantity = rs.getString("QUANTITY");
                            String Date = rs.getString("DATE");
                            String ExpDate = rs.getString("EXPDATE");

                            String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                            DefaultTableModel tb1Model = (DefaultTableModel) AvailableStockTable.getModel();

                            tb1Model.addRow(tbDate);
                        }
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
                    System.out.println(ex);
                }
            } else if (ModeOfSearchBySPbyBP.getSelectedItem().toString().equals("BySELLING")) {
                try {
                    con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                    java.sql.Statement stmt = con.createStatement();
                    String query = "SELECT * FROM MEDICINE ORDER BY ID";
                    rs = stmt.executeQuery(query);
                    model1.setNumRows(0);
                    while (rs.next()) {
                        if (rs.getDouble(7) >= Double.parseDouble(jTextField16.getText()) && rs.getDouble(7) <= Double.parseDouble(jTextField15.getText())) {
                            String id = rs.getString("MED_ID");
                            String Company = rs.getString("CAMPANY");
                            String Category = rs.getString("CATEGORY");
                            String Name = rs.getString("MEDICINENAME");
                            String BuyP = rs.getString("BUYINGPRICE");
                            String SellP = rs.getString("SELLINGPRICE");
                            String Quantity = rs.getString("QUANTITY");
                            String Date = rs.getString("DATE");
                            String ExpDate = rs.getString("EXPDATE");

                            String tbDate[] = {id, Company, Category, Name, BuyP, SellP, Quantity, Date, ExpDate};
                            DefaultTableModel tb1Model = (DefaultTableModel) AvailableStockTable.getModel();

                            tb1Model.addRow(tbDate);
                        }
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
                    System.out.println(ex);
                }
            }
        }
        if (AvailableStockTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No Data Found ...");
            selection1();
        }
    }//GEN-LAST:event_SortMedicine_byBP_bySP

    private void printListButtonSearchMedicine(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_printListButtonSearchMedicine
         try {

            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            JasperDesign jasdi = JRXmlLoader.load("C:\\Users\\moin_pc\\Documents\\NetBeansProjects\\PharmacyDemo\\src\\PharamcyManagementSystem\\createList.jrxml");
            String sql = "SELECT * FROM CREATELIST";
            JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jasdi.setQuery(newQuery);
            JasperReport js = JasperCompileManager.compileReport(jasdi);
            JasperPrint jp = JasperFillManager.fillReport(js, p, con);
            //JasperViewer.viewReport(jp);
            JasperViewer.viewReport(jp, false);
        } catch (JRException ex) {
            System.out.println(ex);
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }//GEN-LAST:event_printListButtonSearchMedicine

    private void RefreshTableOfAvalilableStock(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RefreshTableOfAvalilableStock
        model1.setNumRows(0);
        selection1();
    }//GEN-LAST:event_RefreshTableOfAvalilableStock

    private void jTextField16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField16ActionPerformed

    private void jComboBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox4ActionPerformed

    private void AvailableStockTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AvailableStockTableMouseClicked
        try {
            int i = AvailableStockTable.getSelectedRow();
            TableModel model = AvailableStockTable.getModel();
            TableModel model2 = MakeListTable.getModel();
            DefaultTableModel list = (DefaultTableModel) MakeListTable.getModel();

            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            int id = Integer.parseInt(model.getValueAt(i, 0).toString());
            String query = "SELECT * FROM CreateList WHERE ID=" + id + "";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Already exists...");
            } else {
                PreparedStatement Add = con.prepareStatement("insert into CreateList Values (?,?,?,?,?)");
                Add.setString(1, model.getValueAt(i, 0).toString());
                Add.setString(2, model.getValueAt(i, 1).toString());
                Add.setString(3, model.getValueAt(i, 2).toString());
                Add.setString(4, model.getValueAt(i, 3).toString());
                Add.setString(5, model.getValueAt(i, 6).toString());
                int row = Add.executeUpdate();
                list.setNumRows(0);
                selection2();
            }
            con.close();

        } catch (SQLException e) {
            System.out.println("error in make list " + e);
        }
    }//GEN-LAST:event_AvailableStockTableMouseClicked

    private void RemoveMedicineFromListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RemoveMedicineFromListMouseClicked
        try {
            if (MakeListTable.getRowCount() != 0 && MakeListTable.getSelectedRowCount() != 0) {
                int[] arr = MakeListTable.getSelectedRows();
                for (int i = 0; i < arr.length; i++) {
                    TableModel model2 = MakeListTable.getModel();
                    DefaultTableModel list = (DefaultTableModel) MakeListTable.getModel();
                    con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                    java.sql.Statement stmt = con.createStatement();
                    int id = Integer.parseInt(model2.getValueAt(arr[i], 0).toString());
                    stmt.executeUpdate("DELETE FROM CreateList WHERE ID=" + id + "");
                    list.setNumRows(0);
                    selection2();
                    con.close();
                }

            } else {
                JOptionPane.showMessageDialog(this, "No data Found...");
            }
        } catch (SQLException e) {
            System.out.println();
        }
    }//GEN-LAST:event_RemoveMedicineFromListMouseClicked

    private void Update_stock(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Update_stock
        try {
            if (UpdateMode.isSelected()) {
                TableModel model2 = MakeListTable.getModel();
                int i = MakeListTable.getSelectedRow();
                DefaultTableModel list = (DefaultTableModel) MakeListTable.getModel();
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                java.sql.Statement stmt = con.createStatement();
                int id = Integer.parseInt(model2.getValueAt(i, 0).toString());
                String query = "UPDATE CreateList SET QUANTITY=" + Integer.parseInt(stockUpdateField.getText()) + " WHERE ID=" + id + "";
                stmt.executeUpdate(query);
                list.setNumRows(0);
                selection2();
                con.close();

            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_Update_stock

    private void DeleteCompanyButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeleteCompanyButtonMouseClicked
        try {
            if (CompanyTable.getRowCount() != 0 && CompanyTable.getSelectedRowCount() != 0) {
                int[] arr = CompanyTable.getSelectedRows();
                for (int i = 0; i < arr.length; i++) {
                    TableModel model2 = CompanyTable.getModel();
                    DefaultTableModel list = (DefaultTableModel) CompanyTable.getModel();
                    con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
                    java.sql.Statement stmt = con.createStatement();
                    int id = Integer.parseInt(model2.getValueAt(arr[i], 0).toString());
                    stmt.executeUpdate("DELETE FROM Campany WHERE ID=" + id + "");
                    JOptionPane.showMessageDialog(this, "Campany Deleted...");
                    list.setNumRows(0);
                    selection3();
                    con.close();
                }

            } else {
                JOptionPane.showMessageDialog(this, "No data Found...");
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_DeleteCompanyButtonMouseClicked

    private void RefreshCompanyTableButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshCompanyTableButtonActionPerformed
        DefaultTableModel list = (DefaultTableModel) CompanyTable.getModel();
        list.setNumRows(0);
        selection3();
    }//GEN-LAST:event_RefreshCompanyTableButtonActionPerformed

    private void SearchCompany(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchCompany
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            String query = "SELECT * FROM CAMPANY";
            String search = searchCompanyField.getText();
            if (serachModeFor_search_company.getSelectedItem().toString().equals("ByName")) {
                query = "SELECT * FROM CAMPANY WHERE NAME='" + search + "'";
            } else if (serachModeFor_search_company.getSelectedItem().toString().equals("ByID")) {
                query = "SELECT * FROM CAMPANY WHERE ID=" + Integer.parseInt(search) + "";
            }
            rs = stmt.executeQuery(query);
            model2.setNumRows(0);
            while (rs.next()) {

                String id = rs.getString(1);
                String Name = rs.getString(2);
                String email = rs.getString(3);
                String PhoneNumber = rs.getString(4);
                String Address = rs.getString(5);
                String tbDate[] = {id, Name, email, PhoneNumber, Address};
                DefaultTableModel tb1Model = (DefaultTableModel) CompanyTable.getModel();

                tb1Model.addRow(tbDate);
            }

            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "something went wrong ...");
            model2.setNumRows(0);
            selection3();
        }

        if (CompanyTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No Data Found ...");
            model2.setNumRows(0);
            selection3();
        }
    }//GEN-LAST:event_SearchCompany

    private void PaidMedicine(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PaidMedicine
        Paid.setSelected(true);
        notPaid.setSelected(false);
    }//GEN-LAST:event_PaidMedicine

    private void NotPaidMedicine(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NotPaidMedicine
        Paid.setSelected(false);
        notPaid.setSelected(true);
        System.out.println(p.values());
    }//GEN-LAST:event_NotPaidMedicine

    private void PrintMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PrintMouseClicked
        try {

            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            JasperDesign jasdi = JRXmlLoader.load("C:\\Users\\moin_pc\\Documents\\NetBeansProjects\\PharmacyDemo\\src\\PharamcyManagementSystem\\Medicine.jrxml");
            String sql = MedicineQuery;
            JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jasdi.setQuery(newQuery);
            JasperReport js = JasperCompileManager.compileReport(jasdi);
            JasperPrint jp = JasperFillManager.fillReport(js, p, con);
            //JasperViewer.viewReport(jp);
            JasperViewer.viewReport(jp, false);
        } catch (JRException ex) {
            System.out.println(ex);
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }//GEN-LAST:event_PrintMouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> {
            new Admin().setVisible(true);
        });
    }
    public int stop = 1;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddCompanyButton;
    private javax.swing.JButton AddMedicine;
    private javax.swing.JTable AddedMedcineTable;
    private javax.swing.JTable AvailableStockTable;
    private javax.swing.JLabel BackToHome;
    private javax.swing.JTextField BuyingPriceField;
    private javax.swing.JComboBox<String> CategoryField;
    private javax.swing.JButton CheckStock;
    private javax.swing.JComboBox<String> CompanyNameField;
    private javax.swing.JTable CompanyTable;
    private javax.swing.JButton DeleteCompanyButton;
    private javax.swing.JButton DeleteMedicine;
    private javax.swing.JTextField EndingStockOfMedicine2;
    private javax.swing.JTextField EndingstockOfMedicineField;
    private javax.swing.JTable MakeListTable;
    private com.toedter.calendar.JDateChooser MedicineAddDate;
    private com.toedter.calendar.JDateChooser MedicineExpireDate;
    private javax.swing.JTextField MedicineNameField;
    private javax.swing.JComboBox<String> ModeOfSearchBySPbyBP;
    private javax.swing.JRadioButton Paid;
    private javax.swing.JButton Print;
    private javax.swing.JTextField QuantityField;
    private javax.swing.JButton RefreshCompanyTableButton;
    private javax.swing.JButton RefreshPage;
    private javax.swing.JButton RemoveMedicineFromList;
    private javax.swing.JButton SearchButtonByCategory_Company;
    private javax.swing.JButton SearchCompanyButton;
    private javax.swing.JButton SearchMedicine;
    private javax.swing.JTextField SearchMedicineBycategoryByCompany;
    private javax.swing.JTextField SearchMedicineFieldl;
    private javax.swing.JTextField SellingPriceField;
    private javax.swing.JTextField SerialNumberOfMedicineField;
    private javax.swing.JButton SortByDateButton;
    private javax.swing.JButton SortByPriceButton;
    private javax.swing.JComboBox<String> SortMode_byDate;
    private javax.swing.JButton UpdateMedicine;
    private javax.swing.JRadioButton UpdateMode;
    private javax.swing.JLabel addCategoryLabel;
    private javax.swing.JLabel addCompanylabel;
    private javax.swing.JButton checkLessStckButton;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox6;
    private com.toedter.calendar.JDateChooser jDateChooser4;
    private com.toedter.calendar.JDateChooser jDateChooser5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JRadioButton notPaid;
    private javax.swing.JButton printListButton;
    private javax.swing.JButton refreshButton;
    private javax.swing.JButton searchButttonByName_ID;
    private javax.swing.JTextField searchCompanyField;
    private javax.swing.JTextField searchMedicineByNameByIDField;
    private javax.swing.JComboBox<String> serachModeFor_search_company;
    private javax.swing.JTextField startingStockOfMedicine2;
    private javax.swing.JTextField startingstockOfMedicineField;
    private javax.swing.JTextField stockUpdateField;
    // End of variables declaration//GEN-END:variables

}
