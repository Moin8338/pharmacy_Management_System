package PharamcyManagementSystem;

import java.awt.Cursor;
import java.awt.Toolkit;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

public class MainForm extends javax.swing.JFrame implements Runnable {

    int mode;
    DefaultTableModel model;
    String ExpMedicineListQuery;

    public MainForm() {
        initComponents();
        // time();
        Thread t = new Thread(this);
        t.start();
        model = (DefaultTableModel) Exp_lessStock_medicneTable.getModel();
        ExpMedicineSelection();
        try {
            Calendar c = Calendar.getInstance();
            Date End = c.getTime();
            EndingDateForOverview.setDateFormatString("yyyy-MM-dd");
            EndingDateForOverview.setDate(End);
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String Day = dateFormat.format(End).substring(0, 8) + "01";
            Date Start = new SimpleDateFormat("yyyy-MM-dd").parse(Day);
            StartingDateForOverview.setDateFormatString("yyyy-MM-dd");
            StartingDateForOverview.setDate(Start);
        } catch (ParseException e) {
            System.out.println(e);
        }
        OverViewSelection();
        //seticon();
    }

    public void seticon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("..\\image\\plus-icon d.jpg")));
    }

    //All OverView Selection
    void OverViewSelection() {
        String topCus, TotalCus, TotalExp, TotalCre, DTPay, Purchases, Pay, TopProduct;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date1 = StartingDateForOverview.getDate();
        Date date2 = EndingDateForOverview.getDate();
        String strDate1 = dateFormat.format(date1);
        String strDate2 = dateFormat.format(date2);
        SetDateToDate.setText("From " + strDate1 + " TO " + strDate2);
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();

            //Count Total Customer
            String query = "SELECT COUNT(*) FROM CUSTOMER WHERE DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "'";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                rs.next();
                TotalCus = rs.getString(1);
                TotalCustomer.setText(TotalCus);
            } else {
                TotalCustomer.setText("0");
            }

            //find Top Customer
            query = "SELECT NAME FROM CUSTOMER WHERE DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "' ORDER BY ID DESC FETCH FIRST 1 ROWS ONLY";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                rs.next();
                topCus = rs.getString(1);
                TopCustomer.setText(topCus);
            } else {
                TopCustomer.setText("NULL");
            }

            //Count Total Expenses
            query = "SELECT SUM(AMOUNT) FROM EXPENISES WHERE DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "'";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                rs.next();
                TotalExp = rs.getString(1);
                TotalExpens.setText(TotalExp);
            } else {
                TotalExpens.setText("0");
            }

            //Count Total Credit
            query = "SELECT SUM(AMOUNT) FROM CREDIT WHERE DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "'";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                rs.next();
                TotalCre = Integer.toString(rs.getInt(1));
                TotalCredit.setText(TotalCre);
            } else {
                TotalCredit.setText("0");
            }

            //Count Due to Pay Expense
            query = "SELECT SUM(AMOUNT) FROM EXPENISES WHERE TYPE='NOT PAID' AND DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "'";
            rs = stmt.executeQuery(query);
            //System.out.println(rs.next());
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                rs.next();
                DTPay = rs.getString(1);
                DueToPay.setText(DTPay);
            } else {
                DueToPay.setText("0");
            }

            //Count Payment
            query = "SELECT SUM(AMOUNT) FROM PAYMENT_HISTORY WHERE DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "'";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                rs.next();
                Pay = rs.getString(1);
                Payment.setText(Pay);
            } else {
                Payment.setText("0");
            }

            //find Top Purchased Medicine
            query = "SELECT MEDICINENAME FROM MEDICINE WHERE DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "' ORDER BY ID DESC FETCH FIRST 1 ROWS ONLY";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                rs.next();
                TopProduct = rs.getString(1);
                TopAddedProduct.setText(TopProduct);
            } else {
                TopAddedProduct.setText("NULL");
            }

            //Count Total Purchas
            query = "SELECT QUANTITY,BUYINGPRICE FROM MEDICINE WHERE DATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "'";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                float sum = 0;
                while (rs.next()) {
                    sum = sum + (rs.getFloat(1) * rs.getFloat(2));
                }
                Purchases = Float.toString(sum);
                Purchase.setText(Purchases);
            } else {
                Purchase.setText("0");
            }
        } catch (SQLException e) {
        }
    }

    //Expire Date selection
    void ExpMedicineSelection() {
        String query = "";
        try {
            Date dt = new Date();
            Date dt1 = new Date();
            Calendar c = Calendar.getInstance();
            c.setTime(dt);
            dt1 = c.getTime();
            c.add(Calendar.DATE, 10);
            dt = c.getTime();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String strDate1 = dateFormat.format(dt);
            String strDate2 = dateFormat.format(dt1);
            System.out.println(strDate1 + " TO " + strDate2);
            model.setNumRows(0);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            query = "select * from MEDICINE WHERE EXPDATE BETWEEN '" + strDate2 + "' AND '" + strDate1 + "'";
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                while (rs.next()) {

                    String Med_ID = rs.getString(2);
                    String Name = rs.getString(5);
                    String Qty = rs.getString(8);
                    String Date = rs.getString(9);
                    String ExpDate = rs.getString(10);

                    String tbDate[] = {Med_ID, Name, Qty, Date, ExpDate};
                    DefaultTableModel tb1Model = (DefaultTableModel) Exp_lessStock_medicneTable.getModel();
                    tb1Model.addRow(tbDate);
                }
            } else {
                JOptionPane.showMessageDialog(this, "No Data Found !!");
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    //less stock medicine
    void LessStockMedicineSelection() {
        String query = "";
        try {

            model.setNumRows(0);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            query = "select * from MEDICINE WHERE QUANTITY BETWEEN " + 0 + " AND " + 200 + "";
            ExpMedicineListQuery = query;
            rs = stmt.executeQuery(query);
            if (rs.next()) {
                rs = stmt.executeQuery(query);
                while (rs.next()) {

                    String Med_ID = rs.getString(2);
                    String Name = rs.getString(5);
                    String Qty = rs.getString(8);
                    String Date = rs.getString(9);
                    String ExpDate = rs.getString(10);

                    String tbDate[] = {Med_ID, Name, Qty, Date, ExpDate};
                    DefaultTableModel tb1Model = (DefaultTableModel) Exp_lessStock_medicneTable.getModel();
                    tb1Model.addRow(tbDate);
                }
            } else {
                JOptionPane.showMessageDialog(this, "No Data Found !!");
            }
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
            ExpMedicineListQuery = query;
        }
    }

    public void run() {
        while (true) {
            Calendar c = Calendar.getInstance();

            SimpleDateFormat time = new SimpleDateFormat("yyyy-mm-dd, hh:mm:ss aa");
            Date dat = c.getTime();
            String timeInString = time.format(dat);
            CurruntDate_Time.setText(timeInString);
        }
    }

    public void setmode(int m) {
        mode = m;
    }
    Connection con = null;
    Statement st = null;
    ResultSet rs = null;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        CurruntDate_Time = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        panel1 = new java.awt.Panel();
        SeeResult = new javax.swing.JButton();
        StartingDateForOverview = new com.toedter.calendar.JDateChooser();
        jPanel4 = new javax.swing.JPanel();
        TopCustomer = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        EndingDateForOverview = new com.toedter.calendar.JDateChooser();
        jPanel12 = new javax.swing.JPanel();
        TotalCredit = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        TotalExpens = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        Payment = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        DueToPay = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        TopAddedProduct = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        Purchase = new javax.swing.JLabel();
        SetDateToDate = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        TotalCustomer = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        AddMedicine_button = new javax.swing.JButton();
        SellMedicine_button = new javax.swing.JButton();
        AddExpense_button = new javax.swing.JButton();
        MakeReports_button = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Exp_lessStock_medicneTable = new javax.swing.JTable();
        PrintExpMedicine_button = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        StartingDate = new com.toedter.calendar.JDateChooser();
        EndingDate = new com.toedter.calendar.JDateChooser();
        jLabel16 = new javax.swing.JLabel();
        MinimumStock = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        MaximumStock = new javax.swing.JTextField();
        SortMedicine_button = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        ExpMedicineMode = new javax.swing.JRadioButton();
        LessStockMode = new javax.swing.JRadioButton();
        RemoveExpMedicine_button = new javax.swing.JButton();

        jMenu1.setText("jMenu1");

        jMenu4.setText("jMenu4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("MainForm"); // NOI18N
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(52, 52, 52));

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setFont(new java.awt.Font("Verdana", 0, 16)); // NOI18N
        jButton2.setText("Logout");
        jButton2.setBorder(null);
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(240, 240, 240));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("DAILY");
        jLabel2.setName("DailyActivity"); // NOI18N
        jLabel2.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                DailyActivityHover(evt);
            }
        });
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OpenDailyActivity(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(240, 240, 240));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("PHARMACY");
        jLabel3.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                PharmacyHover(evt);
            }
        });
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OpenPharmacy(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(240, 240, 240));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("ACCOUNT");
        jLabel4.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                AccountHover(evt);
            }
        });
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OpenAccountSection(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(240, 240, 240));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("ADMIN");
        jLabel5.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                AdminHover(evt);
            }
        });
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OpenAdminSection(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jButton4.setText("calc");
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                calculator(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("SETTING");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        CurruntDate_Time.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        CurruntDate_Time.setForeground(new java.awt.Color(0, 153, 0));

        jLabel29.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(0, 153, 0));
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setText("Current Date & Time : ");

        panel1.setBackground(new java.awt.Color(204, 204, 204));

        SeeResult.setBackground(new java.awt.Color(0, 153, 0));
        SeeResult.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        SeeResult.setForeground(new java.awt.Color(255, 255, 255));
        SeeResult.setText("SEE RESULT");
        SeeResult.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SeeResultMouseClicked(evt);
            }
        });

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("TOP CUSTOMER"));
        jPanel4.setMaximumSize(new java.awt.Dimension(181, 71));

        TopCustomer.setBackground(new java.awt.Color(51, 102, 255));
        TopCustomer.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        TopCustomer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TopCustomer.setText("Null");
        TopCustomer.setMaximumSize(new java.awt.Dimension(171, 49));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopCustomer, javax.swing.GroupLayout.DEFAULT_SIZE, 370, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopCustomer, javax.swing.GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE)
        );

        jLabel13.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel13.setText("TO");

        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder("TOTAL CREDIT"));
        jPanel12.setMaximumSize(new java.awt.Dimension(181, 71));

        TotalCredit.setBackground(new java.awt.Color(51, 102, 255));
        TotalCredit.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        TotalCredit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TotalCredit.setText("Null");
        TotalCredit.setMaximumSize(new java.awt.Dimension(171, 49));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TotalCredit, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TotalCredit, javax.swing.GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE)
        );

        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder("TOTAL EXPENSE"));
        jPanel14.setMaximumSize(new java.awt.Dimension(181, 71));

        TotalExpens.setBackground(new java.awt.Color(51, 102, 255));
        TotalExpens.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        TotalExpens.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TotalExpens.setText("Null");
        TotalExpens.setMaximumSize(new java.awt.Dimension(171, 49));

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TotalExpens, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TotalExpens, javax.swing.GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE)
        );

        jPanel15.setBorder(javax.swing.BorderFactory.createTitledBorder("PAYMENT"));
        jPanel15.setMaximumSize(new java.awt.Dimension(181, 71));

        Payment.setBackground(new java.awt.Color(51, 102, 255));
        Payment.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        Payment.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Payment.setText("Null");
        Payment.setMaximumSize(new java.awt.Dimension(171, 49));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Payment, javax.swing.GroupLayout.DEFAULT_SIZE, 171, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Payment, javax.swing.GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE)
        );

        jPanel16.setBorder(javax.swing.BorderFactory.createTitledBorder("DUE TO PAY"));
        jPanel16.setMaximumSize(new java.awt.Dimension(181, 71));

        DueToPay.setBackground(new java.awt.Color(51, 102, 255));
        DueToPay.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        DueToPay.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        DueToPay.setText("Null");
        DueToPay.setMaximumSize(new java.awt.Dimension(171, 49));

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(DueToPay, javax.swing.GroupLayout.DEFAULT_SIZE, 171, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(DueToPay, javax.swing.GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE)
        );

        jPanel17.setBorder(javax.swing.BorderFactory.createTitledBorder("TOP ADDED PRODUCT"));
        jPanel17.setMaximumSize(new java.awt.Dimension(181, 71));

        TopAddedProduct.setBackground(new java.awt.Color(51, 102, 255));
        TopAddedProduct.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        TopAddedProduct.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TopAddedProduct.setText("Null");
        TopAddedProduct.setMaximumSize(new java.awt.Dimension(171, 49));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopAddedProduct, javax.swing.GroupLayout.DEFAULT_SIZE, 171, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopAddedProduct, javax.swing.GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE)
        );

        jPanel18.setBorder(javax.swing.BorderFactory.createTitledBorder("PURCHASE"));
        jPanel18.setMaximumSize(new java.awt.Dimension(181, 71));

        Purchase.setBackground(new java.awt.Color(51, 102, 255));
        Purchase.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        Purchase.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Purchase.setText("Null");
        Purchase.setMaximumSize(new java.awt.Dimension(171, 49));

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Purchase, javax.swing.GroupLayout.DEFAULT_SIZE, 171, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Purchase, javax.swing.GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE)
        );

        SetDateToDate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder("TOTAL CUSTOMER"));
        jPanel13.setMaximumSize(new java.awt.Dimension(181, 71));

        TotalCustomer.setBackground(new java.awt.Color(51, 102, 255));
        TotalCustomer.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        TotalCustomer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TotalCustomer.setText("Null");
        TotalCustomer.setMaximumSize(new java.awt.Dimension(171, 49));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TotalCustomer, javax.swing.GroupLayout.DEFAULT_SIZE, 109, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TotalCustomer, javax.swing.GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panel1Layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panel1Layout.createSequentialGroup()
                                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(panel1Layout.createSequentialGroup()
                                    .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(panel1Layout.createSequentialGroup()
                                    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(panel1Layout.createSequentialGroup()
                                    .addComponent(StartingDateForOverview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jLabel13)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(EndingDateForOverview, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(SetDateToDate, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(78, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(SeeResult, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(200, 200, 200))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(StartingDateForOverview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(EndingDateForOverview, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SeeResult, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(SetDateToDate, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));

        AddMedicine_button.setBackground(new java.awt.Color(0, 153, 0));
        AddMedicine_button.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        AddMedicine_button.setForeground(new java.awt.Color(255, 255, 255));
        AddMedicine_button.setText("ADD MEDICINE");
        AddMedicine_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddMedicine_buttonMouseClicked(evt);
            }
        });

        SellMedicine_button.setBackground(new java.awt.Color(0, 153, 0));
        SellMedicine_button.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        SellMedicine_button.setForeground(new java.awt.Color(255, 255, 255));
        SellMedicine_button.setText("SELL MEDICINE");
        SellMedicine_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SellMedicine_buttonMouseClicked(evt);
            }
        });

        AddExpense_button.setBackground(new java.awt.Color(0, 153, 0));
        AddExpense_button.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        AddExpense_button.setForeground(new java.awt.Color(255, 255, 255));
        AddExpense_button.setText("ADD EXPENSES");
        AddExpense_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddExpense_buttonMouseClicked(evt);
            }
        });

        MakeReports_button.setBackground(new java.awt.Color(0, 153, 0));
        MakeReports_button.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        MakeReports_button.setForeground(new java.awt.Color(255, 255, 255));
        MakeReports_button.setText("MAKE REPORTS");
        MakeReports_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MakeReports_buttonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(MakeReports_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SellMedicine_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AddExpense_button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AddMedicine_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(146, 146, 146)
                .addComponent(AddMedicine_button, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(AddExpense_button, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(SellMedicine_button, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(MakeReports_button, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Exp_lessStock_medicneTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Quantity", "Date", "Exp Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        Exp_lessStock_medicneTable.setRowHeight(30);
        Exp_lessStock_medicneTable.setSelectionBackground(new java.awt.Color(232, 57, 95));
        jScrollPane1.setViewportView(Exp_lessStock_medicneTable);

        PrintExpMedicine_button.setBackground(new java.awt.Color(0, 153, 0));
        PrintExpMedicine_button.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        PrintExpMedicine_button.setForeground(new java.awt.Color(255, 255, 255));
        PrintExpMedicine_button.setText("PRINT");
        PrintExpMedicine_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PrintExpMedicine_buttonMouseClicked(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 18)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("EXPIRE MEDICNE / LESS STOCK");

        jLabel16.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("TO");

        MinimumStock.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        MinimumStock.setText("0");

        jLabel22.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("TO");

        MaximumStock.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        MaximumStock.setText("0");

        SortMedicine_button.setBackground(new java.awt.Color(0, 153, 0));
        SortMedicine_button.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        SortMedicine_button.setForeground(new java.awt.Color(255, 255, 255));
        SortMedicine_button.setText("SORT");
        SortMedicine_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SortMedicine_buttonMouseClicked(evt);
            }
        });

        jLabel23.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("OR");

        ExpMedicineMode.setSelected(true);
        ExpMedicineMode.setText("EXP MEDICINE");
        ExpMedicineMode.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExpMedicineModeMouseClicked(evt);
            }
        });

        LessStockMode.setText("LESS STOCK");
        LessStockMode.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LessStockModeMouseClicked(evt);
            }
        });

        RemoveExpMedicine_button.setBackground(new java.awt.Color(255, 0, 0));
        RemoveExpMedicine_button.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 14)); // NOI18N
        RemoveExpMedicine_button.setForeground(new java.awt.Color(255, 255, 255));
        RemoveExpMedicine_button.setText("REMOVE");
        RemoveExpMedicine_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RemoveExpMedicine_buttonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(ExpMedicineMode)
                        .addGap(18, 18, 18)
                        .addComponent(LessStockMode)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(PrintExpMedicine_button, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(RemoveExpMedicine_button, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(StartingDate, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(3, 3, 3)
                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(4, 4, 4)
                                .addComponent(EndingDate, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(MinimumStock, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(4, 4, 4)
                                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(4, 4, 4)
                                .addComponent(MaximumStock, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(SortMedicine_button)))
                        .addGap(0, 143, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ExpMedicineMode)
                    .addComponent(LessStockMode))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(StartingDate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(EndingDate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(MaximumStock)
                    .addComponent(SortMedicine_button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(MinimumStock))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 445, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PrintExpMedicine_button, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(RemoveExpMedicine_button, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(CurruntDate_Time, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1106, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel29, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                    .addComponent(CurruntDate_Time, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Login l = new Login();
        l.show();
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void OpenAdminSection(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OpenAdminSection
        try {
            Admin a = new Admin();
            a.show();
            dispose();
        } catch (Exception e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_OpenAdminSection

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        if (mode == 2) {
            jLabel5.setVisible(false);
            jLabel4.setVisible(false);
        }
        try {
            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy  hh:mm:ss");
            String strDate = dateFormat.format(date);
            CurruntDate_Time.setText(strDate);
        } catch (Exception e) {

        }
    }//GEN-LAST:event_formWindowOpened

    private void OpenPharmacy(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OpenPharmacy
        Pharmacy p = new Pharmacy();
        p.show();
        dispose();
    }//GEN-LAST:event_OpenPharmacy

    private void OpenAccountSection(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OpenAccountSection
        Account a = new Account();
        a.show();
        dispose();
    }//GEN-LAST:event_OpenAccountSection

    private void OpenDailyActivity(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OpenDailyActivity
        DAILY d = new DAILY();
        d.show();
        dispose();
    }//GEN-LAST:event_OpenDailyActivity

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated

    }//GEN-LAST:event_formWindowActivated

    private void calculator(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_calculator
        calculator c = new calculator();
        c.show();
    }//GEN-LAST:event_calculator

    private void DailyActivityHover(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DailyActivityHover
        jLabel2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_DailyActivityHover

    private void PharmacyHover(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PharmacyHover
        jLabel3.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_PharmacyHover

    private void AccountHover(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AccountHover
        jLabel4.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_AccountHover

    private void AdminHover(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AdminHover
        jLabel5.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_AdminHover

    private void AddMedicine_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddMedicine_buttonMouseClicked
        dispose();
        Admin a = new Admin();
        a.show();
    }//GEN-LAST:event_AddMedicine_buttonMouseClicked

    private void AddExpense_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddExpense_buttonMouseClicked
        dispose();
        Account ac = new Account();
        ac.show();
    }//GEN-LAST:event_AddExpense_buttonMouseClicked

    private void SellMedicine_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SellMedicine_buttonMouseClicked
        dispose();
        Pharmacy p = new Pharmacy();
        p.show();
    }//GEN-LAST:event_SellMedicine_buttonMouseClicked

    private void ExpMedicineModeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExpMedicineModeMouseClicked
        LessStockMode.setSelected(false);
        ExpMedicineSelection();
    }//GEN-LAST:event_ExpMedicineModeMouseClicked

    private void LessStockModeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LessStockModeMouseClicked
        ExpMedicineMode.setSelected(false);
        LessStockMedicineSelection();
    }//GEN-LAST:event_LessStockModeMouseClicked

    private void SortMedicine_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SortMedicine_buttonMouseClicked
        String query = "";
        try {

            if (ExpMedicineMode.isSelected()) {
                Date dt = StartingDate.getDate();
                Date dt1 = EndingDate.getDate();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String strDate1 = dateFormat.format(dt);
                String strDate2 = dateFormat.format(dt1);
                System.out.println(strDate1 + " TO " + strDate2);
                query = "select * from MEDICINE WHERE EXPDATE BETWEEN '" + strDate1 + "' AND '" + strDate2 + "'";
            } else {
                query = "select * from MEDICINE WHERE QUANTITY BETWEEN " + Integer.parseInt(MinimumStock.getText()) + " AND " + Integer.parseInt(MaximumStock.getText()) + "";
            }
            System.out.println(query);
            model.setNumRows(0);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();

            rs = stmt.executeQuery(query);
            if (rs.next()) {

                rs = stmt.executeQuery(query);
                while (rs.next()) {

                    String Med_ID = rs.getString(2);
                    String Name = rs.getString(5);
                    String Qty = rs.getString(8);
                    String Date = rs.getString(9);
                    String ExpDate = rs.getString(10);

                    String tbDate[] = {Med_ID, Name, Qty, Date, ExpDate};
                    DefaultTableModel tb1Model = (DefaultTableModel) Exp_lessStock_medicneTable.getModel();
                    tb1Model.addRow(tbDate);
                }
            } else {
                JOptionPane.showMessageDialog(this, "No Data Found !!");
            }
            ExpMedicineListQuery = query;
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
            ExpMedicineListQuery = query;
        }
        if (Exp_lessStock_medicneTable.getRowCount() == 0) {
            ExpMedicineSelection();
            if (ExpMedicineMode.isSelected()) {
                Date dt = new Date();
                Date dt1 = new Date();
                Calendar c = Calendar.getInstance();
                c.setTime(dt);
                dt1 = c.getTime();
                c.add(Calendar.DATE, 10);
                dt = c.getTime();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String strDate11 = dateFormat.format(dt);
                String strDate22 = dateFormat.format(dt1);
                model.setNumRows(0);
                query = "select * from MEDICINE WHERE EXPDATE BETWEEN '" + strDate22 + "' AND '" + strDate11 + "'";
                ExpMedicineListQuery = query;
            } else {
                ExpMedicineListQuery = "select * from MEDICINE WHERE QUANTITY BETWEEN " + 0 + " AND " + 200 + "";
                LessStockMedicineSelection();
            }

        }


    }//GEN-LAST:event_SortMedicine_buttonMouseClicked

    private void SeeResultMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SeeResultMouseClicked
        OverViewSelection();
    }//GEN-LAST:event_SeeResultMouseClicked

    private void RemoveExpMedicine_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RemoveExpMedicine_buttonMouseClicked
        Calendar c = Calendar.getInstance();
        SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd");
        Date dat = c.getTime();
        String timeInString = time.format(dat);
        try {
            String query = "DELETE FROM MEDICINE WHERE EXPDATE='" + timeInString + "'";
            model.setNumRows(0);
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            java.sql.Statement stmt = con.createStatement();
            stmt.executeUpdate(query);
            JOptionPane.showMessageDialog(this, "Delete Successfully ...");
            ExpMedicineSelection();
            con.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_RemoveExpMedicine_buttonMouseClicked

    private void PrintExpMedicine_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PrintExpMedicine_buttonMouseClicked
        System.out.println("hello  "+ExpMedicineListQuery);
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/PharmacyDatabase", "Moin", "Moin8338");
            JasperDesign jasdi = JRXmlLoader.load("C:\\Users\\moin_pc\\Documents\\NetBeansProjects\\PharmacyDemo\\src\\PharamcyManagementSystem\\Medicine.jrxml");
            String sql = ExpMedicineListQuery;
            JRDesignQuery newQuery = new JRDesignQuery();
            newQuery.setText(sql);
            jasdi.setQuery(newQuery);
            JasperReport js = JasperCompileManager.compileReport(jasdi);
            JasperPrint jp = JasperFillManager.fillReport(js, null, con);
            //JasperViewer.viewReport(jp);
            JasperViewer.viewReport(jp, false);
        } catch (JRException ex) {
            System.out.println(ex);
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }//GEN-LAST:event_PrintExpMedicine_buttonMouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        Register r=new Register();
        dispose();
        r.setMode("setting");
        r.show();
    }//GEN-LAST:event_jLabel1MouseClicked

    private void MakeReports_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MakeReports_buttonMouseClicked
        Make_report mr=new Make_report();
        dispose();
        mr.show();
    }//GEN-LAST:event_MakeReports_buttonMouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddExpense_button;
    private javax.swing.JButton AddMedicine_button;
    private javax.swing.JLabel CurruntDate_Time;
    private javax.swing.JLabel DueToPay;
    private com.toedter.calendar.JDateChooser EndingDate;
    private com.toedter.calendar.JDateChooser EndingDateForOverview;
    private javax.swing.JRadioButton ExpMedicineMode;
    private javax.swing.JTable Exp_lessStock_medicneTable;
    private javax.swing.JRadioButton LessStockMode;
    private javax.swing.JButton MakeReports_button;
    private javax.swing.JTextField MaximumStock;
    private javax.swing.JTextField MinimumStock;
    private javax.swing.JLabel Payment;
    private javax.swing.JButton PrintExpMedicine_button;
    private javax.swing.JLabel Purchase;
    private javax.swing.JButton RemoveExpMedicine_button;
    private javax.swing.JButton SeeResult;
    private javax.swing.JButton SellMedicine_button;
    private javax.swing.JLabel SetDateToDate;
    private javax.swing.JButton SortMedicine_button;
    private com.toedter.calendar.JDateChooser StartingDate;
    private com.toedter.calendar.JDateChooser StartingDateForOverview;
    private javax.swing.JLabel TopAddedProduct;
    private javax.swing.JLabel TopCustomer;
    private javax.swing.JLabel TotalCredit;
    private javax.swing.JLabel TotalCustomer;
    private javax.swing.JLabel TotalExpens;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private java.awt.Panel panel1;
    // End of variables declaration//GEN-END:variables
}
